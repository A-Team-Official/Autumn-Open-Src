/*
 * Client Hacked Client
 * A free open source mixin-based injection hacked client for Minecraft using Minecraft Forge.
 * https://github.com/CCBlueX/Client/
 */
package net.ccbluex.liquidbounce.features.module.modules.combat

import net.ccbluex.liquidbounce.Client
import net.ccbluex.liquidbounce.api.enums.MaterialType
import net.ccbluex.liquidbounce.api.minecraft.client.entity.IEntity
import net.ccbluex.liquidbounce.api.minecraft.network.IPacket
import net.ccbluex.liquidbounce.api.minecraft.network.play.client.ICPacketUseEntity
import net.ccbluex.liquidbounce.api.minecraft.util.WBlockPos
import net.ccbluex.liquidbounce.event.*
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.features.module.modules.movement.StrafeFix
import net.ccbluex.liquidbounce.features.module.modules.world.Scaffold
import net.ccbluex.liquidbounce.injection.backend.unwrap
import net.ccbluex.liquidbounce.utils.*
import net.ccbluex.liquidbounce.utils.extensions.getDistanceToEntityBox
import net.ccbluex.liquidbounce.utils.timer.MSTimer
import net.ccbluex.liquidbounce.value.BoolValue
import net.ccbluex.liquidbounce.value.FloatValue
import net.ccbluex.liquidbounce.value.IntegerValue
import net.ccbluex.liquidbounce.value.ListValue
import net.minecraft.entity.EntityLivingBase
import net.minecraft.entity.player.EntityPlayer
import net.minecraft.network.play.client.*
import net.minecraft.network.play.server.SPacketEntityVelocity
import kotlin.math.cos
import kotlin.math.sin

@ModuleInfo(name = "Velocity2", description = "修复版", category = ModuleCategory.COMBAT, Chinese = "击退覆盖2")
class Velocity2 : Module() {
    /**
     * OPTIONS
     */
    private val horizontalValue = FloatValue("Horizontal", 0.79F, 0F, 1F)
    private val verticalValue = FloatValue("Vertical", 0F, 0F, 1F)
    private val airReducerValue = FloatValue("airReducer", 0.95F, 0F, 1F)

    private val modeValue = ListValue("Mode", arrayOf("Simple", "AAC", "AACPush", "AACZero",
        "Reverse", "SmoothReverse", "Jump", "Glitch","Smart","HytPit","GrimCombat","Click","Noxz"), "Smart")

    // Reverse
    private val reverseStrengthValue = FloatValue("ReverseStrength", 1F, 0.1F, 1F)
    private val reverse2StrengthValue = FloatValue("SmoothReverseStrength", 0.05F, 0.02F, 0.1F)

    // AAC Push
    private val aacPushXZReducerValue = FloatValue("AACPushXZReducer", 2F, 1F, 3F)
    private val msValue = FloatValue("msValue", 80F, 1F, 500F)

    // Smart
    private val wtapreduce = BoolValue("Wtap reduce", false)
    private val stapreduce = BoolValue("Stap reduce", true)
    private val legitPush = BoolValue("Legit Push", false)
    private val attackValue = BoolValue("Attack Reduce", true)
    private val cpsbypass = BoolValue("Cps Bypass", true)
    private val attacktimes = IntegerValue("Attack Times", 15, 1, 50)
    private val legitFaceValue = BoolValue("Legit Face", false)
    private val legitStrafeValue = BoolValue("Legit Strafe", false)
    private val noblock = BoolValue("Noblock", false)
    private val debug = BoolValue("noxzdebug", false)
    private val changesource = BoolValue("noxzchangesource", false)
    private val pushValue = FloatValue("PushSpeed", 0F, 0F, 1F)
    private val Auto = BoolValue("Auto Reduce", true)
    private val onlyinRange = BoolValue("Only InRange", true)
    private val distance = FloatValue("inRange", 4f, 0f, 6f)


    // Click
    private val clickCount = IntegerValue("ClickCount", 2, 1, 10)
    private val clickTime = IntegerValue("ClickMinHurtTime", 8, 1, 10) // 10: only click when receive velocity packet
    private val clickRange = FloatValue("ClickRange", 3.0F, 2.5F, 7F)
    private val clickOnPacket = BoolValue("ClickOnPacket", true)
    private val clickSwing = BoolValue("ClickSwing", false)
    private val clickFakeSwing = BoolValue("ClickFakeSwing", true)



    var radiansYaw = 0.0
    var xx = 0.0
    var zz = 0.0

    /**
     * VALUES
     */
    // legit smart
    private var jumped = 0
    var dosprint = true
    var doinrange = true
    private var velocityTimer = MSTimer()
    var velocityInput = false  //normal velocity
    private var velocityInput2 = false //ground velocity
    private var velocityInput3 = false //air velocity
    //potions
    private var x = 0.0
    private var z = 0.0
    //push
    private var d1 = 0.0
    private var d2 = 0.0
    private var pushtick = 0
    //face
    private var pos: WBlockPos? = null



    // SmoothReverse
    private var reverseHurt = false

    // AACPush
    private var jump = false

    //attack reduce
    var attack = false
    private var jumps = 0
    private var aimed = false
    private var dojump = false



    override val tag: String
        get() = modeValue.get()

    override fun onDisable() {
        mc.thePlayer?.speedInAir = 0.02F
        velocityInput = false
        velocityInput2 = false
        attack = false


    }

    override fun onEnable() {
        velocityInput = false
        velocityInput2 = false
        attack = false

    }
    @EventTarget
    fun onRender(event: Render3DEvent) {
        val objectMouseOver = mc.objectMouseOver

        if (objectMouseOver != null &&
            EntityUtils.isSelected(objectMouseOver.entityHit, true)) {
            aimed = true
        }else{
            aimed = false
        }
    }

    @EventTarget
    fun onStrafe(event: StrafeEvent) {
        when (modeValue.get().toLowerCase()) {
            "smart" -> {
                if (pos == null || mc.thePlayer!!.hurtTime <= 0)
                    return

                val rot = RotationUtils.getRotations(pos!!.x.toDouble(), pos!!.y.toDouble(), pos!!.z.toDouble())
                if (legitFaceValue.get() && !mc.thePlayer!!.onGround) {
                    RotationUtils.setTargetRotation(rot)
                }
                val yaw = rot.yaw
                if (legitStrafeValue.get()) {
                    val speed = MovementUtils.speed
                    val yaw1 = Math.toRadians(yaw.toDouble())
                    mc.thePlayer!!.motionX = -sin(yaw1) * speed
                    mc.thePlayer!!.motionZ = cos(yaw1) * speed
                }
            }

            "hytpit" -> {
                if (pos == null || mc.thePlayer!!.hurtTime <= 0)
                    return

                val rot = RotationUtils.getRotations(pos!!.x.toDouble(), pos!!.y.toDouble(), pos!!.z.toDouble())
                if (legitFaceValue.get()) {
                    RotationUtils.setTargetRotation(rot)
                }
                val yaw = rot.yaw
                if (legitStrafeValue.get()) {
                    val speed = MovementUtils.speed
                    val yaw1 = Math.toRadians(yaw.toDouble())
                    mc.thePlayer!!.motionX = -sin(yaw1) * speed
                    mc.thePlayer!!.motionZ = cos(yaw1) * speed
                }
            }

        }
    }
    @EventTarget
    fun onUpdate(event: UpdateEvent) {
        val thePlayer = mc.thePlayer ?: return
        val aura = Client.moduleManager[KillAura::class.java] as KillAura
        val sca = Client.moduleManager[Scaffold::class.java] as Scaffold

        jumps++
        if (wtapreduce.get() && mc.thePlayer!!.hurtTime < 9)
            mc.gameSettings.keyBindForward.pressed = mc.gameSettings.isKeyDown(mc.gameSettings.keyBindForward)

        if (thePlayer.isInWater || thePlayer.isInLava || thePlayer.isInWeb || !thePlayer.isInsideOfMaterial(classProvider.getMaterialEnum(
                MaterialType.AIR)) )
            return

        for (entity in mc.theWorld!!.loadedEntityList) {
            if (entity.unwrap() is EntityLivingBase && entity.entityId != mc.thePlayer!!.entityId && mc.thePlayer!!.getDistanceToEntityBox(
                    entity
                ) <= distance.get()
            ) {
                doinrange = true
            }else{
                doinrange = false
            }
        }
        when (modeValue.get().toLowerCase()) {

            "jump" -> if (thePlayer.hurtTime > 0 && thePlayer.onGround) {
                thePlayer.motionY = 0.4199999

                val yaw = thePlayer.rotationYaw * 0.017453292F

                thePlayer.motionX -= sin(yaw) * 0.2
                thePlayer.motionZ += cos(yaw) * 0.2
            }
            "click" -> if (velocityInput && thePlayer.hurtTime >= clickTime.get()) {
                if (!attackRayTrace(clickCount.get(), clickRange.get().toDouble(), thePlayer.sprinting)) {
                    if (clickFakeSwing.get()) mc.netHandler.addToSendQueue(classProvider.createCPacketAnimation())
                    velocityInput = false
                }
            } else velocityInput = false

            "noxz"-> {
                //Main
                if (velocityInput) {
                    if (attack) {

                        if (debug.get()) {
                            ClientUtils.displayChatMessage("§8[§c§lCatBounce§8]§c§dReduced")
                        }
                        velocityInput = false
                        attack = false
                    }else{
                        //Bypass all ac
                        if (mc.thePlayer!!.hurtTime>0){
                            mc.thePlayer!!.motionX += -1.0E-7
                            mc.thePlayer!!.motionY += -1.0E-7
                            mc.thePlayer!!.motionZ += -1.0E-7
                            mc.thePlayer!!.isAirBorne = true
                        }
                        velocityInput = false
                        attack = false
                    }
                }
                if (velocityInput2) {
                    if (mc.thePlayer!!.onGround && mc.thePlayer!!.hurtTime == 9) {
                        if (jumped > 2) {
                            jumped = 0
                        } else {
                            ++jumped
                            if (mc.thePlayer!!.ticksExisted % 5 != 0) mc.gameSettings.keyBindJump.pressed = true
                        }
                    } else if (mc.thePlayer!!.hurtTime == 8) {
                        mc.gameSettings.keyBindJump.pressed = mc.gameSettings.isKeyDown(mc.gameSettings.keyBindJump)
                        velocityInput = false
                    }
                }
                if (mc.thePlayer!!.hurtTime == 0){
                    //reset
                    if (cpsbypass.get()) {
                        aura.minCpsValue.set(11)
                        aura.maxCpsValue.set(14)
                    }
                    if(!sca.state) mc.gameSettings.keyBindJump.pressed = mc.gameSettings.isKeyDown(mc.gameSettings.keyBindJump)
                }
            }
            "grimcombat" -> {
                if (velocityInput) {
                    if (mc.thePlayer!!.onGround && mc.thePlayer!!.hurtTime == 9) {
                        if (jumped > 2) {
                            jumped = 0
                        } else {
                            ++jumped
                            if (mc.thePlayer!!.ticksExisted % 5 != 0) mc.gameSettings.keyBindJump.pressed = true
                        }
                    } else if (mc.thePlayer!!.hurtTime == 8) {
                        mc.gameSettings.keyBindJump.pressed = mc.gameSettings.isKeyDown(mc.gameSettings.keyBindJump)
                        velocityInput = false
                    }
                    if (attack) {
                        attack = false
                        mc.thePlayer!!.motionX *= 0.077760000
                        mc.thePlayer!!.motionZ *= 0.077760000
                        velocityInput = false
                    }
                }
                if (mc.thePlayer!!.hurtTime == 0){
                    if(!sca.state) mc.gameSettings.keyBindJump.pressed = mc.gameSettings.isKeyDown(mc.gameSettings.keyBindJump)
                }
            }
            "smart" -> {
                //Jump res
                if (velocityInput) {
                    if (mc.thePlayer!!.onGround && mc.thePlayer!!.hurtTime == 9) {
                        if (jumped > 2) {
                            jumped = 0
                        } else {
                            ++jumped
                            if (mc.thePlayer!!.ticksExisted % 5 != 0) mc.gameSettings.keyBindJump.pressed = true
                        }
                    } else if (mc.thePlayer!!.hurtTime == 8) {
                        mc.gameSettings.keyBindJump.pressed = mc.gameSettings.isKeyDown(mc.gameSettings.keyBindJump)
                        velocityInput = false
                    }
                }
                //Delaymotionreduce
                if (velocityInput2 && velocityTimer.hasTimePassed(msValue.get().toLong())) {
                    if (!doinrange && onlyinRange.get()) return
                    thePlayer.motionX *= horizontalValue.get()
                    thePlayer.motionZ *= horizontalValue.get()
                    thePlayer.motionY *= verticalValue.get()
                    velocityInput2 = false
                }
                //Bypass all ac
                if (mc.thePlayer!!.hurtTime>0){
                    mc.thePlayer!!.motionX += -1.0E-7
                    mc.thePlayer!!.motionY += -1.0E-7
                    mc.thePlayer!!.motionZ += -1.0E-7
                    mc.thePlayer!!.isAirBorne = true
                }
                //Air reduce
                if(!mc.thePlayer!!.onGround && mc.thePlayer!!.hurtTime > 0 && mc.thePlayer!!.hurtTime <=5 && velocityInput3){
                    if (!doinrange && onlyinRange.get()) return
                    mc.thePlayer!!.motionX *= airReducerValue.get()
                    mc.thePlayer!!.motionZ *= airReducerValue.get()
                    velocityInput3 = false
                }
                //LegitPush
                if (!legitPush.get()) return
                if(mc.thePlayer!!.onGround && mc.thePlayer!!.hurtTime == 0){
                    x = mc.thePlayer!!.posX
                    z = mc.thePlayer!!.posZ
                }else if(!mc.thePlayer!!.onGround && mc.thePlayer!!.hurtTime == 5) {
                    d1 = mc.thePlayer!!.posX - x
                    d2 = mc.thePlayer!!.posZ - z
                    pushtick = 5
                }
                if (!doinrange && onlyinRange.get()) return
                if(pushtick>0){
                    mc.thePlayer!!.motionX -= (d1 * pushValue.get())
                    mc.thePlayer!!.motionZ -= (d2 * pushValue.get())
                    pushtick--
                }
            }
            "hytpit" -> {
                //jump res
                if (velocityInput) {
                    if (mc.thePlayer!!.onGround && mc.thePlayer!!.hurtTime == 9 && mc.thePlayer!!.sprinting && mc.currentScreen == null) {
                        if (jumped > 2) {
                            jumped = 0
                        } else {
                            ++jumped
                            if (mc.thePlayer!!.ticksExisted % 5 != 0) mc.gameSettings.keyBindJump.pressed = true
                        }
                    } else if (mc.thePlayer!!.hurtTime == 8) {
                        mc.gameSettings.keyBindJump.pressed = mc.gameSettings.isKeyDown(mc.gameSettings.keyBindJump)
                        velocityInput = false
                    }
                }
            }
            "glitch" -> {
                thePlayer.noClip = velocityInput

                if (thePlayer.hurtTime == 7)
                    thePlayer.motionY = 0.4

                velocityInput = false
            }

            "reverse" -> {
                if (!velocityInput)
                    return

                if (!thePlayer.onGround) {
                    MovementUtils.strafe(MovementUtils.speed * reverseStrengthValue.get())
                } else if (velocityTimer.hasTimePassed(80L))
                    velocityInput = false
            }

            "smoothreverse" -> {
                if (!velocityInput) {
                    thePlayer.speedInAir = 0.02F
                    return
                }

                if (thePlayer.hurtTime > 0)
                    reverseHurt = true

                if (!thePlayer.onGround) {
                    if (reverseHurt)
                        thePlayer.speedInAir = reverse2StrengthValue.get()
                } else if (velocityTimer.hasTimePassed(80L)) {
                    velocityInput = false
                    reverseHurt = false
                }
            }

            "aac" -> if (velocityInput){
                if (velocityTimer.hasTimePassed(80L)) {
                    thePlayer.motionX *= horizontalValue.get()
                    thePlayer.motionZ *= horizontalValue.get()
                    thePlayer.motionY *= verticalValue.get()
                }
                if(mc.thePlayer!!.onGround) { if (mc.thePlayer!!.sprinting) mc.thePlayer!!.jump()
                }else{
                    mc.thePlayer!!.motionX += -1.0E-7
                    mc.thePlayer!!.motionY += -1.0E-7
                    mc.thePlayer!!.motionZ += -1.0E-7
                    mc.thePlayer!!.isAirBorne = true
                }
                velocityInput = false
            }

            "aacpush" -> {
                if (jump) {
                    if (thePlayer.onGround)
                        jump = false
                } else {
                    // Strafe
                    if (thePlayer.hurtTime > 0 && thePlayer.motionX != 0.0 && thePlayer.motionZ != 0.0)
                        thePlayer.onGround = true
                }

                // Reduce XZ
                if (thePlayer.hurtResistantTime >= 19) {
                    val reduce = aacPushXZReducerValue.get()

                    thePlayer.motionX /= reduce
                    thePlayer.motionZ /= reduce
                }
            }
            "aaczero" -> if (thePlayer.hurtTime > 0) {
                if (!velocityInput || thePlayer.onGround || thePlayer.fallDistance > 2F)
                    return

                thePlayer.motionY -= 1.0
                thePlayer.isAirBorne = true
                thePlayer.onGround = true
            } else
                velocityInput = false
        }
    }

    @EventTarget
    fun onPacket(event: PacketEvent) {

        val thePlayer = mc.thePlayer ?: return

        val packet = event.packet.unwrap()
        val killAura = Client.moduleManager[KillAura::class.java] as KillAura
        val silentmode = Client.moduleManager[StrafeFix::class.java] as StrafeFix

        if (thePlayer.isInWater || thePlayer.isInLava || thePlayer.isInWeb || !thePlayer.isInsideOfMaterial(classProvider.getMaterialEnum(
                MaterialType.AIR)) )
            return

        if (packet is SPacketEntityVelocity) {

            if ((mc.theWorld?.getEntityByID(packet.entityID) ?: return) != thePlayer)
                return

            velocityTimer.reset()

            if(wtapreduce.get()) mc.gameSettings.keyBindForward.pressed = false

            if (stapreduce.get()){
                mc.thePlayer!!.sprinting = false
            }
            val target = Client.combatManager.getNearByEntity(3F) ?: return

            if (attackValue.get()){
                repeat(attacktimes.get()) {
                    mc.thePlayer!!.sendQueue.addToSendQueue(
                        classProvider.createCPacketUseEntity(
                            target,
                            ICPacketUseEntity.WAction.ATTACK
                        )
                    )
                    mc.thePlayer!!.sendQueue.addToSendQueue(classProvider.createCPacketAnimation())
                }
            }

            when (modeValue.get().toLowerCase()) {
                "click" -> {
                    if (packet.motionX == 0 && packet.motionZ == 0) return
                    if (attackRayTrace(
                            clickCount.get(),
                            clickRange.get().toDouble(),
                            clickOnPacket.get() && mc.thePlayer!!.sprinting
                        )
                    )
                        velocityInput = true
                }
                "noxz"-> {
                    velocityInput = true
                    velocityInput2 = true
                    if (mc.thePlayer!!.onGround){
                        mc.gameSettings.keyBindJump.pressed = true
                    }
                    if (cpsbypass.get()) {
                        killAura.minCpsValue.set(8)
                        killAura.maxCpsValue.set(8)
                    }
                    if (killAura.state && killAura.currentTarget != null && mc.thePlayer!!.getDistanceToEntityBox(killAura.currentTarget!!) <= 3.01 && !silentmode.state) {
                        //是否疾跑
                        if (mc.thePlayer!!.movementInput.moveForward > 0.9f && mc.thePlayer!!.sprinting && mc.thePlayer!!.serverSprintState) {
                            repeat(5) {
                                mc2.connection!!.sendPacket(CPacketConfirmTransaction(100, 100, true))
                                mc.thePlayer!!.sendQueue.addToSendQueue(
                                    classProvider.createCPacketUseEntity(
                                        killAura.currentTarget!!,
                                        ICPacketUseEntity.WAction.ATTACK
                                    )
                                )
                                mc.thePlayer!!.sendQueue.addToSendQueue(classProvider.createCPacketAnimation())
                            }
                            if (thePlayer.isCollidedHorizontally && noblock.get() && !thePlayer.isOnLadder && !thePlayer.isInWater && !thePlayer.isInLava) return
                            if (changesource.get()) {
                                packet.motionX = ((0.077760000 * 8000).toInt())
                                packet.motionZ = ((0.077760000 * 8000).toInt())
                            }
                            attack = true
                            if (debug.get()) {
                                ClientUtils.displayChatMessage("§8[§c§lCatBounce§8]§b§ddoattack normal")
                            }
                        } else {
                            if (mc.thePlayer!!.movementInput.moveForward > 0.9f) {
                                repeat(5) {
                                    mc2.connection!!.sendPacket(CPacketConfirmTransaction(100, 100, true))
                                    mc2.connection!!.networkManager.sendPacket(
                                        CPacketEntityAction(
                                            mc2.player,
                                            CPacketEntityAction.Action.START_SPRINTING
                                        )
                                    )
                                    mc.thePlayer!!.sendQueue.addToSendQueue(
                                        classProvider.createCPacketUseEntity(
                                            killAura.currentTarget!!,
                                            ICPacketUseEntity.WAction.ATTACK
                                        )
                                    )
                                    mc.thePlayer!!.sendQueue.addToSendQueue(classProvider.createCPacketAnimation())
                                }
                                if (thePlayer.isCollidedHorizontally && noblock.get() && !thePlayer.isOnLadder && !thePlayer.isInWater && !thePlayer.isInLava) return
                                if (changesource.get()) {
                                    packet.motionX = ((0.077760000 * 8000).toInt())
                                    packet.motionZ = ((0.077760000 * 8000).toInt())
                                }
                                attack = true
                                if (debug.get()) {
                                    ClientUtils.displayChatMessage("§8[§c§lCatBounce§8]§b§ddoattack sprint")
                                }
                            }
                        }
                    } else if (killAura.state && killAura.currentTarget != null && mc.thePlayer!!.getDistanceToEntityBox(killAura.currentTarget!!) <= 3.01 && !silentmode.state) {
                        //是否疾跑
                        if (mc.thePlayer!!.movementInput.moveForward > 0.9f && mc.thePlayer!!.sprinting && mc.thePlayer!!.serverSprintState) {
                            repeat(5) {
                                mc2.connection!!.sendPacket(CPacketConfirmTransaction(100, 100, true))
                                mc.thePlayer!!.sendQueue.addToSendQueue(
                                    classProvider.createCPacketUseEntity(
                                        killAura.currentTarget!!,
                                        ICPacketUseEntity.WAction.ATTACK
                                    )
                                )
                                mc.thePlayer!!.sendQueue.addToSendQueue(classProvider.createCPacketAnimation())
                            }
                            if (thePlayer.isCollidedHorizontally && noblock.get() && !thePlayer.isOnLadder && !thePlayer.isInWater && !thePlayer.isInLava) return
                            if (changesource.get()) {
                                packet.motionX = ((0.077760000 * 8000).toInt())
                                packet.motionZ = ((0.077760000 * 8000).toInt())
                            }
                            attack = true
                            if (debug.get()) {
                                ClientUtils.displayChatMessage("§8[§c§lCatBounce§8]§b§ddoattack normal")
                            }
                        } else {
                            if (mc.thePlayer!!.movementInput.moveForward > 0.9f) {
                                repeat(5) {
                                    mc2.connection!!.sendPacket(CPacketConfirmTransaction(100, 100, true))
                                    mc2.connection!!.networkManager.sendPacket(
                                        CPacketEntityAction(
                                            mc2.player,
                                            CPacketEntityAction.Action.START_SPRINTING
                                        )
                                    )
                                    mc.thePlayer!!.sendQueue.addToSendQueue(
                                        classProvider.createCPacketUseEntity(
                                            killAura.currentTarget!!,
                                            ICPacketUseEntity.WAction.ATTACK
                                        )
                                    )
                                    mc.thePlayer!!.sendQueue.addToSendQueue(classProvider.createCPacketAnimation())
                                }
                                if (thePlayer.isCollidedHorizontally && noblock.get() && !thePlayer.isOnLadder && !thePlayer.isInWater && !thePlayer.isInLava) return
                                if (changesource.get()) {
                                    packet.motionX = ((0.077760000 * 8000).toInt())
                                    packet.motionZ = ((0.077760000 * 8000).toInt())
                                }
                                attack = true
                                if (debug.get()) {
                                    ClientUtils.displayChatMessage("§8[§c§lCatBounce§8]§b§ddoattack sprint")
                                }
                            }
                        }
                    }
                }
                "smart" -> {
                    velocityInput = true
                    pos = WBlockPos(mc.thePlayer!!.posX, mc.thePlayer!!.posY, mc.thePlayer!!.posZ)
                    if (mc.thePlayer!!.onGround && (packet.motionX <= 3600 && packet.motionY <= 3600 && packet.motionZ <= 3600)) {
                        if (Auto.get()){
                            if (packet.motionX <= 2800 && packet.motionY <= 2800 && packet.motionZ <= 2800){
                                horizontalValue.set(0.4f)
                            }else if (packet.motionX <= 3000 && packet.motionY <= 3000 && packet.motionZ <= 3000){
                                horizontalValue.set(0.55f)
                            }else if(packet.motionX <= 3200 && packet.motionY <= 3200 && packet.motionZ <= 3200 ){
                                horizontalValue.set(0.65f)
                            }else if(packet.motionX <= 3400 && packet.motionY <= 3400 && packet.motionZ <= 3400){
                                horizontalValue.set(0.74f)
                            }else{
                                horizontalValue.set(0.79f)
                            }
                        }
                        velocityInput2 = true
                    }
                }
                "simple" -> {
                    val horizontal = horizontalValue.get()
                    val vertical = verticalValue.get()

                    packet.motionX = (packet.motionX * horizontal).toInt()
                    packet.motionY = (packet.motionY * vertical).toInt()
                    packet.motionZ = (packet.motionZ * horizontal).toInt()
                }

                "grimcombat"  -> {
                    velocityInput = true
                    if (mc.thePlayer!!.onGround){
                        mc.gameSettings.keyBindJump.pressed = true
                    }
                    for (entity in mc.theWorld!!.loadedEntityList) {
                        if ( mc.thePlayer!!.getDistanceToEntity(entity) < 3.01 && mc.thePlayer!!.movementInput.moveForward > 0.0f && entity.unwrap() !is EntityLivingBase && entity.entityId != mc.thePlayer!!.entityId && RotationUtils.getRotationDifference(entity) <= 90f) {
                            repeat(5) {

                                mc2.connection!!.networkManager.sendPacket(CPacketEntityAction(mc2.player, CPacketEntityAction.Action.START_SPRINTING))
                                mc.thePlayer!!.sendQueue.addToSendQueue((classProvider.createCPacketUseEntity(entity, ICPacketUseEntity.WAction.ATTACK) as IPacket))
                                mc.thePlayer!!.sendQueue.addToSendQueue(classProvider.createCPacketAnimation())
                            }
                            attack = true
                        }
                    }
                }

                "aac", "reverse", "smoothreverse", "aaczero","hytpit" -> velocityInput = true

                "glitch" -> {
                    if (!thePlayer.onGround)
                        return

                    velocityInput = true
                    event.cancelEvent()
                }
            }
        }
    }

    @EventTarget
    fun onJump(event: JumpEvent) {
        val thePlayer = mc.thePlayer
        jumps = 0
        if (thePlayer == null || thePlayer.isInWater || thePlayer.isInLava || thePlayer.isInWeb)
            return

        when (modeValue.get().toLowerCase()) {
            "aacpush" -> {
                jump = true

            }
            "aaczero" -> if (thePlayer.hurtTime > 0)
                event.cancelEvent()
        }

    }

    private fun getMoveYaw(): Float {
        var moveYaw = mc.thePlayer!!.rotationYaw
        if (mc.thePlayer!!.moveForward != 0F && mc.thePlayer!!.moveStrafing == 0F) {
            moveYaw += if(mc.thePlayer!!.moveForward > 0) 0 else 180
        } else if (mc.thePlayer!!.moveForward != 0F && mc.thePlayer!!.moveStrafing != 0F) {
            if (mc.thePlayer!!.moveForward > 0) {
                moveYaw += if (mc.thePlayer!!.moveStrafing > 0) -45 else 45
            } else {
                moveYaw -= if (mc.thePlayer!!.moveStrafing > 0) -45 else 45
            }
            moveYaw += if(mc.thePlayer!!.moveForward > 0) 0 else 180
        } else if (mc.thePlayer!!.moveStrafing != 0F && mc.thePlayer!!.moveForward == 0F) {
            moveYaw += if(mc.thePlayer!!.moveStrafing > 0) -90 else 90
        }
        return moveYaw
    }

    fun attackRayTrace(attack: Int, range: Double, doAttack: Boolean=true): Boolean {
        if (mc.thePlayer == null) return false
        val raycastedEntity = RaycastUtils.raycastEntity(range + 1, object : RaycastUtils.EntityFilter {
            override fun canRaycast(entity: IEntity?): Boolean {
                return entity != null && entity is EntityLivingBase
            }

        })


        raycastedEntity?.let {
            if (it !is EntityPlayer) return true
            if (doAttack) {
                Client.eventManager.callEvent(AttackEvent(it))
                repeat(attack) { _ ->
                    if (clickSwing.get()) mc.thePlayer!!.swingItem()
                    else mc.netHandler.addToSendQueue(classProvider.createCPacketAnimation())
                    mc.netHandler.addToSendQueue(classProvider.createCPacketUseEntity(it, ICPacketUseEntity.WAction.ATTACK))
                }
                mc.thePlayer!!.attackTargetEntityWithCurrentItem(it)
            }
            return true
        }
        return false
    }
}
