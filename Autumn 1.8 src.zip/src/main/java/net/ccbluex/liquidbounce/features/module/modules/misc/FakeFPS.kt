package net.ccbluex.liquidbounce.features.module.modules.misc

import net.ccbluex.liquidbounce.event.EventTarget
import net.ccbluex.liquidbounce.event.WorldEvent
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.utils.misc.RandomUtils
import net.ccbluex.liquidbounce.value.IntegerValue
import net.minecraft.client.Minecraft

@ModuleInfo(name = "MemoryFix", description = "", category = ModuleCategory.MISC, array = false, Chinese = "MemoryFix")
class FakeFPS : Module() {

    override fun onEnable() {
        Runtime.getRuntime().gc()
    }
    @EventTarget
    fun onWorld(event: WorldEvent) {
        Runtime.getRuntime().gc()
    }
}