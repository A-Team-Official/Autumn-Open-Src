package net.ccbluex.liquidbounce.features.module.modules.combat;


import net.ccbluex.liquidbounce.event.EventTarget
import net.ccbluex.liquidbounce.event.PacketEvent
import net.ccbluex.liquidbounce.event.UpdateEvent
import net.ccbluex.liquidbounce.event.WorldEvent
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.injection.backend.unwrap
import net.minecraft.client.Minecraft
import net.minecraft.network.Packet
import net.minecraft.network.play.INetHandlerPlayClient
import net.minecraft.network.play.client.CPacketCustomPayload
import net.minecraft.network.play.client.CPacketEntityAction
import net.minecraft.network.play.client.CPacketPlayer
import net.minecraft.network.play.client.CPacketPlayerAbilities
import net.minecraft.network.play.server.*
import java.util.*
import java.util.concurrent.LinkedBlockingQueue

@ModuleInfo(name = "GrimVelocity", Chinese = "",description = "Grim", category = ModuleCategory.COMBAT)
class NMSL :Module() {
    val resetPersec = 8;
    var grimTCancel = 0;
    var updates = 0;
    val cancelPacket = 6;
    private val inBus = LinkedList<Packet<INetHandlerPlayClient>>()


    override fun onEnable() {
        grimTCancel = 0;
        inBus.clear();
    }

    override fun onDisable() {
        grimTCancel = 0;
        inBus.clear();

    }

    @EventTarget
    fun onUpdate(event:UpdateEvent){
        updates++;
        if (resetPersec > 0) {
            if (updates >= 0) {
                updates = 0;
                if (grimTCancel > 0) {
                    grimTCancel--;
                }
            }
        }
        if(Minecraft.getMinecraft().getConnection() == null) return;

        while (!inBus.isEmpty() && grimTCancel == 0)
            inBus.poll().processPacket(Minecraft.getMinecraft().getConnection());
    };

    @EventTarget
    fun  onWorld(event: WorldEvent) {
        grimTCancel = 0;
        inBus.clear();
    };

    @EventTarget
    fun  onPacket(event: PacketEvent) {
        val packet = event.packet.unwrap()
        if (mc.thePlayer == null) return;
        if (mc.theWorld == null) return;
        if (mc2.player.isDead) return;

        if (packet is SPacketEntityVelocity && packet.entityID == mc.thePlayer!!.entityId) {
            event.cancelEvent();
            grimTCancel = cancelPacket;
        }
        if (packet is SPacketExplosion) {
            event.cancelEvent();
            grimTCancel = cancelPacket;
        }

        if (grimTCancel > 0 && (packet::class.java.simpleName.startsWith("S",true))) {
            if (packet is SPacketSpawnGlobalEntity || packet is SPacketSpawnExperienceOrb || packet is SPacketSpawnObject || packet is SPacketSpawnPainting || packet is SPacketSpawnPosition || packet is SPacketSpawnMob || packet is SPacketSpawnPlayer || (packet is SPacketPlayerPosLook) || (packet is SPacketUpdateTileEntity)
                || packet is SPacketUpdateHealth || packet is SPacketStatistics ||  packet is SPacketPlayerAbilities || packet is SPacketCustomPayload
                || packet is SPacketBlockBreakAnim || packet is SPacketBlockAction || packet is SPacketBlockChange || packet is SPacketMultiBlockChange
            ) {
                return
            }
            if ((packet is SPacketEntityVelocity && (mc.theWorld?.getEntityByID(packet.entityID)
                    ?: return) == mc2.player)
            ) {
                return
            }
            event.cancelEvent();

            inBus.add(packet as Packet<INetHandlerPlayClient>)
        }
    };
}