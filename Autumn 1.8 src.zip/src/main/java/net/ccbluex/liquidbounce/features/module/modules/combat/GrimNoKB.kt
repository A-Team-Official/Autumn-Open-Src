

package net.ccbluex.liquidbounce.features.module.modules.combat

import net.ccbluex.liquidbounce.event.*
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.injection.backend.unwrap
import net.ccbluex.liquidbounce.utils.C08PacketPlayerBlockPlacement
import net.ccbluex.liquidbounce.utils.PacketUtils
import net.ccbluex.liquidbounce.value.BoolValue
import net.ccbluex.liquidbounce.value.IntegerValue
import net.minecraft.block.BlockSlab
import net.minecraft.entity.player.EntityPlayer
import net.minecraft.item.ItemBlock
import net.minecraft.item.ItemStack
import net.minecraft.network.play.client.CPacketHeldItemChange
import net.minecraft.network.play.client.CPacketPlayerDigging
import net.minecraft.network.play.client.CPacketPlayerTryUseItemOnBlock
import net.minecraft.network.play.server.SPacketEntityVelocity
import net.minecraft.network.play.server.SPacketPlayerPosLook
import net.minecraft.util.EnumFacing
import net.minecraft.util.EnumHand
import net.minecraft.util.math.BlockPos


@ModuleInfo("GrimNoKB", Chinese = "", description = "优化版", category =ModuleCategory.COMBAT)
class GrimNoKB : Module() {


    val newGrimTicks: IntegerValue = IntegerValue("NewGrimTicks", 1, 1, 10)
    val deBug: BoolValue = BoolValue("DeBug",  true)
    private var tick = 0
    private var autoDis = 0


    override fun onDisable() {
        mc.timer.timerSpeed = 1f
    }


    @EventTarget
    fun onPacket(event: PacketEvent) {
        if (autoDis > 0) {
            autoDis--
            return
        }

        val packet = event.packet.unwrap()
        if (packet is SPacketEntityVelocity && packet.entityID == mc.thePlayer!!.entityId) {
            event.cancelEvent()
            tick = newGrimTicks.get()

        }
        if (packet is SPacketPlayerPosLook) {
            autoDis = 6
        }

    }

    private fun isPlayerOnSlab(player: EntityPlayer): Boolean {
        val playerPos = BlockPos(player.posX, player.posY, player.posZ)

        val block = player.entityWorld.getBlockState(playerPos).block
        val boundingBox = player.entityBoundingBox

        return block is BlockSlab && player.posY - playerPos.y <= boundingBox.minY + 0.1
    }

    @EventTarget
    fun onUpdate(event: UpdateEvent) {
        if (autoDis > 0) {
            return
        }
        if (tick > 0) {
            tick--
            if (mc.thePlayer!!.onGround) { // 只有玩家在地面时才执行以下操作
                val blockPos = BlockPos(mc.thePlayer!!.posX, mc.thePlayer!!.posY + 0.9999999, mc.thePlayer!!.posZ)
                val facing = EnumFacing.UP
                val packet = CPacketPlayerTryUseItemOnBlock(blockPos, EnumFacing.UP,EnumHand.MAIN_HAND,0F, 0F, 0F)
                PacketUtils.sendPacketNoEvent(packet)

                val c07PacketPlayerDigging = CPacketPlayerDigging(
                    CPacketPlayerDigging.Action.ABORT_DESTROY_BLOCK,
                    BlockPos.ORIGIN,
                    EnumFacing.DOWN
                )
                PacketUtils.sendPacketNoEvent(c07PacketPlayerDigging)
                val heldItem: ItemStack = mc2.player.heldItemMainhand
                if (heldItem != null && heldItem.item is ItemBlock) {
                    val heldItemChange = CPacketHeldItemChange(mc2.player.inventory.currentItem % 8 + 1)
                    PacketUtils.sendPacketNoEvent(heldItemChange)
                }

            } else {
                mc.thePlayer!!.rotationYaw += 180
                mc.thePlayer!!.motionX *= 0.31415926
                mc.thePlayer!!.motionY *= 0.31415926
                mc.thePlayer!!.motionZ *= 0.31415926
            }
        }

    }
}