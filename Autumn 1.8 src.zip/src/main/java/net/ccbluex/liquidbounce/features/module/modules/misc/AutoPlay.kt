package net.ccbluex.liquidbounce.features.module.modules.misc

import cn.client.novoline.ui.InfosUtils.Recorder
import net.ccbluex.liquidbounce.Client
import net.ccbluex.liquidbounce.event.EventTarget
import net.ccbluex.liquidbounce.event.PacketEvent
import net.ccbluex.liquidbounce.event.WorldEvent
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.features.module.modules.combat.AutoArmor
import net.ccbluex.liquidbounce.features.module.modules.combat.GrimVelocity2
import net.ccbluex.liquidbounce.features.module.modules.combat.KillAura
import net.ccbluex.liquidbounce.features.module.modules.exploit.Clip
import net.ccbluex.liquidbounce.features.module.modules.player.InventoryCleaner
import net.ccbluex.liquidbounce.features.module.modules.world.ChestAura
import net.ccbluex.liquidbounce.features.module.modules.world.ChestStealer
import net.ccbluex.liquidbounce.injection.backend.unwrap
import net.ccbluex.liquidbounce.ui.client.hud.element.elements.AutoPlayHuds
import net.ccbluex.liquidbounce.ui.client.hud.element.elements.Notification
import net.ccbluex.liquidbounce.ui.client.hud.element.elements.Notification.NotifyType
import net.ccbluex.liquidbounce.utils.item.ItemHelper
import net.ccbluex.liquidbounce.value.BoolValue
import net.ccbluex.liquidbounce.value.IntegerValue
import net.ccbluex.liquidbounce.value.ListValue
import net.minecraft.entity.Entity
import net.minecraft.entity.player.EntityPlayer
import net.minecraft.network.play.client.CPacketClickWindow
import net.minecraft.network.play.client.CPacketPlayerDigging
import net.minecraft.network.play.server.SPacketChat
import net.minecraft.network.play.server.SPacketOpenWindow
import java.util.*
import java.util.regex.Pattern
import kotlin.concurrent.schedule

@ModuleInfo(name = "AutoPlay", category = ModuleCategory.PLAYER,description = "e", Chinese = "自动游玩")
class AutoPlay : Module() {
    private var clickState = 0
    private val modeValue = ListValue("Server", arrayOf("RedeSky", "Minemora", "HuaYuTingGG","HuaYuTingSw","HuaYuTing16"), "HuaYuTingGG")
    private val ClientName = BoolValue("Clientname",true)
    private val autodis = BoolValue("Auto-Disable",true)
    val delayValue = IntegerValue("JoinDelay", 3, 0, 7)
    private val playerwarn = BoolValue("PlayerWarning",true)
    private val postcheck = BoolValue("postcheck",true)

    var flaggedEntity = ArrayList<Entity?>()
    var flaggedEntity2 = ArrayList<Entity?>()

    private var clicking = false
    private var queued = false
    override fun onEnable() {
        clickState = 0
        clicking = false
        queued = false
    }



    @EventTarget
    fun onPacket(event: PacketEvent) {
        val packet = event.packet.unwrap()

        when (modeValue.get().toLowerCase()) {
            "huayutingsw"->{
                if (playerwarn.get()) {
                    for (targets in mc2.world.loadedEntityList) {
                        if (targets is EntityPlayer && targets != mc2.player) {
                            if (ItemHelper.isHoldingGodAxe(targets) && !flaggedEntity.contains(targets)) {
                                flaggedEntity.add(targets)
                                Client.hud.addNotification(
                                    Notification(
                                        "AutoPlay",
                                        "!!!${targets.name}是秒人斧", NotifyType.INFO, ModuleCategory.MISC, 8000
                                    )
                                )

                            }
                            if (ItemHelper.isHoldingEnchantedGoldenApple(targets) && !flaggedEntity.contains(targets)) {
                                flaggedEntity.add(targets)
                                Client.hud.addNotification(
                                    Notification(
                                        "AutoPlay",
                                        "!!!${targets.name}有附魔金苹果", NotifyType.INFO, ModuleCategory.MISC, 8000
                                    )
                                )

                            }
                            if (ItemHelper.isRegen(targets) > 0 && !flaggedEntity2.contains(targets)) {
                                flaggedEntity2.add(targets)
                                Client.hud.addNotification(
                                    Notification(
                                        "AutoPlay",
                                        "!!!${targets.name}有人在生命恢复", NotifyType.INFO, ModuleCategory.MISC, 8000
                                    )
                                )

                            }
                        }
                    }
                }
            }
            "redesky" -> {
                if (clicking && (packet is CPacketClickWindow || packet is CPacketPlayerDigging)) {
                    event.cancelEvent()
                    return
                }
                if (clickState == 2 && packet is SPacketOpenWindow) {
                    event.cancelEvent()
                }
            }
            "hypixel" -> {
                if (clickState == 1 && packet is SPacketOpenWindow) {
                    event.cancelEvent()
                }
            }
        }
        val GrimVel = Client.moduleManager.getModule(GrimVelocity2::class.java) as GrimVelocity2
        val KillAura = Client.moduleManager.getModule(KillAura::class.java) as KillAura
        val ChestStealer = Client.moduleManager.getModule(ChestStealer::class.java) as ChestStealer
        val ChestAura = Client.moduleManager.getModule(ChestAura::class.java) as ChestAura
        val InventoryCleaner = Client.moduleManager.getModule(InventoryCleaner::class.java) as InventoryCleaner
        val AutoArmor = Client.moduleManager.getModule(AutoArmor::class.java) as AutoArmor
        if (packet is SPacketChat) {
            val text = packet.chatComponent.unformattedText
            when (modeValue.get().toLowerCase()) {
                "minemora" -> {
                    if (text.contains("Has click en alguna de las siguientes opciones", true)) {
                        queueAutoPlay {
                            mc.thePlayer!!.sendChatMessage("/join")
                            Recorder.win++
                        }
                    }
                }
                "huayutinggg" -> {

                    if (text.contains("      喜欢      一般      不喜欢", true)) {
                        Client.hud.addNotification(Notification(name,"Send you to next Game", NotifyType.INFO))
                        if (ClientName.get()){mc.thePlayer!!.sendChatMessage("@["+Client.CLIENT_NAME+"]GG")}
                        else{mc.thePlayer!!.sendChatMessage("@GG")}
                        if (autodis.get()) {
                            KillAura.state = false
                        }
                        Recorder.win++

                        Client.hud.addAutoPlayHud(AutoPlayHuds("你赢得了本场游戏胜利 | 胜利数:"+ Recorder.win,net.ccbluex.liquidbounce.ui.client.hud.element.elements.NotifyType.INFO))
                        Client.hud.addNotification(Notification("Warning","KillAura was disabled, because game has ended", NotifyType.WARNING))

                    }
                }
                "huayutingsw" -> {
                    val matcher = Pattern.compile("你在地图 (.*?)\\(").matcher(packet.chatComponent.unformattedText)
                    if (text.contains("你现在是观察者状态. 按E打开菜单.", true)) {
                        val diabler = Client.moduleManager[Clip::class.java] as Clip
                        if (!diabler.getnewpostdis() && postcheck.get()) {
                            diabler.topacket()
                        }
                        KillAura.state = false
                        ChestStealer.state = false
                        InventoryCleaner.state = false
                        ChestAura.state = false
                        AutoArmor.state = false
                        Recorder.win++

                        Client.hud.addAutoPlayHud(AutoPlayHuds("你赢得了本场游戏胜利 | 胜利数:"+ Recorder.win,net.ccbluex.liquidbounce.ui.client.hud.element.elements.NotifyType.INFO))
                        Client.hud.addNotification(Notification("AutoPlay","Game Over", NotifyType.INFO, ModuleCategory.MISC,1000))
                        if (ClientName.get()){mc.thePlayer!!.sendChatMessage("@["+Client.CLIENT_NAME+"]GG")}
                        else{mc.thePlayer!!.sendChatMessage("@GG")}
                    }
                }
                "huayuting16" -> {
                    if (text.contains("[起床战争] Game 结束！感谢您的参与！", true)) {
                        Client.hud.addNotification(Notification(name,"Game Over", NotifyType.INFO))
                        Client.hud.addNotification(Notification("Warning","KillAura was disabled, because game has ended", NotifyType.WARNING))
                        if (ClientName.get()){
                            mc.thePlayer!!.sendChatMessage("@["+Client.CLIENT_NAME+"]GG")}
                        else{mc.thePlayer!!.sendChatMessage("@GG")}
                        Recorder.win++

                        Client.hud.addAutoPlayHud(AutoPlayHuds("你赢得了本场游戏胜利 | 胜利数:"+ Recorder.win.toString(),net.ccbluex.liquidbounce.ui.client.hud.element.elements.NotifyType.INFO))
                        if (autodis.get()) {
                            KillAura.state = false
                        }
                    }
                }
            }
        }
    }

    private fun queueAutoPlay(runnable: () -> Unit) {
        if (queued) {
            return
        }
        queued = true
        if (this.state) {
            Timer().schedule(delayValue.get().toLong() * 1000) {
                if (state) {
                    runnable()
                }
            }

            //play sound when everything done
            Client.hud.addNotification(Notification(name,"Sending you to next game in ${delayValue.get()}s...", NotifyType.INFO))
        }
    }

    @EventTarget
    fun onWorld(event: WorldEvent) {
        clicking = false
        clickState = 0
        queued = false
        flaggedEntity.clear()
        flaggedEntity2.clear()

    }

    override val tag: String
        get() = modeValue.get()

    override fun handleEvents() = true
}
