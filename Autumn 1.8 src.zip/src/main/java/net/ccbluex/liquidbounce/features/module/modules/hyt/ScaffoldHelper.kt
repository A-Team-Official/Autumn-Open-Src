package net.ccbluex.liquidbounce.features.module.modules.hyt

import net.ccbluex.liquidbounce.Client
import net.ccbluex.liquidbounce.event.EventTarget
import net.ccbluex.liquidbounce.event.UpdateEvent
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.features.module.modules.movement.SafeWalk
import net.ccbluex.liquidbounce.features.module.modules.world.Scaffold
import net.ccbluex.liquidbounce.utils.ClientUtils

import net.ccbluex.liquidbounce.utils.MovementUtils
import net.ccbluex.liquidbounce.value.BoolValue
import net.ccbluex.liquidbounce.value.ListValue

@ModuleInfo(name = "ScaffoldHelper", description = "ScaffoldHelper", category = ModuleCategory.HYT, Chinese = "自动搭路助手")
class ScaffoldHelper : Module() {
    //by xiaoyan
    val modeValue = ListValue("Mode", arrayOf("scaffold"), "scaffold")
    val AutoJumpMode = ListValue("AutoJumpMode", arrayOf("packour", "ground","off"), "packour")
    val Rotation = ListValue("KeepRotationMode", arrayOf("lock", "new","off"), "lock")
    val safewalkValue = BoolValue("SafeWalk",true)





    @EventTarget
    fun onUpdate(event: UpdateEvent) {

        val scaffold = Client.moduleManager.getModule(Scaffold::class.java) as Scaffold
        val safeWalk = Client.moduleManager.getModule(SafeWalk::class.java) as SafeWalk
        safeWalk.state = safewalkValue.get()





        when (AutoJumpMode.get().toLowerCase()) {
            "ground" -> {

                if (mc.thePlayer!!.onGround && MovementUtils.isMoving && mc.thePlayer!!.sprinting) {

                    mc.thePlayer!!.jump()
                }
            }
            "packour" -> {
                if (MovementUtils.isMoving && mc.thePlayer!!.onGround && !mc.thePlayer!!.sneaking && !mc.gameSettings.keyBindSneak.isKeyDown && !mc.gameSettings.keyBindJump.isKeyDown && mc.theWorld!!.getCollidingBoundingBoxes(mc.thePlayer!!, mc.thePlayer!!.entityBoundingBox.offset(0.0, -0.5, 0.0).expand(-0.001, 0.0, -0.001)).isEmpty())
                    mc.thePlayer!!.jump()
            }
        }



        when (Rotation.get().toLowerCase()) {
            "new" -> {
                val rotation = net.ccbluex.liquidbounce.utils.Rotation(mc.thePlayer!!.rotationYaw, 23f)
                rotation.toPlayer(mc.thePlayer!!)
                var needNormal = false
                val yaw = mc.thePlayer!!.rotationYaw
                if (yaw >= -22.5 && yaw < 22.5) {
                    // 玩家面朝正
                    needNormal = false
                } else if (yaw >= 22.5 && yaw < 67.5) {
                    // 玩家面朝正西南方
                    needNormal = true
                } else if (yaw >= 67.5 && yaw < 112.5) {
                    // 玩家面朝正西方
                    needNormal = false
                } else if (yaw >= 112.5 && yaw < 157.5) {
                    // 玩家面朝正西北方
                    needNormal = true
                } else if (yaw >= 157.5 || yaw < -157.5) {
                    // 玩家面朝正北方
                    needNormal = false
                } else if (yaw >= -157.5 && yaw < -112.5) {
                    // 玩家面朝正东北方
                    needNormal = true
                } else if (yaw >= -112.5 && yaw < -67.5) {
                    // 玩家面朝正东方
                    needNormal = false
                } else if (yaw >= -67.5 && yaw < -22.5) {
                    // 玩家面朝正东南方
                    needNormal = true
                }


            }


            "lock" -> {
                if (mc.thePlayer!!.motionZ > 0.1) {
                    mc.thePlayer!!.rotationYaw = 0F
                }
                if (mc.thePlayer!!.motionZ < -0.1) {
                    mc.thePlayer!!.rotationYaw = 180F
                }
                if (mc.thePlayer!!.motionX > 0.1) {
                    mc.thePlayer!!.rotationYaw = -90F
                }
                if (mc.thePlayer!!.motionX < -0.1) {
                    mc.thePlayer!!.rotationYaw = 90F
                }
            }
        }


        when (modeValue.get().toLowerCase()) {
            "scaffold" -> {
                scaffold.state = !mc.thePlayer!!.onGround
            }
        }
    }



    override fun onDisable() {
        val scaffold = Client.moduleManager.getModule(Scaffold::class.java) as Scaffold
        val safeWalk = Client.moduleManager.getModule(SafeWalk::class.java) as SafeWalk


        scaffold.state = false
        safeWalk.state = false

    }

}