package net.ccbluex.liquidbounce.features.module.modules.combat;

import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import net.ccbluex.liquidbounce.api.minecraft.client.entity.IEntity;
import net.ccbluex.liquidbounce.api.minecraft.client.entity.IEntityPlayerSP;
import net.ccbluex.liquidbounce.api.minecraft.client.multiplayer.IWorldClient;
import net.ccbluex.liquidbounce.api.minecraft.network.IPacket;
import net.ccbluex.liquidbounce.api.minecraft.network.play.client.ICPacketUseEntity.WAction;
import net.ccbluex.liquidbounce.event.EventTarget;
import net.ccbluex.liquidbounce.event.UpdateEvent;
import net.ccbluex.liquidbounce.features.module.Module;
import net.ccbluex.liquidbounce.features.module.ModuleCategory;
import net.ccbluex.liquidbounce.features.module.ModuleInfo;
import net.ccbluex.liquidbounce.utils.MinecraftInstance;
import net.ccbluex.liquidbounce.utils.RotationUtils;
import net.ccbluex.liquidbounce.utils.timer.MSTimer;
import net.ccbluex.liquidbounce.value.BoolValue;
import net.ccbluex.liquidbounce.value.ListValue;
import org.jetbrains.annotations.NotNull;

@ModuleInfo(name="AntiFireBall",description=":/",Chinese =  "自动防火球", category=ModuleCategory.COMBAT)
@Metadata(mv={1, 1, 16}, bv={1, 0, 3}, k=1, d1={""}, d2={"Lnet/ccbluex/liquidbounce/features/module/modules/combat/AntiFireBall;", "Lnet/ccbluex/liquidbounce/features/module/Module;", "()V", "rotationValue", "Lnet/ccbluex/liquidbounce/value/BoolValue;", "swingValue", "Lnet/ccbluex/liquidbounce/value/ListValue;", "timer", "Lnet/ccbluex/liquidbounce/utils/timer/MSTimer;", "onUpdate", "", "event", "Lnet/ccbluex/liquidbounce/event/UpdateEvent;", "LiquidSense"})
public final class AntiFireBall extends Module
{

    private final ListValue swingValue = new ListValue("Swing", new String[] { "Normal", "Packet", "None" }, "Normal");
    private final BoolValue rotationValue = new BoolValue("Rotation", true);

    private final MSTimer timer = new MSTimer();

    @EventTarget
    public final void onUpdate(@NotNull UpdateEvent event) { Intrinsics.checkParameterIsNotNull(event, "event");
        IWorldClient tmp14_9 = MinecraftInstance.mc.getTheWorld(); if (tmp14_9 == null) Intrinsics.throwNpe(); for (IEntity entity : tmp14_9.getLoadedEntityList())
            if (MinecraftInstance.classProvider.isEntityFireball(entity))
            {
                IEntityPlayerSP tmp71_66 = MinecraftInstance.mc.getThePlayer(); if (tmp71_66 == null) Intrinsics.throwNpe(); if ((tmp71_66.getDistanceToEntity(entity) < 6D) && (this.timer.hasTimePassed(0L))) {
                if (((Boolean)this.rotationValue.get()).booleanValue())
                    RotationUtils.setTargetRotation(RotationUtils.getRotationsNonLivingEntity(entity));
                IEntityPlayerSP tmp136_131 = MinecraftInstance.mc.getThePlayer(); if (tmp136_131 == null) Intrinsics.throwNpe(); tmp136_131.getSendQueue().addToSendQueue((IPacket)MinecraftInstance.classProvider.createCPacketUseEntity(entity, WAction.ATTACK));

                if (Intrinsics.areEqual((String)this.swingValue.get(), "Normal"))
                {
                    IEntityPlayerSP tmp194_189 = MinecraftInstance.mc.getThePlayer(); if (tmp194_189 == null) Intrinsics.throwNpe(); tmp194_189.swingItem();
                } else if (Intrinsics.areEqual((String)this.swingValue.get(), "Packet")) {
                    MinecraftInstance.mc.getNetHandler().addToSendQueue((IPacket)MinecraftInstance.classProvider.createCPacketAnimation());
                }
                this.timer.reset();
                break;
            }
            }
    }
}