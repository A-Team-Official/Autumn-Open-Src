/*
 * LiquidBounce Hacked Client
 * A free open source mixin-based injection hacked client for Minecraft using Minecraft Forge.
 * https://github.com/CCBlueX/LiquidBounce/
 */
package net.ccbluex.liquidbounce.features.module.modules.movement

import net.ccbluex.liquidbounce.Client
import net.ccbluex.liquidbounce.api.enums.WEnumHand
import net.ccbluex.liquidbounce.api.minecraft.item.IItem
import net.ccbluex.liquidbounce.event.*
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.features.module.modules.combat.KillAura
import net.ccbluex.liquidbounce.injection.backend.unwrap
import net.ccbluex.liquidbounce.utils.MSTimer
import net.ccbluex.liquidbounce.utils.MovementUtils
import net.ccbluex.liquidbounce.utils.PacketUtils
import net.ccbluex.liquidbounce.utils.createUseItemPacket
import net.ccbluex.liquidbounce.value.BoolValue
import net.ccbluex.liquidbounce.value.FloatValue
import net.ccbluex.liquidbounce.value.IntegerValue
import net.ccbluex.liquidbounce.value.ListValue
import net.minecraft.block.Block
import net.minecraft.inventory.ClickType
import net.minecraft.item.*
import net.minecraft.network.Packet
import net.minecraft.network.play.INetHandlerPlayServer
import net.minecraft.network.play.client.*
import net.minecraft.network.play.server.SPacketSetSlot
import net.minecraft.network.play.server.SPacketWindowItems
import net.minecraft.util.EnumFacing
import net.minecraft.util.EnumHand
import net.minecraft.util.math.BlockPos
import top.fl0wowp4rty.phantomshield.annotations.Native
import java.util.*
import java.util.concurrent.LinkedBlockingDeque


@ModuleInfo(name = "NoSlow", Chinese = "", description = "Cancels slowness effects caused by soulsand and using items.",
    category = ModuleCategory.MOVEMENT)
@Native
class NoSlow : Module() {

    // Highly customizable values
    private val blockForwardis = FloatValue("BlockForwardis", 1.0F, 0.2F, 1.0F)
    private val blockStrafeis = FloatValue("BlockStrafeis", 1.0F, 0.2F, 1.0F)

    private var consumeForwardis = FloatValue("ConsumeForwardis", 1.0F, 0.2F, 1.0F)
    private val consumeStrafeis = FloatValue("ConsumeStrafeis", 1.0F, 0.2F, 1.0F)

    private val bowForwardis = FloatValue("BowForwardis", 1.0F, 0.2F, 1.0F)

    private val bowStrafeis = FloatValue("BowStrafeis", 1.0F, 0.2F, 1.0F)
    val modeValue = ListValue("Mode", arrayOf("None","Grim","GrimAC","HuaYuTing"),"None")
    private val ciucValue = BoolValue("CheckInUseCount", true)
    private val foodtimer = IntegerValue("foodtimer", 0, 0, 10000)

    // Blocks
    val soulsandValue = BoolValue("Soulsand", true)
    val liquidPushValue = BoolValue("LiquidPush", true)
    private val badPacket = LinkedBlockingDeque<SPacketWindowItems>()
    private val msTimer = MSTimer()
    private var packetBuf2 = LinkedList<SPacketWindowItems>()
    private var packetBuf = LinkedList<Packet<INetHandlerPlayServer>>()
    private var noRev = false
    private var noBlink = false
    private var lastBlockingStat = false
    private var send = false
    private var usefood = false
    private var c08: CPacketPlayerTryUseItem? = null
    private val killAura = Client.moduleManager[KillAura::class.java] as KillAura

    private var slow = false
    override fun onEnable() {
        slow = false
    }
    override fun onDisable() {
        msTimer.reset()
        noBlink = false
        send = false
        noRev = false
        lastBlockingStat = false
        blink()


    }

    private val isBlocking: Boolean
        get() = mc2.player.isHandActive && mc.thePlayer!!.heldItem != null && (mc2.player.heldItemMainhand.item is ItemFood || mc2.player.heldItemMainhand.item is ItemPotion || mc2.player.heldItemMainhand.item is ItemBucketMilk || mc2.player.heldItemMainhand.item is ItemSword)

    private fun sendPacket(
        event: MotionEvent,
        sendC07: Boolean,
        delay: Boolean,
        delayValue: Long,
        onGround: Boolean
    ) {
        val digging = CPacketPlayerDigging(CPacketPlayerDigging.Action.RELEASE_USE_ITEM, BlockPos(-1, -1, -1), EnumFacing.DOWN)
        if (onGround && !mc.thePlayer!!.onGround) {
            return
        }
        if (sendC07 && event.eventState == EventState.PRE) {
            if (delay && msTimer.hasTimePassed(delayValue)) {
                mc2.connection!!.sendPacket(digging)
            } else if (!delay) {
                mc2.connection!!.sendPacket(digging)
            }
        }

    }
    var eatSlow = false

    @EventTarget
    fun onSlowDown(event: SlowDownEvent) {
        val heldItem = mc.thePlayer!!.heldItem?.item
        when(modeValue.get().toLowerCase()){
            "huayuting"->{
                if (!eatSlow || mc2.player.heldItemMainhand.item is ItemSword) {
                    event.cancelEvent()
                }
            }
        }

        event.forward = getis(heldItem, true)
        event.strafe = getis(heldItem, false)
    }
    @EventTarget
    fun OnPacket(event: PacketEvent){
        when (modeValue.get().toLowerCase()) {
            "grim" -> {
                val packet = event.packet.unwrap()
                if (packet is SPacketWindowItems && packet.windowId == 0 && (mc2.player.activeItemStack
                        ?: ItemStack.EMPTY) != ItemStack.EMPTY
                ) {
                    packetBuf2.add(packet)
                    event.cancelEvent()
                    slow = false
                }
            }
        }
    }


    @EventTarget
    fun onMotion(event: MotionEvent) {
        if ((!mc.thePlayer!!.isBlocking && !mc2.player.isHandActive || !MovementUtils.isMoving))
            return
        when(modeValue.get().toLowerCase()){
            "grim" -> {
                if ((mc.thePlayer!!.heldItem == null && mc.thePlayer!!.heldItem?.item == null && mc.thePlayer!!.itemInUse == null && mc.thePlayer!!.itemInUse?.item == null) || mc2.player.heldItemMainhand.item is ItemBlock || !MovementUtils.isMoving) {
                    return
                }

                if (isBlocking && event.eventState == EventState.PRE && mc2.gameSettings.keyBindUseItem.isKeyDown) {
                    PacketUtils.sendPacketNoEvent(
                        CPacketEntityAction(
                            mc2.player,
                            CPacketEntityAction.Action.OPEN_INVENTORY
                        )
                    )

                }
                if (isBlocking && event.eventState == EventState.POST && mc2.gameSettings.keyBindUseItem.isKeyDown) {
                    PacketUtils.sendPacketNoEvent(
                        CPacketClickWindow(
                            mc.thePlayer!!.inventoryContainer.windowId,
                            mc2.player.inventory.currentItem,
                            0,
                            ClickType.QUICK_MOVE,
                            mc.thePlayer!!.heldItem!!.unwrap(),
                            1.toShort()
                        )
                    )

                    mc2.connection!!.sendPacket(CPacketConfirmTransaction())
                    mc.netHandler.addToSendQueue(createUseItemPacket(mc.thePlayer!!.heldItem,WEnumHand.MAIN_HAND))
                    mc.netHandler.addToSendQueue(createUseItemPacket(mc.thePlayer!!.heldItem,WEnumHand.OFF_HAND))
                    mc2.connection!!.sendPacket(CPacketCloseWindow())
                }
            }
            "huayuting" -> {
                if (mc2.player.heldItemMainhand.item is ItemSword) {
                    if (event.eventState == EventState.PRE && isBlocking ) {
                        mc2.player.connection.sendPacket(
                            CPacketPlayerDigging(
                                CPacketPlayerDigging.Action.RELEASE_USE_ITEM,
                                BlockPos.ORIGIN,
                                EnumFacing.DOWN
                            )
                        )
                    }
                    if (event.eventState == EventState.POST && isBlocking){
                        PacketUtils.sendPacketC0F()
                        mc2.player.connection.sendPacket(CPacketPlayerTryUseItem(EnumHand.MAIN_HAND))
                        mc2.player.connection.sendPacket(CPacketPlayerTryUseItem(EnumHand.OFF_HAND))
                    }
                } else {
                    if (event.eventState == EventState.PRE){
                        if (mc2.player.isHandActive && mc2.player.heldItemMainhand.item is ItemFood){

                        }
                    }

                    if (usefood && !(mc2.player.isHandActive)) {
                        consumeForwardis.set(0.2f)
                        consumeStrafeis.set(0.2f)
                    }

                }
            }
            "grimac2" -> {


                if (event.eventState == EventState.PRE) {
                    mc2.player.connection.sendPacket(
                        CPacketPlayerDigging(
                            CPacketPlayerDigging.Action.RELEASE_USE_ITEM,
                            BlockPos.ORIGIN,
                            EnumFacing.DOWN
                        )
                    )
                } else {
                    mc2.player.connection.sendPacket(CPacketConfirmTransaction())
                    mc2.player.connection.sendPacket(CPacketPlayerTryUseItem(EnumHand.MAIN_HAND))
                    mc2.player.connection.sendPacket(CPacketPlayerTryUseItem(EnumHand.OFF_HAND))
                }


            }
            "grimac" -> {
                if (mc2.player.heldItemMainhand.item is ItemSword && isBlocking) {
                    if (event.eventState == EventState.PRE) {
                        mc2.player.connection.sendPacket(
                            CPacketPlayerDigging(
                                CPacketPlayerDigging.Action.RELEASE_USE_ITEM,
                                BlockPos.ORIGIN,
                                EnumFacing.DOWN
                            )
                        )
                    } else {

                        mc2.player.connection.sendPacket(CPacketPlayerTryUseItem(EnumHand.MAIN_HAND))
                        mc2.player.connection.sendPacket(CPacketPlayerTryUseItem(EnumHand.OFF_HAND))
                    }
                } else if (mc2.player.isHandActive) {
                    if (event.eventState == EventState.PRE) {
                        if (noRev) {
                            mc2.player.connection.sendPacket(c08!!)
                            noRev = false
                            c08 = null
                        }
                    }
                }
                if (usefood && mc2.player.isHandActive){
                    consumeForwardis.set(1f)
                    consumeStrafeis.set(1f)
                }
            }
        }
    }
    @EventTarget
    fun onPacket(event: PacketEvent) {
        val packet = event.packet.unwrap()

        when (modeValue.get().toLowerCase()) {
            "grim"->{

                //Post
                if(packet is CPacketAnimation || packet is CPacketPlayerAbilities || packet is CPacketPlayerTryUseItem || packet is CPacketPlayerDigging || packet is CPacketUseEntity || packet is CPacketClickWindow || packet is CPacketEntityAction){
                    PacketUtils.sendPacketNoEvent(CPacketConfirmTransaction())
                }
            }
            "huayuting" -> {

                if (mc2.player!!.heldItemMainhand.item is ItemSword && killAura.state){
                    if (packet is CPacketPlayerTryUseItemOnBlock){
                        event.cancelEvent()
                    }
                }

                if (mc2.player!!.heldItemMainhand.item is ItemFood || mc2.player.heldItemMainhand.item is ItemPotion || mc2.player.heldItemMainhand.item is ItemBow) {
                    if (packet is CPacketPlayerTryUseItemOnBlock){
                        event.cancelEvent()
                    }
                    if (packet is CPacketPlayerTryUseItem && !noRev) {
                        consumeForwardis.set(0.2f)
                        consumeStrafeis.set(0.2f)
                        eatSlow = true
                        usefood = true
                        noRev = true
                        mc2.connection!!.sendPacket(CPacketClickWindow(0, 36, 0, ClickType.SWAP, ItemStack(Block.getBlockById(166)), 0))
                        noRev = false
                    }


                    if (packet is CPacketPlayerDigging) {
                        if (packet.action == CPacketPlayerDigging.Action.RELEASE_USE_ITEM) {
                            consumeForwardis.set(0.2f)
                            consumeStrafeis.set(0.2f)
                            mc2.player.connection.sendPacket(
                                CPacketClickWindow(
                                    0,
                                    36,
                                    0,
                                    ClickType.SWAP,
                                    ItemStack(Block.getBlockById(166)),
                                    0.toShort()
                                )
                            )
                            eatSlow = true
                            usefood = false
                            send = true
                        }
                    }
                    if (usefood && mc2.player!!.isHandActive){
                        consumeForwardis.set(1f)
                        consumeStrafeis.set(1f)
                    }
                    if (packet is SPacketWindowItems) {
                        eatSlow = false
                        event.cancelEvent()

                    }
                }
            }
            "grimac" -> {
                if(classProvider.isItemSword(mc.thePlayer!!.heldItem!!.item) && mc.thePlayer!!.isBlocking) {
                    //转头vl
                    if (packet is CPacketPlayerTryUseItemOnBlock && killAura.currentTarget != null) {
                        event.cancelEvent()
                    }

                }



                if (mc2.player.getHeldItemMainhand().getItem() is ItemFood || mc2.player.heldItemMainhand
                        .getItem() is ItemPotion || mc2.player.heldItemMainhand.item is ItemLingeringPotion || mc2.player.getHeldItemMainhand().getItem() is ItemSplashPotion || mc2.player.getHeldItemMainhand().getItem() is ItemBow
                ) {

                    if (packet is CPacketPlayerTryUseItemOnBlock) {
                        event.cancelEvent()
                    }
                    if (packet is CPacketPlayerTryUseItem && !noRev) {
                        usefood = true
                        event.cancelEvent()
                        mc2.player.connection.sendPacket(
                            CPacketClickWindow(
                                0,
                                36,
                                0,
                                ClickType.SWAP,
                                ItemStack(Block.getBlockById(166)),
                                0.toShort()
                            )
                        )
                        c08 = packet
                    }
                    if (usefood && mc2.player.isHandActive){
                        consumeForwardis.set(1f)
                        consumeStrafeis.set(1f)
                    }

                    if (packet is CPacketPlayerDigging && packet.action == CPacketPlayerDigging.Action.RELEASE_USE_ITEM) {
                        usefood = false
                        mc2.player.connection.sendPacket(
                            CPacketClickWindow(
                                0,
                                36,
                                0,
                                ClickType.SWAP,
                                ItemStack(Block.getBlockById(166)),
                                0.toShort()
                            )
                        )
                    }
                    if (packet is SPacketWindowItems) {
                        if (c08 != null) {
                            mc2.player.connection.sendPacket(
                                CPacketClickWindow(
                                    0,
                                    36,
                                    0,
                                    ClickType.SWAP,
                                    ItemStack(Block.getBlockById(166)),
                                    0.toShort()
                                )
                            )
                            noRev = true
                        }
                        event.cancelEvent()
                    }
                    if (packet is SPacketSetSlot) {
                        event.cancelEvent()
                    }
                }
            }
            "grimac2" -> {
                //转头vl
                if (packet is CPacketPlayerTryUseItemOnBlock && classProvider.isItemSword(mc.thePlayer!!.heldItem!!.item)) {
                    event.cancelEvent()
                }
                //Post
                if(packet is CPacketAnimation || packet is CPacketPlayerAbilities || packet is CPacketPlayerTryUseItem || packet is CPacketPlayerDigging || packet is CPacketUseEntity || packet is CPacketClickWindow || packet is CPacketEntityAction){
                    PacketUtils.sendPacketNoEvent(CPacketConfirmTransaction())
                }
            }
        }
    }
    fun blink() {
        val connection = mc2.connection ?: return
        for (i in packetBuf2)
            i.processPacket(connection)
        packetBuf2.clear()

    }






    private fun getis(item: IItem?, isForward: Boolean): Float {
        return when {
            classProvider.isItemFood(item) || classProvider.isItemPotion(item) || classProvider.isItemBucketMilk(item) -> {
                if (isForward) this.consumeForwardis.get() else this.consumeStrafeis.get()
            }
            classProvider.isItemSword(item) -> {
                if (isForward) this.blockForwardis.get() else this.blockStrafeis.get()
            }
            classProvider.isItemBow(item) -> {
                if (isForward) this.bowForwardis.get() else this.bowStrafeis.get()
            }
            else -> 0.2F
        }
    }
    override val tag: String
        get() = modeValue.get()
}
