package net.ccbluex.liquidbounce.features.module.modules.combat;


import cn.client.utils2.TimeHelper;
import net.ccbluex.liquidbounce.api.enums.WEnumHand;
import net.ccbluex.liquidbounce.api.minecraft.item.IItemArmor;
import net.ccbluex.liquidbounce.api.minecraft.item.IItemStack;
import net.ccbluex.liquidbounce.event.EventTarget;
import net.ccbluex.liquidbounce.event.Render3DEvent;
import net.ccbluex.liquidbounce.features.module.Module;
import net.ccbluex.liquidbounce.features.module.ModuleCategory;
import net.ccbluex.liquidbounce.features.module.ModuleInfo;
import net.ccbluex.liquidbounce.utils.CrossVersionUtilsKt;
import net.ccbluex.liquidbounce.utils.InventoryUtils;
import net.ccbluex.liquidbounce.utils.MovementUtils;
import net.ccbluex.liquidbounce.utils.item.ItemUtils;
import net.ccbluex.liquidbounce.utils.timer.TimeUtils;
import net.ccbluex.liquidbounce.value.BoolValue;
import net.ccbluex.liquidbounce.value.IntegerValue;
import net.minecraft.inventory.ClickType;

import static net.ccbluex.liquidbounce.utils.CrossVersionUtilsKt.createOpenInventoryPacket;

@ModuleInfo(name = "AutoArmor",Chinese = "", description = "AutoArmor.", category = ModuleCategory.COMBAT)
public class AutoArmor extends Module {
    public static boolean isDone = false;
    private final TimeHelper timer = new TimeHelper();
    private final TimeHelper glitchFixer = new TimeHelper();
    private final BoolValue openInv = new BoolValue("Sort In Inv", false);
    private final BoolValue simulateInventory = new BoolValue("SimulateInventory", true);
    private final BoolValue hotbarValue = new BoolValue("Hotbar", true);

    private final BoolValue noMove = new BoolValue("No Move", false);
    private long delay;
    private final IntegerValue minDelayValue = new IntegerValue("MinDelay", 100, 0, 400) {

        @Override
        protected void onChanged(final Integer oldValue, final Integer newValue) {
            final int maxDelay = maxDelayValue.get();

            if (maxDelay < newValue) set(maxDelay);
        }
    };
    private final IntegerValue maxDelayValue = new IntegerValue("MaxDelay", 200, 0, 400) {
        @Override
        protected void onChanged(final Integer oldValue, final Integer newValue) {
            final int minDelay = minDelayValue.get();

            if (minDelay > newValue) set(minDelay);
        }
    };

    enum ArmorType {
        BOOTS,
        LEGGINGS,
        CHEST_PLATE,
        HELMET;
    }
    @EventTarget
    public void onRender3D(final Render3DEvent event) {
        if (!this.noMove.get() || !MovementUtils.isMoving()) {
            if (this.openInv.get()) {
                if (!classProvider.isGuiInventory(mc.getCurrentScreen())) {
                    return;
                }
            } else {
                if (mc.getCurrentScreen() != null) {
                    this.glitchFixer.reset();
                }

            }

            if ((mc.getCurrentScreen() == null || this.openInv.get())) {
                ArmorType[] var3 = ArmorType.values();
                int var4 = var3.length;

                for(int var5 = 0; var5 < var4; ++var5) {
                    ArmorType armorType = var3[var5];
                    int slot;
                    if ((slot = this.findArmor(armorType, InventoryUtils.getArmorScore(mc.getThePlayer().getInventory().armorItemInSlot(armorType.ordinal())))) != -1) {
                        if (!ItemUtils.isStackEmpty(mc.getThePlayer().getInventory().armorItemInSlot(armorType.ordinal()))) {
                            this.dropArmor(armorType.ordinal());
                            return;
                        }

                        this.warmArmor(slot);
                        this.timer.reset();
                        return;
                    }
                }
                isDone = false;


            } else {
                this.timer.reset();
            }

        }
    }
    private void dropArmor(int armorSlot) {
        int slot = InventoryUtils.armorSlotToNormalSlot(armorSlot);
        boolean full = true;
        for (IItemStack iItemStack : mc.getThePlayer().getInventory().getMainInventory()) {
            if (ItemUtils.isStackEmpty(iItemStack)) {
                full = false;
                break;
            }
        }
        if (!full) {
            mc2.playerController.windowClick(mc.getThePlayer().getInventoryContainer().getWindowId(), slot, 1, ClickType.THROW, mc2.player);
        } else {
            mc2.playerController.windowClick(mc.getThePlayer().getInventoryContainer().getWindowId(), slot, 1, ClickType.THROW, mc2.player);
        }
    }
    private void warmArmor(int slot_In) {
        if (slot_In >= 0 && slot_In <= 8) {
            mc.getPlayerController().windowClick(mc.getThePlayer().getInventoryContainer().getWindowId(),slot_In + 36, 0, 1,mc.getThePlayer());
        } else {
            mc.getPlayerController().windowClick(mc.getThePlayer().getInventoryContainer().getWindowId(),slot_In, 1,1, mc.getThePlayer());
        }

    }
    private int findArmor(ArmorType armorType, float minimum) {
        float best = 0.0F;
        int result = -1;

        for(int i = 0; i < mc2.player.inventory.mainInventory.size(); ++i) {
            IItemStack itemStack = mc.getThePlayer().getInventory().getMainInventory().get(i);
            if (!(InventoryUtils.getArmorScore(itemStack) < 0.0F) && !(InventoryUtils.getArmorScore(itemStack) <= minimum) && !(InventoryUtils.getArmorScore(itemStack) < best) && this.isValid(armorType, itemStack)) {
                best = InventoryUtils.getArmorScore(itemStack);
                result = i;
            }
        }
        return result;
    }

    private boolean isValid(ArmorType type, IItemStack itemStack) {
        if (!(classProvider.isItemArmor(itemStack.getItem()))) {
            return false;
        } else {
            IItemArmor armor = itemStack.getItem().asItemArmor();
            if (type == ArmorType.HELMET && armor.getArmorType() == 0) {
                return true;
            } else if (type == ArmorType.CHEST_PLATE && armor.getArmorType() == 1) {
                return true;
            } else if (type == ArmorType.LEGGINGS && armor.getArmorType() == 2) {
                return true;
            } else {
                return type == ArmorType.BOOTS && armor.getArmorType() == 3;
            }
        }
    }



    private boolean move(int item, boolean isArmorSlot) {
        if (!isArmorSlot && item < 9 && hotbarValue.get() && !classProvider.isGuiInventory(mc.getCurrentScreen())) {
            mc.getNetHandler().addToSendQueue(classProvider.createCPacketHeldItemChange(item));
            mc.getNetHandler().addToSendQueue(CrossVersionUtilsKt.createUseItemPacket(mc.getThePlayer().getInventoryContainer().getSlot(item).getStack(), WEnumHand.MAIN_HAND));
            mc.getNetHandler().addToSendQueue(classProvider.createCPacketHeldItemChange(mc.getThePlayer().getInventory().getCurrentItem()));

            delay = TimeUtils.randomDelay(minDelayValue.get(), maxDelayValue.get());

            return true;
        } else if (!(noMove.get() && MovementUtils.isMoving()) && (!openInv.get() || classProvider.isGuiInventory(mc.getCurrentScreen())) && item != -1) {
            final boolean openInventory = simulateInventory.get() && !classProvider.isGuiInventory(mc.getCurrentScreen());

            if (openInventory) mc.getNetHandler().addToSendQueue(createOpenInventoryPacket());

            boolean full = isArmorSlot;

            if (full) {
                for (IItemStack iItemStack : mc.getThePlayer().getInventory().getMainInventory()) {
                    if (ItemUtils.isStackEmpty(iItemStack)) {
                        full = false;
                        break;
                    }
                }
            }

            if (full) {
                mc.getPlayerController().windowClick(mc.getThePlayer().getInventoryContainer().getWindowId(), item, 1, 4, mc.getThePlayer());
            } else {
                mc.getPlayerController().windowClick(mc.getThePlayer().getInventoryContainer().getWindowId(), (isArmorSlot ? item : (item < 9 ? item + 36 : item)), 0, 1, mc.getThePlayer());
            }

            delay = TimeUtils.randomDelay(minDelayValue.get(), maxDelayValue.get());

            if (openInventory) mc.getNetHandler().addToSendQueue(classProvider.createCPacketCloseWindow());

            return true;
        }

        return false;
    }


}
