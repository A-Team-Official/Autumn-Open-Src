package net.ccbluex.liquidbounce.features.module.modules.hyt


import cn.client.utils2.TimeHelper
import net.ccbluex.liquidbounce.Client
import net.ccbluex.liquidbounce.api.minecraft.network.IPacket
import net.ccbluex.liquidbounce.event.EventTarget
import net.ccbluex.liquidbounce.event.PacketEvent
import net.ccbluex.liquidbounce.event.UpdateEvent
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.features.module.modules.movement.Fly
import net.ccbluex.liquidbounce.features.module.modules.world.Scaffold
import net.ccbluex.liquidbounce.injection.backend.unwrap
import net.ccbluex.liquidbounce.injection.backend.utils.unwrap
import net.ccbluex.liquidbounce.utils.ClientUtils
import net.ccbluex.liquidbounce.utils.MSTimer
import net.ccbluex.liquidbounce.utils.MovementUtils
import net.ccbluex.liquidbounce.utils.RotationUtils
import net.ccbluex.liquidbounce.utils.block.BlockUtils
import net.ccbluex.liquidbounce.value.BoolValue
import net.ccbluex.liquidbounce.value.FloatValue
import net.ccbluex.liquidbounce.value.IntegerValue
import net.minecraft.block.BlockAir
import net.minecraft.network.play.client.CPacketPlayer
import net.minecraft.network.play.client.CPacketPlayerTryUseItem
import net.minecraft.network.play.server.SPacketPlayerPosLook
import net.minecraft.util.EnumHand
import net.minecraft.util.math.BlockPos

@ModuleInfo(name = "AntiVoid",  description = "GrimAC is the best", category = ModuleCategory.HYT, Chinese = "虚空回弹(新)")
open class HytAntiVoid : Module() {


    var a = false

    @EventTarget
    open fun isInVoid(): Boolean {
        for (i in 0..128) {
            if (MovementUtils.isOnGround(i.toDouble())) {
                return false
            }
        }
        return true
    }



    override fun onEnable() {
        a = true


    }
    @EventTarget
    fun onUpdate(event: UpdateEvent){
        if (isInVoid()){
            mc2.player.motionX = 0.0
            mc2.player.motionY = 0.0
            mc2.player.motionZ = 0.0
        }


    }
    @EventTarget
    fun onPacket(e: PacketEvent) {
        val packet = e.packet.unwrap()
        if (isInVoid()){
            if(packet is CPacketPlayer && a) {
                e.cancelEvent()
            }
            if (packet is SPacketPlayerPosLook){
                this.state = false
            }

            if(packet is CPacketPlayerTryUseItem && a){
                a = false
                e.cancelEvent()
                mc2.connection!!.sendPacket(CPacketPlayer.Rotation(mc2.player.rotationYaw,mc2.player.rotationPitch,mc2.player.onGround))
                mc2.connection!!.sendPacket(CPacketPlayerTryUseItem(EnumHand.MAIN_HAND))
            }
        }

    }

}


