/*
 * FDPClient Hacked Client
 * A free open source mixin-based injection hacked client for Minecraft using Minecraft Forge by LiquidBounce.
 * https://github.com/SkidderMC/FDPClient/
 */
package net.ccbluex.liquidbounce.features.module.modules.movement.speeds.other

import net.ccbluex.liquidbounce.Client
import net.ccbluex.liquidbounce.event.MoveEvent
import net.ccbluex.liquidbounce.features.module.modules.movement.Speed
import net.ccbluex.liquidbounce.features.module.modules.movement.speeds.SpeedMode
import net.ccbluex.liquidbounce.utils.MovementUtils

class LegitSpeed : SpeedMode("Legit") {

    override fun onMotion() {
    }

    override fun onUpdate() {
        val speed = Client.moduleManager.getModule(Speed::class.java) as Speed? ?: return
        if (speed.timer.get())mc.timer.timerSpeed = 1.004f
        if (mc.thePlayer!!.isInWater) return
        if (MovementUtils.isMoving) {
            if (mc.thePlayer!!.onGround) mc.thePlayer!!.jump()
        }
    }

    override fun onMove(event: MoveEvent) {
    }
}
