package net.ccbluex.liquidbounce.features.module.modules.misc;

import net.ccbluex.liquidbounce.Client;
import net.ccbluex.liquidbounce.api.minecraft.util.WEnumChatFormatting;
import net.ccbluex.liquidbounce.event.EventTarget;
import net.ccbluex.liquidbounce.event.UpdateEvent;
import net.ccbluex.liquidbounce.features.module.Module;
import net.ccbluex.liquidbounce.features.module.ModuleCategory;
import net.ccbluex.liquidbounce.features.module.ModuleInfo;
import net.ccbluex.liquidbounce.utils.ClientUtils;
import net.ccbluex.liquidbounce.value.BoolValue;
import verify.irc.ClientIRC;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * @author xiatian233
 * @create 05/06/2023
 */

@ModuleInfo(name = "IRC", description = "IRC", category = ModuleCategory.MISC, canEnable = false , Chinese = "你好")
public class IRC extends Module {
    public static BoolValue irc = new BoolValue("IRC",true);


}
