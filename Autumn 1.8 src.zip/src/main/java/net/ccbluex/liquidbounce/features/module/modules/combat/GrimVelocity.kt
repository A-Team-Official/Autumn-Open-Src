package net.ccbluex.liquidbounce.features.module.modules.combat

import net.ccbluex.liquidbounce.Client
import net.ccbluex.liquidbounce.event.EventTarget
import net.ccbluex.liquidbounce.event.PacketEvent
import net.ccbluex.liquidbounce.event.UpdateEvent
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.injection.backend.unwrap
import net.minecraft.block.BlockAir
import net.minecraft.block.BlockSlab
import net.minecraft.block.BlockStairs
import net.minecraft.entity.player.EntityPlayer
import net.minecraft.item.ItemBow
import net.minecraft.item.ItemFood
import net.minecraft.item.ItemPotion
import net.minecraft.network.play.client.*
import net.minecraft.network.play.server.SPacketEntityVelocity
import net.minecraft.network.play.server.SPacketPlayerPosLook
import net.minecraft.util.EnumFacing
import net.minecraft.util.math.BlockPos

@ModuleInfo(name = "GrimVelocity2", description = "Grim", Chinese = "",category = ModuleCategory.COMBAT)
class GrimVelocity : Module() {

    private var isvel = false
    private var s08 = false
    var redeCount = 24
    override fun onEnable() {
        redeCount = 24
    }


    private fun isPlayerOnSlab(player: EntityPlayer): Boolean {
        val playerPos = BlockPos(player.posX, player.posY, player.posZ)
        val block = player.entityWorld.getBlockState(playerPos).block



        val playerPos3 = BlockPos(player.posX, player.posY - 0.5, player.posZ)
        val block3 = player.entityWorld.getBlockState(playerPos3).block




        if ((block3 is BlockAir || block3 is BlockStairs) && (mc2.player.onGround)){
            return true
        }

        return block is BlockSlab || block is BlockStairs

    }
    @EventTarget
    fun onUpdate(event: UpdateEvent) {
        if (redeCount < 24) redeCount++
    }
    @EventTarget
    fun onPacket(event: PacketEvent) {
        val packet = event.packet.unwrap()
        if (packet is SPacketEntityVelocity) {

            if (packet.getMotionX() == 0 && packet.getMotionZ() == 0) { // ignore horizonal velocity
                return
            }
            val killAura = Client.moduleManager[KillAura::class.java] as KillAura
            val target = Client.combatManager.getNearByEntity(killAura.rangeValue.get() + 1) ?: return

            mc2.player!!.motionX = 0.0
            mc2.player!!.motionZ = 0.0
            packet.motionX = 0
            packet.motionZ = 0
            for (i in 0..redeCount) {
                mc2.player!!.connection.sendPacket(CPacketUseEntity(target.unwrap()))
                mc2.player!!.connection.sendPacket(CPacketAnimation())
            }
            if (redeCount > 12) redeCount -= 5


        }
    }


}