package net.ccbluex.liquidbounce.features.command.commands

import net.ccbluex.liquidbounce.features.command.Command
import net.ccbluex.liquidbounce.utils.ClientUtils
import verify.ver.MySQLDemo
@cn.obf.Native
class PlayerListCommand : Command("playerlist"){
    override fun execute(args: Array<String>) {
        chat("§c§l-PlayerList-")
        ClientUtils.displayChatMessage(MySQLDemo.X2Gname().toString() + "\n")
    }
}