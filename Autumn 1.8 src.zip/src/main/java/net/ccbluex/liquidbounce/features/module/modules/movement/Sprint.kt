/*
 * FDPClient Hacked Client
 * A free open source mixin-based injection hacked client for Minecraft using Minecraft Forge by LiquidBounce.
 * https://github.com/SkidderMC/FDPClient/
 */
package net.ccbluex.liquidbounce.features.module.modules.movement

import net.ccbluex.liquidbounce.api.minecraft.potion.PotionType
import net.ccbluex.liquidbounce.event.EventTarget
import net.ccbluex.liquidbounce.event.PacketEvent
import net.ccbluex.liquidbounce.event.UpdateEvent
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.utils.MovementUtils
import net.ccbluex.liquidbounce.utils.MovementUtils.isMoving
import net.ccbluex.liquidbounce.utils.Rotation
import net.ccbluex.liquidbounce.utils.RotationUtils
import net.ccbluex.liquidbounce.value.BoolValue
import net.ccbluex.liquidbounce.value.FloatValue
import net.ccbluex.liquidbounce.value.ListValue
import net.minecraft.network.play.client.CPacketEntityAction


@ModuleInfo(name = "Sprint", category = ModuleCategory.MOVEMENT, description = "Sprint", Chinese = "")
class Sprint : Module() {
    val useItemValue = BoolValue("UseItem", true)
    val useItemSwordValue = BoolValue("UseItemOnlySword", false).displayable{ useItemValue.get() }
    val hungryValue = BoolValue("Hungry", true)
    val sneakValue = BoolValue("Sneak", false)
    val collideValue = BoolValue("Collide", false)
    val jumpDirectionsValue = BoolValue("JumpDirections", false)
    val allDirectionsValue = BoolValue("AllDirections", false)
    val allDirectionsBypassValue = ListValue("AllDirectionsBypass", arrayOf("Rotate", "RotateSpoof", "Toggle", "Spoof", "SpamSprint", "NoStopSprint", "Minemora", "LimitSpeed", "None"), "None").displayable { allDirectionsValue.get() }
    private val allDirectionsLimitSpeedGround = BoolValue("AllDirectionsLimitSpeedOnlyGround", true)
    private val allDirectionsLimitSpeedValue = FloatValue("AllDirectionsLimitSpeed", 0.7f, 0.5f, 1f).displayable { allDirectionsBypassValue.displayable && allDirectionsBypassValue.equals("LimitSpeed") }
    private val noPacketValue = BoolValue("NoPackets", true)
    var switchStat = false
    var forceSprint = false

    @EventTarget
    fun onUpdate(event: UpdateEvent) {
        if (allDirectionsValue.get()) {
            when(allDirectionsBypassValue.get()) {
                "NoStopSprint" -> {
                    forceSprint = true
                }
                "SpamSprint" -> {
                    forceSprint = true
                    mc2.connection!!.sendPacket(CPacketEntityAction(mc2.player!!, CPacketEntityAction.Action.START_SPRINTING))
                }
                "Spoof" -> {
                    mc2.connection!!.sendPacket(CPacketEntityAction(mc2.player!!, CPacketEntityAction.Action.START_SPRINTING))
                    switchStat = true
                }
            }
            if (RotationUtils.getRotationDifference(Rotation(MovementUtils.movingYaw, mc2.player!!.rotationPitch), Rotation(mc2.player!!.rotationYaw, mc2.player!!.rotationPitch)) > 30) {
                when(allDirectionsBypassValue.get()) {
                    "Rotate" -> RotationUtils.setTargetRotation(Rotation(MovementUtils.movingYaw, mc2.player!!.rotationPitch), 2)
                    "RotateSpoof" -> {
                        switchStat = !switchStat
                        if (switchStat) {
                            RotationUtils.setTargetRotation(Rotation(MovementUtils.movingYaw, mc2.player!!.rotationPitch))
                        }
                    }
                    "Toggle" -> {
                        mc2.connection!!.sendPacket(CPacketEntityAction(mc2.player!!, CPacketEntityAction.Action.STOP_SPRINTING))
                        mc2.connection!!.sendPacket(CPacketEntityAction(mc2.player!!, CPacketEntityAction.Action.START_SPRINTING))
                    }
                    "Minemora" -> {
                        if (mc2.player!!.onGround && RotationUtils.getRotationDifference(Rotation(MovementUtils.movingYaw, mc2.player!!.rotationPitch)) > 60) {
                            mc2.player!!.setPosition(mc2.player!!.posX, mc2.player!!.posY + 0.0000013, mc2.player!!.posZ)
                            mc2.player!!.motionY = 0.0
                        }
                    }
                    "LimitSpeed" -> {
                        if (!allDirectionsLimitSpeedGround.get() || mc2.player!!.onGround) {
                            MovementUtils.limitSpeedByPercent(allDirectionsLimitSpeedValue.get())
                        }
                    }
                }
            }
        } else {
            switchStat = false
            forceSprint = false
        }
    }

    @EventTarget
    fun onPacket(event: PacketEvent) {
        val packet = event.packet
        if (packet is CPacketEntityAction) {
            if (allDirectionsValue.get()) {
                when(allDirectionsBypassValue.get()) {
                    "SpamSprint", "NoStopSprint" -> {
                        if (packet.action == CPacketEntityAction.Action.STOP_SPRINTING) {
                            event.cancelEvent()
                        }
                    }
                    "Toggle" -> {
                        if (switchStat) {
                            if (packet.action == CPacketEntityAction.Action.STOP_SPRINTING) {
                                event.cancelEvent()
                            } else {
                                switchStat = !switchStat
                            }
                        } else {
                            if (packet.action == CPacketEntityAction.Action.START_SPRINTING) {
                                event.cancelEvent()
                            } else {
                                switchStat = !switchStat
                            }
                        }
                    }
                    "Spoof" -> {
                        if (switchStat) {
                            if (packet.action == CPacketEntityAction.Action.STOP_SPRINTING || packet.action == CPacketEntityAction.Action.START_SPRINTING) {
                                event.cancelEvent()
                            }
                        }
                    }
                }
            }
            if (noPacketValue.get() && !event.isCancelled) {
                if (packet.action == CPacketEntityAction.Action.STOP_SPRINTING || packet.action == CPacketEntityAction.Action.START_SPRINTING) {
                    event.cancelEvent()
                }
            }
        }
    }
}
