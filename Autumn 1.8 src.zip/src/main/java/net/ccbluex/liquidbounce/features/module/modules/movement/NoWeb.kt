/*
 * LiquidBounce Hacked Client
 * A free open source mixin-based injection hacked client for Minecraft using Minecraft Forge.
 * https://github.com/CCBlueX/LiquidBounce/
 */
package net.ccbluex.liquidbounce.features.module.modules.movement

import net.ccbluex.liquidbounce.event.*
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.injection.backend.unwrap
import net.ccbluex.liquidbounce.injection.backend.utils.unwrap
import net.ccbluex.liquidbounce.utils.MovementUtils
import net.ccbluex.liquidbounce.utils.block.BlockUtils
import net.ccbluex.liquidbounce.value.FloatValue
import net.minecraft.block.BlockLiquid
import net.minecraft.block.BlockWeb
import net.minecraft.network.play.client.CPacketPlayerDigging
import net.minecraft.util.EnumFacing


@ModuleInfo(name = "NoWeb", Chinese = "无减速穿越", description = "bzd", category = ModuleCategory.MOVEMENT)
class NoWeb : Module() {
      private val range = FloatValue("range",0f,0f,10f)
    //   private var blockpos2 = BlockPos(0,0,0)

    @EventTarget
    fun onMotion(event: MotionEvent) {

        val searchBlocks = BlockUtils.searchBlocks(range.get().toInt())

        for (block in searchBlocks){
            if (event.eventState == EventState.PRE) {
                val blockpos = block.key.unwrap()
                val blocks = block.value.unwrap()
                if (blocks is BlockWeb) {
                    mc2.connection!!.sendPacket(
                        CPacketPlayerDigging(
                            CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK,
                            blockpos,
                            EnumFacing.DOWN
                        )
                    )
                    mc2.player.isInWeb = false


                }

            }


            /*   if(blocks is BlockLiquid){
                   if(mc2.player.getDistanceSqToCenter(blockpos)<= range.get()){
                   blockpos2 = blockpos

                       mc2.connection!!.sendPacket(CPacketPlayerDigging(CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK,blockpos, EnumFacing.DOWN))
                       mc2.player.inWater = false
                   }
               }*/

        }


        if (mc2.player.isOnLadder && mc2.gameSettings.keyBindJump.isKeyDown) {
            if (mc2.player.motionY >= 0.0) {
                mc2.player.motionY = 0.1786
            }
        }
    }
    @EventTarget
    fun onRender3D (event:Render3DEvent){
        // if(blockpos2 != BlockPos(0,0,0))
        //  RenderUtils.drawBlockBox(blockpos2.wrap(),Color(255,0,0),true)
    }
}