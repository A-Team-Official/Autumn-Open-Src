package net.ccbluex.liquidbounce.features.module.modules.combat;

import net.ccbluex.liquidbounce.event.EventTarget;
import net.ccbluex.liquidbounce.event.PacketEvent;
import net.ccbluex.liquidbounce.event.UpdateEvent;
import net.ccbluex.liquidbounce.event.WorldEvent;
import net.ccbluex.liquidbounce.features.module.Module;
import net.ccbluex.liquidbounce.features.module.ModuleCategory;
import net.ccbluex.liquidbounce.features.module.ModuleInfo;
import net.ccbluex.liquidbounce.injection.backend.PacketImplKt;
import net.ccbluex.liquidbounce.utils.ClientUtils;
import net.ccbluex.liquidbounce.utils.MovementUtils;
import net.ccbluex.liquidbounce.utils.misc.RandomUtils;
import net.ccbluex.liquidbounce.value.BoolValue;
import net.ccbluex.liquidbounce.value.ListValue;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.*;
import net.minecraft.network.play.server.SPacketConfirmTransaction;
import net.minecraft.network.play.server.SPacketEntityVelocity;

import java.util.ArrayList;
import java.util.HashMap;
@cn.obf.Native
@ModuleInfo(name = "DisablerA", description = "Super.", category = ModuleCategory.EXPLOIT,Chinese = "减少反作弊检测")
public class Disabler extends Module {
    public final ListValue modeValue = new ListValue("Mode", new String[]{"HuaYuTing", "PingSpoof"}, "HuaYuTing");
    public final BoolValue badPacketsValue = new BoolValue("HuaYuTing-BadPackets", true);
    public final BoolValue noC03Value = new BoolValue("HuaYuTing-Combat-Reach", true);
    public final BoolValue noC03PValue = new BoolValue("HuaYuTing-Combat-Reach-Addon", false);
    public final BoolValue velocityValue = new BoolValue("HuaYuTing-Velocity-Test", false);
    public final BoolValue velocityOnlyMoveValue = new BoolValue("HuaYuTing-Velocity-OnlyMove", true);
    public final BoolValue debugValue = new BoolValue("Debug", false);

    private final ArrayList<CPacketConfirmTransaction> c0EMap = new ArrayList<>();
    private int lastTick = 0;
    private boolean cancelNextC02 = false;
    private int s32counter = 0;
    private final HashMap<Packet<?>, Long> packetsMap = new HashMap<>();

    private void debug(String str) {
        if (debugValue.get()) ClientUtils.displayChatMessage("§7[§8§lDisabler§7] §3" + str);
    }

    @EventTarget
    public void onWorld(WorldEvent event) {
        c0EMap.forEach(packet -> mc2.getConnection().sendPacket(packet));
        c0EMap.clear();
        packetsMap.forEach((packet, Long) -> mc2.getConnection().sendPacket(packet));
        packetsMap.clear();

    }

    @Override
    public void onEnable() {

        c0EMap.clear();
        packetsMap.clear();
    }

    @Override
    public void onDisable() {
        c0EMap.forEach(packet -> mc2.getConnection().sendPacket(packet));
        c0EMap.clear();
        packetsMap.forEach((packet, Long) -> mc2.getConnection().sendPacket(packet));
        packetsMap.clear();
    }

    @EventTarget
    public void onUpdate(UpdateEvent event) {
        switch (modeValue.get().toLowerCase()) {
            case "huayuting": {
                    if (mc2.player.ticksExisted % 40 == 0) {
                        c0EMap.forEach(packet -> mc2.getConnection().sendPacket(packet));
                        c0EMap.clear();
                        cancelNextC02 = true;
                    }
                }
                break;
            case "pingspoof": {
                    packetsMap.forEach((packet, time) -> {
                        if (System.currentTimeMillis() >= time) {
                            mc2.getConnection().sendPacket(packet);
                            packetsMap.remove(packet);
                        }
                    });
                }
                break;
        }
    }

    @EventTarget
    public void onPacket(PacketEvent event) {
        final Packet<?> packet = PacketImplKt.unwrap(event.getPacket());

        switch (modeValue.get().toLowerCase()) {
            case "huayuting": {
                    if (badPacketsValue.get()) {
                        if (packet instanceof CPacketHeldItemChange) {
                            if (((CPacketHeldItemChange) packet).getSlotId() == mc2.player.inventory.currentItem) {
                                event.cancelEvent();
                                debug("Cancel a bad packet.");
                            }
                        }
                        if (packet instanceof CPacketUseEntity) {
                            if (((CPacketUseEntity) packet).getAction() == CPacketUseEntity.Action.ATTACK) {
                                if (((CPacketUseEntity) packet).getEntityFromWorld(mc2.world) == mc2.player) {
                                    event.cancelEvent();
                                    debug("Cancel a bad packet.");
                                }
                                if (mc2.player.ticksExisted - lastTick > 1) {
                                    event.cancelEvent();
                                    debug("Cancel a bad packet.");
                                }
                            }
                        }
                        if (packet instanceof CPacketEntityAction) {
                            final CPacketEntityAction.Action action = ((CPacketEntityAction) packet).getAction();
                            if (action == CPacketEntityAction.Action.START_RIDING_JUMP) {
                                final int jumpBoost = ((CPacketEntityAction) packet).getAuxData();

                                if (jumpBoost < 0 || jumpBoost > 100) {
                                    event.cancelEvent();
                                    debug("Ccancel a bad packet.");
                                }
                            }
                        }
                        if (packet instanceof CPacketAnimation) {
                            lastTick = mc2.player.ticksExisted;
                        }
                    }
                    if (noC03Value.get()) {
                        if (!MovementUtils.isMoving()) {
                            if (packet instanceof CPacketPlayer) {
                                event.cancelEvent();
                                debug("Cancel a packet.");
                            }
                            if (noC03PValue.get()) {
                                if (packet instanceof CPacketConfirmTransaction) {
                                    c0EMap.add((CPacketConfirmTransaction) packet);
                                    event.cancelEvent();
                                    debug("Spoof a packet.");
                                }
                                if (packet instanceof CPacketUseEntity) {
                                    if (cancelNextC02) {
                                        event.cancelEvent();
                                        cancelNextC02 = false;
                                        debug("Cancel an attack packet.");
                                    }
                                }
                            }
                        } else {
                            if (!c0EMap.isEmpty()) {
                                c0EMap.forEach(p -> mc2.getConnection().sendPacket(p));
                                c0EMap.clear();
                            }
                        }
                    }
                    if (velocityValue.get()) {
                        if (packet instanceof SPacketEntityVelocity) {
                            if (((SPacketEntityVelocity) packet).getEntityID() == mc2.player.getEntityId()) {
                                s32counter = 5;
                            }
                        }
                        if (packet instanceof SPacketConfirmTransaction) {
                            if (s32counter > 0) {
                                s32counter--;
                                event.cancelEvent();
                                debug("Cancel a packet.");
                            }
                        }
                        if (packet instanceof CPacketConfirmTransaction || packet instanceof CPacketPlayer) {
                            if (s32counter > 0 && (!MovementUtils.isMoving() && !velocityOnlyMoveValue.get())) {
                                event.cancelEvent();
                            }
                        }
                    }
                }
                break;
            case "pingspoof": {
                    if (packet instanceof CPacketKeepAlive) {
                        packetsMap.put(packet, System.currentTimeMillis() + (long) RandomUtils.nextInt(400, 500));
                        event.cancelEvent();
                    }
                    if (packet instanceof CPacketConfirmTransaction) {
                        packetsMap.put(packet, System.currentTimeMillis() + (long) RandomUtils.nextInt(400, 500));
                        event.cancelEvent();
                    }
                    if (packet instanceof CPacketClientStatus) {
                        packetsMap.put(packet, System.currentTimeMillis() + (long) RandomUtils.nextInt(400, 500));
                        event.cancelEvent();
                    }
                }
                break;
        }
    }

    public String getMode() {
        return this.modeValue.get();
    }
}
