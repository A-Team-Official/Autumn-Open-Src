package net.ccbluex.liquidbounce.features.module.modules.hyt

import net.ccbluex.liquidbounce.event.EventTarget
import net.ccbluex.liquidbounce.event.PacketEvent
import net.ccbluex.liquidbounce.event.UpdateEvent
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.injection.backend.unwrap
import net.ccbluex.liquidbounce.utils.MovementUtils
import net.ccbluex.liquidbounce.value.FloatValue
import net.ccbluex.liquidbounce.value.IntegerValue
import net.ccbluex.liquidbounce.value.ListValue
import net.minecraft.network.play.server.SPacketChat


@ModuleInfo(name = "AutoClip", description = "AutoClip", Chinese = "", category = ModuleCategory.MOVEMENT)
class BedFucker : Module() {

    private val modeValue = ListValue("mode", arrayOf("firework", "fly","off"), "off")
    private val X = IntegerValue("posX",0,-100,100)
    private val Y = IntegerValue("posY",10,2,50)
    private val Z = IntegerValue("posZ",0,-100,100)
    private val vanillaSpeedValue = FloatValue("FlySpeed", 4f, 0f, 10f)
    private val Times = IntegerValue("TpTicks",10,0,100)
    private var TPtimes = Times.get()
    private var a = 0

    @EventTarget
    fun onPacket(event: PacketEvent) {
        val packet = event.packet.unwrap()
        if (packet is SPacketChat) {
            val text = packet.chatComponent.unformattedText

            if (!packet.chatComponent.unformattedText.contains(":") && (text.contains("恭喜", true)
                        || text.contains("${mc.thePlayer!!.name} 在地图", true) && text.contains("取得了一场游戏的胜利", true) )) {
                a = -20
            }
            if (!packet.chatComponent.unformattedText.contains(":") && text.contains("正在进行匹配", true)) {
                a = 0
            }
        }
    }

    @EventTarget
    fun onUpdate(event: UpdateEvent) {
        val vanillaSpeed = vanillaSpeedValue.get()
        val thePlayer = mc.thePlayer!!
        a += 1
        if(a < 0) return
        if (thePlayer.capabilities.isFlying) {
            when (modeValue.get().toLowerCase()) {
                "firework" -> {//像烟花一样起飞
                    thePlayer.setPositionAndRotation(
                        thePlayer.posX + X.get() / 2,
                        thePlayer.posY + Y.get() / 2,
                        thePlayer.posZ + Z.get() / 2,
                        thePlayer.rotationYaw,
                        thePlayer.rotationPitch
                    )
                }
                "fly" -> {//飞行
                    if (TPtimes == 0) {
                        thePlayer.motionY = 0.0
                        thePlayer.motionX = 0.0
                        thePlayer.motionZ = 0.0
                        if (mc.gameSettings.keyBindJump.isKeyDown) thePlayer.motionY += vanillaSpeed
                        if (mc.gameSettings.keyBindSneak.isKeyDown) thePlayer.motionY -= vanillaSpeed
                        MovementUtils.strafe(vanillaSpeed)
                    }else{
                        thePlayer.setPositionAndRotation(
                            thePlayer.posX + X.get() / 2,
                            thePlayer.posY + Y.get() / 2,
                            thePlayer.posZ + Z.get() / 2,
                            thePlayer.rotationYaw,
                            thePlayer.rotationPitch
                        )
                        TPtimes -= 1
                    }
                }
            }
        }
        else{
            val thePlayer = mc.thePlayer ?: return
            thePlayer.capabilities.isFlying = false
            mc.timer.timerSpeed = 1f
            thePlayer.speedInAir = 0.02f
            TPtimes = Times.get()
        }
    }

    override fun handleEvents() = true
    override val tag: String
        get() = modeValue.get()

}