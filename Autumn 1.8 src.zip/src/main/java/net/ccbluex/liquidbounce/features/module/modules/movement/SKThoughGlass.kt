package net.ccbluex.liquidbounce.features.module.modules.movement

import net.ccbluex.liquidbounce.event.*
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.utils.ClientUtils
import net.ccbluex.liquidbounce.utils.MovementUtils
import net.ccbluex.liquidbounce.value.FloatValue
import net.ccbluex.liquidbounce.value.IntegerValue
import net.ccbluex.liquidbounce.value.ListValue

@ModuleInfo(name = "SKThoughGlass", category = ModuleCategory.MOVEMENT, Chinese = "在花雨庭空岛提前穿过玻璃障碍", description = "") //By 菜级玩家
class SKThoughGlass : Module() {

    private val modeValue = ListValue("mode", arrayOf(

        "firework",

        "fly"

    ), "firework")

    private val X = IntegerValue("posX",0,-100,100)

    private val Y = IntegerValue("posY",10,2,50)

    private val Z = IntegerValue("posZ",0,-100,100)

    private val vanillaSpeedValue = FloatValue("FlySpeed", 4f, 0f, 10f)

    private val Times = IntegerValue("TpTicks",10,0,100)

    private var TPtimes = Times.get()

    @EventTarget



    fun onUpdate(event: UpdateEvent) {

        val vanillaSpeed = vanillaSpeedValue.get()

        val thePlayer = mc.thePlayer!!

            if (thePlayer.capabilities.isFlying) {

                when (modeValue.get().toLowerCase()) {

                    "firework" -> {

                            ClientUtils.displayChatMessage("[修改空岛出生点]火箭发射器ヾ(✿ﾟ▽ﾟ)ノ")

                            thePlayer.setPositionAndRotation(

                                thePlayer.posX + X.get() / 2,

                                thePlayer.posY + Y.get() / 2,

                                thePlayer.posZ + Z.get() / 2,

                                thePlayer.rotationYaw,

                                thePlayer.rotationPitch

                            )

                    }

                    "fly" -> {//飞行

                        if (TPtimes == 0) {

                            thePlayer.motionY = 0.0

                            thePlayer.motionX = 0.0

                            thePlayer.motionZ = 0.0

                            if (mc.gameSettings.keyBindJump.isKeyDown) thePlayer.motionY += vanillaSpeed

                            if (mc.gameSettings.keyBindSneak.isKeyDown) thePlayer.motionY -= vanillaSpeed

                            MovementUtils.strafe(vanillaSpeed)

                        }else{

                            ClientUtils.displayChatMessage("[修改空岛出生点]芜湖!起飞！！")

                            thePlayer.setPositionAndRotation(

                                thePlayer.posX + X.get() / 2,

                                thePlayer.posY + Y.get() / 2,

                                thePlayer.posZ + Z.get() / 2,

                                thePlayer.rotationYaw,

                                thePlayer.rotationPitch

                            )

                            TPtimes -= 1

                        }

                    }

                }

            }

            else{

                    val thePlayer = mc.thePlayer ?: return

                    thePlayer.capabilities.isFlying = false

                    mc.timer.timerSpeed = 1f

                    thePlayer.speedInAir = 0.02f

                    TPtimes = Times.get()

            }

    }

    override fun handleEvents() = true

    override val tag: String

        get() = modeValue.get()

} 