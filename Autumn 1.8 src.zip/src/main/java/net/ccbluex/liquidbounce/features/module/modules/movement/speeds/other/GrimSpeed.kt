package net.ccbluex.liquidbounce.features.module.modules.movement.speeds.other

import net.ccbluex.liquidbounce.Client
import net.ccbluex.liquidbounce.event.MoveEvent
import net.ccbluex.liquidbounce.features.module.modules.movement.Speed
import net.ccbluex.liquidbounce.features.module.modules.movement.speeds.SpeedMode
import net.ccbluex.liquidbounce.utils.MovementUtils
import net.minecraft.entity.EntityLivingBase

class GrimSpeed:SpeedMode("GrimSpeed") {
    private var offGroundTicks = 0
    override fun onMotion() {
        TODO("Not yet implemented")
    }

    override fun onUpdate() {
        val speed = Client.moduleManager.getModule(Speed::class.java) as Speed? ?: return
        if (mc2.player.onGround) {
            offGroundTicks = 0
        } else offGroundTicks++
        for (entity in mc2.world.loadedEntityList) {

            if (entity is EntityLivingBase && entity.getEntityId() != mc2.player.entityId && mc2.player.getDistance(
                    entity
                ) <= 1.3 && offGroundTicks >= 3.5 && entity.hurtTime > 0
            ) {


                if (speed.speedUp.get()) {
                    mc2.player.motionX *= 1.45
                    mc2.player.motionZ *= 1.45
                }


            }
        }
    }

    override fun onMove(event: MoveEvent) {
        TODO("Not yet implemented")
    }


}