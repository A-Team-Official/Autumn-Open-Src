package net.ccbluex.liquidbounce.features.module.modules.combat

import net.ccbluex.liquidbounce.Client
import net.ccbluex.liquidbounce.event.*
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.injection.backend.unwrap
import net.ccbluex.liquidbounce.utils.MovementUtils
import net.ccbluex.liquidbounce.utils.PacketUtils
import net.minecraft.network.Packet
import net.minecraft.network.play.client.*
import net.minecraft.network.play.server.SPacketEntityVelocity
import net.minecraft.util.EnumHand
import net.minecraft.util.math.MathHelper
import net.minecraft.util.math.RayTraceResult
import top.fl0wowp4rty.phantomshield.annotations.Native

@Native
@ModuleInfo(name = "GrimVelocity", description = "Grim", Chinese = "",category = ModuleCategory.COMBAT)
class GrimVelocity2 : Module() {


    val killAura = Client.moduleManager[KillAura::class.java] as KillAura
    var isvel = false
    var velx = 0f
    var velz = 0f
    var vely = 0f

    var attacked = false;


    @EventTarget
    fun onUpdate(event: UpdateEvent) {
        if (isvel) {
            if (attacked) {
                if (attacked) {
                    if (MathHelper.sqrt(velx * velx + velz * velz) <= 2) {
                        if (mc2.player.onGround) {
                            mc2.player.motionX = velx * 0.0001
                            mc2.player.motionZ = velz * 0.0001
                        } else {
                            mc2.player.motionX = velx * 0.02
                            mc2.player.motionZ = velz * 0.02
                        }
                    } else {
                        mc2.player.motionX = velx * 0.15
                        mc2.player.motionZ = velz * 0.15

                    }
                }
                attacked = false
            } else if (mc2.player.hurtTime == 6 && mc2.player.onGround && !mc2.gameSettings.keyBindJump.isKeyDown) {
                mc2.player.movementInput.jump = true
            }
            if(mc2.player.hurtTime == 0){
                isvel = false
            }
        }
    }

    @EventTarget
    fun onPacket(event: PacketEvent) {
        val packet: Packet<*> = event.packet.unwrap()
        if (packet is SPacketEntityVelocity) {
            if (packet.entityID != mc2.player.entityId) return
            val targets =  killAura.currentTarget!!.unwrap()
            if (mc2.player.getDistance(targets) < 3.01) {

                isvel = true

                for (i in 0..15) {
                    if (mc2.player.serverSprintState && MovementUtils.isMoving) {
                        PacketUtils.sendPacketC0F()
                        PacketUtils.sendPacketNoEvent(CPacketAnimation(EnumHand.MAIN_HAND));
                        PacketUtils.sendPacketNoEvent(CPacketUseEntity(targets));
                    } else {
                        PacketUtils.sendPacketC0F()
                        PacketUtils.sendPacketNoEvent(
                            CPacketEntityAction(
                                mc2.player,
                                CPacketEntityAction.Action.START_SPRINTING
                            )
                        );
                        mc2.player.isSprinting = false
                        PacketUtils.sendPacketNoEvent(CPacketAnimation(EnumHand.MAIN_HAND));
                        PacketUtils.sendPacketNoEvent(CPacketUseEntity(targets));
                        PacketUtils.sendPacketNoEvent(
                            CPacketEntityAction(
                                mc2.player,
                                CPacketEntityAction.Action.STOP_SPRINTING
                            )
                        );
                    }
                }

                velx = packet.getMotionX() / 8000f
                velz = packet.getMotionZ() / 8000f
                vely = packet.getMotionY() / 8000f
                attacked = true

            }

        }
    }

}