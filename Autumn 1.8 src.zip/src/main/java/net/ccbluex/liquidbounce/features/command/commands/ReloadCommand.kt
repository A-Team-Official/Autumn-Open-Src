package net.ccbluex.liquidbounce.features.command.commands

import net.ccbluex.liquidbounce.Client
import net.ccbluex.liquidbounce.features.command.Command
import net.ccbluex.liquidbounce.features.command.CommandManager
import net.ccbluex.liquidbounce.ui.cape.GuiCapeManager
import net.ccbluex.liquidbounce.ui.client.clickgui.ClickGui
import net.ccbluex.liquidbounce.ui.font.Fonts

class ReloadCommand : Command("reload", "configreload") {
    /**
     * Execute commands with provided [args]
     */
    override fun execute(args: Array<String>) {
        chat("Reloading...")
        chat("§c§lReloading commands...")
        Client.commandManager = CommandManager()
        Client.registerCommands()
        Client.isStarting = true
        Client.scriptManager.disableScripts()
        Client.scriptManager.unloadScripts()
        for(module in Client.moduleManager.modules)
            Client.moduleManager.generateCommand(module)
        chat("§c§lReloading scripts...")
        Client.scriptManager.loadScripts()
        Client.scriptManager.enableScripts()
        chat("§c§lReloading fonts...")
        Fonts.loadFonts()
        GuiCapeManager.load()
        Client.isStarting = false
        chat("§c§lReloading values...")
        Client.fileManager.loadConfig(Client.fileManager.valuesConfig)
        chat("§c§lReloading accounts...")
        Client.fileManager.loadConfig(Client.fileManager.accountsConfig)
        chat("§c§lReloading friends...")
        Client.fileManager.loadConfig(Client.fileManager.friendsConfig)
        chat("§c§lReloading xray...")
        Client.fileManager.loadConfig(Client.fileManager.xrayConfig)
        chat("§c§lReloading HUD...")
        Client.fileManager.loadConfig(Client.fileManager.hudConfig)
        chat("§c§lReloading ClickGUI...")
        Client.clickGui = ClickGui()
        Client.fileManager.loadConfig(Client.fileManager.clickGuiConfig)
        chat("Reloaded.")
    }
}
