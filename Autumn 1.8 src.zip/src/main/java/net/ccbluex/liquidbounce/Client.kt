package net.ccbluex.liquidbounce

import cn.client.gui.MusicManager
import cn.client.modules.*
import cn.client.neverlose.yuanshen.OP
import cn.client.novoline.module.Ambience
import cn.client.novoline.module.ChatTranslator
import cn.client.novoline.module.TianKengHelper
import cn.client.novoline.ui.GuiMainMenu
import cn.client.utils.Color.modules.CustomUI
import cn.client.utils.TipSoundManager
import net.ccbluex.liquidbounce.api.Wrapper
import net.ccbluex.liquidbounce.api.minecraft.util.IResourceLocation
import net.ccbluex.liquidbounce.clickgui.ClickGUI
import net.ccbluex.liquidbounce.clickgui.ConfigSettingsCommand
import net.ccbluex.liquidbounce.clickgui.NewGUI
import net.ccbluex.liquidbounce.event.EventManager
import net.ccbluex.liquidbounce.features.command.CommandManager
import net.ccbluex.liquidbounce.features.command.ConfigCommand
import net.ccbluex.liquidbounce.features.command.commands.*
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleManager
import net.ccbluex.liquidbounce.features.module.modules.color.ColorMixer
import net.ccbluex.liquidbounce.features.module.modules.combat.*
import net.ccbluex.liquidbounce.features.module.modules.exploit.*
import net.ccbluex.liquidbounce.features.module.modules.gui.HudDesigner
import net.ccbluex.liquidbounce.features.module.modules.gui.TargetList
import net.ccbluex.liquidbounce.features.module.modules.hyt.*
import net.ccbluex.liquidbounce.features.module.modules.misc.*
import net.ccbluex.liquidbounce.features.module.modules.movement.*
import net.ccbluex.liquidbounce.features.module.modules.player.*
import net.ccbluex.liquidbounce.features.module.modules.render.*
import net.ccbluex.liquidbounce.features.module.modules.world.*
import net.ccbluex.liquidbounce.features.module.modules.world.Timer
import net.ccbluex.liquidbounce.features.special.AntiForge
import net.ccbluex.liquidbounce.features.special.BungeeCordSpoof
import net.ccbluex.liquidbounce.file.FileManager
import net.ccbluex.liquidbounce.management.CombatManager
import net.ccbluex.liquidbounce.management.MemoryManager
import net.ccbluex.liquidbounce.script.ScriptManager
import net.ccbluex.liquidbounce.script.remapper.Remapper.loadSrg
import net.ccbluex.liquidbounce.ui.cape.GuiCapeManager
import net.ccbluex.liquidbounce.ui.client.altmanager.GuiAltManager
import net.ccbluex.liquidbounce.ui.client.clickgui.ClickGui
import net.ccbluex.liquidbounce.ui.client.hud.HUD
import net.ccbluex.liquidbounce.ui.client.hud.HUD.Companion.createDefault
import net.ccbluex.liquidbounce.ui.cnfont.FontLoaders
import net.ccbluex.liquidbounce.ui.font.Fonts
import net.ccbluex.liquidbounce.utils.ClientUtils
import net.ccbluex.liquidbounce.utils.InventoryUtils
import net.ccbluex.liquidbounce.utils.RotationUtils
import net.ccbluex.liquidbounce.utils.block.BlurEvent
import net.ccbluex.liquidbounce.utils.render.DrawArc
import net.minecraft.client.Minecraft
import org.lwjgl.opengl.Display
import sun.misc.Unsafe
import top.fl0wowp4rty.phantomshield.annotations.Native
import verify.Client
import verify.QQ.QQCheek
import verify.irc.ClientIRC
import verify.irc.IRCGui
import verify.irc.IRCHelper
import verify.jamming.AutoJamming
import verify.jamming.JammingCommand
import verify.ver.*
import java.awt.TrayIcon
import java.io.File
import java.io.IOException
import java.lang.instrument.ClassFileTransformer
import java.lang.instrument.Instrumentation
import java.security.ProtectionDomain
import java.text.SimpleDateFormat
import java.util.*
import javax.swing.JOptionPane
@Native
object Client: ClassFileTransformer {

    // Client information
    const val CLIENT_NAME = "Autumn"
    const val CLIENT_VERSION = "Reborn"
    const val CLIENT_CREATOR = "@A-Team"
    const val CLIENT_CLOUD = "https://cloud.liquidbounce.net/LiquidBounce"

    var isStarting = false
    var height = -14f
    var aniHeight = -14f
    lateinit var username1: String
    var rank = Rank.User;
    // Managers
    lateinit var irc: ClientIRC
    lateinit var ircGui: IRCGui
    lateinit var tipSoundManager: TipSoundManager
    lateinit var moduleManager: ModuleManager

    lateinit var commandManager: CommandManager
    lateinit var eventManager: EventManager
    lateinit var fileManager: FileManager
    lateinit var scriptManager: ScriptManager
    lateinit var combatManager: CombatManager
    lateinit var fontLoaders: FontLoaders
    var USERNAME = ""
    var QQ = ""
    var group = ""
    // HUD & ClickGUI

    lateinit var hud: HUD

    lateinit var clickGui: ClickGui
    lateinit var op: OP
    var background: IResourceLocation? = null
    var mainMenuPrep = false
    lateinit var wrapper: Wrapper
    lateinit var Password: String
    fun setUsername(username: String) {
        this.USERNAME = username
    }
    var configchose = 0

    @JvmStatic
    var state: String = ""
    @JvmStatic
    var state2: String = ""

    lateinit var chooselanuage:Any
    var visable = true

    override  fun transform(
        loader: ClassLoader?, className: String, classBeingRedefined: Class<*>?,
        protectionDomain: ProtectionDomain?, classfileBuffer: ByteArray?
    ): ByteArray? {
        // 检查是否要对当前类进行修改
        return if (isXBootAgent(className)) {
            // 禁用XBoot Agent
            null
        } else classfileBuffer
        // 不需要修改该类
    }

    private fun isXBootAgent(className: String): Boolean {
        // 检查类名是否为XBoot Agent
        return className == "com.alibaba.xhook.XHookImpl"
    }
    /**
     * Execute if client will be started
     */
    fun startClient() {


        isStarting = true
        var ref: Unsafe? = null

        // fuck agent
        fun getInstrumentation(): Instrumentation? {
            return try {
                Instrumentation::class.java.getMethod("getInstrumentation").invoke(null) as Instrumentation?
            } catch (e: java.lang.Exception) {
                null
            }
        }

        val inst: Instrumentation? = getInstrumentation()

        // 检查 -javaagent
        if (inst != null) {
            System.exit(-1)
            Display.destroy()
            initClient()

        } else {
            try {
                QQCheek.getQQ()

                if (!QQCheek.QQNumber.equals("{")) {
                    Firstcheck.Update4()
                    DrawArc.helper = "checkyou789007535678llloiygjiufgaserf"
                    Client.regSocket()
                    state = "Wait for login"
                    eventManager =  EventManager()

                    fileManager = FileManager()


                    Fonts.lfont()
                    CustomUI.Chinese.set(false)

                    Display.setTitle("Autumn | Not logged in")
                    val options = arrayOf<Any>("开端", "注入")
                    val `object` = JOptionPane.showInputDialog(
                        null, "请选择启动方式", "启动", JOptionPane.QUESTION_MESSAGE, null, options,
                        options[0]
                    )
                    if (`object` == "注入") {
                        state2 = "注入"
                    } else if (`object` == "开端") {
                        System.out.println("Load GuiLogin")
                    } else {
                        JOptionPane.showInputDialog(null, "请选择启动方式!", "Error", JOptionPane.ERROR_MESSAGE)
                        System.exit(1)
                    }

                } else {
                    JOptionPane.showMessageDialog(
                        null,
                        "QQ或Tim未启动",
                        "失败",
                        JOptionPane.ERROR_MESSAGE
                    )
                    System.exit(1)
                }


            } catch (e: ClassNotFoundException) {
                System.exit(-1)
                e.printStackTrace()
            } catch (e: IllegalAccessException) {
                System.exit(-1)
                e.printStackTrace()
            } catch (e: NoSuchFieldException) {
                System.exit(-1)
                e.printStackTrace()
            }
        }
    }
    @JvmStatic
    fun stopClient() {
        state = "Logging in"
        var time = 0

        if (Firstcheck.getHWID().equals (Client.get())) {
            if (state2 == "注入"){
                MySQLDemo.reg()
                GuiLogin.anim *= 10
                GuiLogin.b = 10
                GuiLogin.encoder = Base64.getEncoder()
                GuiLogin.decoder = Base64.getDecoder()


                irc = ClientIRC()
                ircGui = IRCGui()
                val uSERNAME = JOptionPane.showInputDialog("请输入账号")
                val password = JOptionPane.showInputDialog("请输入密码")
                USERNAME = uSERNAME
                Password = password
            }

            MySQLDemo.getname = USERNAME
            if (MySQLDemo.getname != null) {
                MySQLDemo.UpdateHwid(MySQLDemo.getname)
                if (USERNAME.equals(MySQLDemo.X2name(MySQLDemo.getname))) {
                    if (Password.equals(MySQLDemo.X2pass(MySQLDemo.getname))) {
                        try {
                            if (MySQLDemo.X2black(MySQLDemo.getname)) {
                                if (MySQLDemo.X2Black(MySQLDemo.getname).equals("NO")) {
                                    MySQLDemo.X2QQ(MySQLDemo.getname)
                                    if (MySQLDemo.X2Hwid(MySQLDemo.getname) == MySQLDemo.getHWID1()) {
                                        MySQLDemo.Update9()
                                        QQ = QQCheek.QQNumber.toString()
                                        //check version
                                        C0347SystemUtils.displayTray(
                                            "Successful",
                                            "登陆成功",
                                            TrayIcon.MessageType.INFO
                                        )
                                        println("OK")
                                        time = Client.anInt
                                        if (time < 1) {
                                            C0347SystemUtils.displayTray(
                                                "卡密",
                                                "卡密剩余时间不到1天请你及时充值",
                                                TrayIcon.MessageType.WARNING
                                            )
                                            JOptionPane.showMessageDialog(
                                                null,
                                                "卡密剩余时间不到1天请你及时充值",
                                                "卡密",
                                                JOptionPane.WARNING_MESSAGE
                                            )
                                        } else {
                                            C0347SystemUtils.displayTray(
                                                "Hello",
                                                "User " + USERNAME + " You card residue " + time + " day",
                                                TrayIcon.MessageType.INFO
                                            )
                                        }
                                        val sdf = SimpleDateFormat(" yyyy-MM-dd HH:mm:ss")
                                        val time2 = (sdf.format(System.currentTimeMillis()))
                                        WbxMain.cheakuser()
                                        username1 = MySQLDemo.getname!!
                                        MySQLDemo.Update11()
                                        MySQLDemo.Update11()
                                        MySQLDemo.Update5(username1, time2)
                                        MySQLDemo.Update7(username1)
                                        MySQLDemo.Update4("Null", "127.0.0.1")

                                        DrawArc.helper = "checkyou789007535678llloiygjiufgaserf"
                                        ClientUtils.getLogger()
                                            .info("Starting $CLIENT_NAME b$CLIENT_VERSION, by $CLIENT_CREATOR")
                                        //TODO:HERE
                                        // Create file manager
                                        val groupcheck = WbxMain.cheakuser()
                                        val start = System.currentTimeMillis()

                                        if (groupcheck == 2) {
                                            C0347SystemUtils.displayTray(
                                                "Notification",
                                                "Hello Dev " + USERNAME,
                                                TrayIcon.MessageType.INFO
                                            )
                                            rank = Rank.Dev
                                            group = "Dev"
                                        } else if (groupcheck == 3) {
                                            C0347SystemUtils.displayTray(
                                                "Notification",
                                                "Hello Tester " + USERNAME,
                                                TrayIcon.MessageType.INFO
                                            )
                                            rank = Rank.Tester
                                            group = "Tester"
                                        } else if (groupcheck == 1) {
                                            C0347SystemUtils.displayTray(
                                                "Notification",
                                                "Hello Contributor " + USERNAME,
                                                TrayIcon.MessageType.INFO
                                            )
                                            group = "Contributor"
                                        } else {
                                            group = "User"

                                        }
                                        irc = ClientIRC()
                                        ClientIRC.connect()

                                        Fonts.loadFonts()
                                        FontLoaders.initFonts()
                                        // Create combat manager
                                        combatManager = CombatManager()
                                        moduleManager = ModuleManager()
                                        commandManager = CommandManager()

                                        fontLoaders = FontLoaders()
                                        // Register listeners
                                        eventManager.registerListener(RotationUtils())
                                        eventManager.registerListener(AntiForge())
                                        eventManager.registerListener(BungeeCordSpoof())
                                        eventManager.registerListener(InventoryUtils())
                                        eventManager.registerListener(combatManager)
                                        eventManager.registerListener(MemoryManager())
                                        eventManager.registerListener(MusicManager())
                                        eventManager.registerListener(BlurEvent())
                                        // Set HUD
                                        hud = createDefault()
                                        fileManager.loadConfig(fileManager.hudConfig)
                                        GuiCapeManager.load()

                                        tipSoundManager = TipSoundManager()
                                        // Setup module manager and register modules
                                        // Remapper
                                        try {
                                            loadSrg()

                                            // ScriptManager
                                            scriptManager = ScriptManager()
                                            scriptManager.loadScripts()
                                            scriptManager.enableScripts()
                                        } catch (throwable: Throwable) {
                                            ClientUtils.getLogger().error("Failed to load scripts.", throwable)
                                        }
                                        configchose = Configchose.chooseconfig()

                                        // Register commands
                                        registerCommands()



                                        registerModules()
                                        IRCHelper()

                                        // ClickGUI
                                        clickGui = ClickGui()
                                        op = OP.getInstance()
                                        // Disable Optifine fast render


                                        fileManager.loadConfigs(
                                            fileManager.accountsConfig,
                                            fileManager.friendsConfig,
                                            fileManager.xrayConfig,
                                            fileManager.valuesConfig
                                        )
                                        ClientUtils.disableFastRender()

                                        // Load generators
                                        GuiAltManager.loadGenerators()

                                        ClientUtils.getLogger()
                                            .info("Loaded client in " + (System.currentTimeMillis() - start) + " ms.")

                                        Display.setTitle("Autumn | " + USERNAME + " | Have a good time.")
                                        Minecraft.getMinecraft().displayGuiScreen(GuiMainMenu())

                                        isStarting = false


                                    }else {
                                        val chose: Int
                                        val options = arrayOf("Yes", "No")
                                        val kami: String = JOptionPane.showInputDialog(
                                            null,
                                            "账户绑定的HWID与当前HWID不符,请输入激活时的卡密",
                                            "Error",
                                            JOptionPane.QUESTION_MESSAGE
                                        )
                                        if (kami == MySQLDemo.X2card()) {
                                            chose = JOptionPane.showOptionDialog(
                                                null,
                                                "成功验证,你要修改HWID吗?",
                                                "Update",
                                                JOptionPane.DEFAULT_OPTION,
                                                JOptionPane.INFORMATION_MESSAGE,
                                                null,
                                                options,
                                                options.get(0)
                                            )
                                            if (chose == 0) {
                                                MySQLDemo.ChangeHwid()
                                                JOptionPane.showMessageDialog(
                                                    null,
                                                    "修改成功",
                                                    "成功",
                                                    JOptionPane.INFORMATION_MESSAGE
                                                )
                                                stopClient()
                                            } else if (chose == 1) {
                                                JOptionPane.showMessageDialog(
                                                    null,
                                                    "修改取消",
                                                    "失败",
                                                    JOptionPane.ERROR_MESSAGE
                                                )
                                                stopClient()
                                            }
                                        } else {
                                            JOptionPane.showMessageDialog(
                                                null,
                                                "卡密错误请联系管理员",
                                                "失败",
                                                JOptionPane.ERROR_MESSAGE
                                            )
                                            state = "Error:0008"
                                        }
                                    }

                                } else {
                                    JOptionPane.showMessageDialog(null, "账户被拉入黑名单", "错误", 0)
                                    state = "账户被拉入黑名单"

                                }
                            }else{
                                JOptionPane.showMessageDialog(null, "此电脑信息在黑名单当中", "错误", 0)
                                state = "此电脑信息在黑名单当中"
                            }
                        } catch (e: IOException) {
                            JOptionPane.showMessageDialog(
                                null,
                                "未知错误",
                                "失败",
                                JOptionPane.ERROR_MESSAGE
                            )
                            state = "未知错误"

                        }

                    } else {
                        JOptionPane.showMessageDialog(null, "密码错误", "错误", 0)
                        state = "密码错误"

                    }
                } else {
                    JOptionPane.showMessageDialog(null, "账户错误", "错误", 0)
                    state = "账户错误"

                }
            }else{
                JOptionPane.showInputDialog("错误","账户不存在")
            }
        }else {
            Firstcheck.Update4()

            JOptionPane.showMessageDialog(
                null,
                "许可未激活,但已发送请求",
                "failed",
                JOptionPane.ERROR_MESSAGE
            )

        }

    }

    fun registerCommands() {
        if (Firstcheck.getHWID().equals(verify.Client.get())) {

            val configchose = configchose

            commandManager.registerCommand(JammingCommand())
            commandManager.registerCommand(BindCommand())
            commandManager.registerCommand(VClipCommand())
            commandManager.registerCommand(HClipCommand())
            commandManager.registerCommand(HelpCommand())
            commandManager.registerCommand(SayCommand())
            commandManager.registerCommand(FriendCommand())
            commandManager.registerCommand(ServerInfoCommand())
            commandManager.registerCommand(ToggleCommand())
            commandManager.registerCommand(TargetCommand())
            commandManager.registerCommand(IRCCommand())
            commandManager.registerCommand(BindsCommand())
            commandManager.registerCommand(PingCommand())
            commandManager.registerCommand(RenameCommand())
            commandManager.registerCommand(ReloadCommand())
            commandManager.registerCommand(ScriptManagerCommand())
            commandManager.registerCommand(RemoteViewCommand())
            commandManager.registerCommand(PrefixCommand())
            commandManager.registerCommand(HideCommand())
            commandManager.registerCommand(ConfigCommand())
            commandManager.registerCommand(HudCommand())
            commandManager.registerCommand(ConfigCommand())
            if (configchose == 114514) {
                commandManager.registerCommand(ConfigSettingsCommand)
            } else if (configchose == 980340) {
                commandManager.registerCommand(ConfigSettingsCommand)
            }
        }

    }
    fun registerModules() {
        if (Firstcheck.getHWID().equals(verify.Client.get())) {
            ClientUtils.getLogger().info("[ModuleManager] Loading modules...")
            RegModule.module()
            //player
            for (i in RegModule.player.split(",".toRegex()).dropLastWhile { it.isEmpty() }.toTypedArray().indices) {
                moduleManager.registerModule(
                    Class.forName(
                        "net.ccbluex.liquidbounce.features.module.modules.player." + (RegModule.player.split(
                            ",".toRegex()
                        ).dropLastWhile { it.isEmpty() }.toTypedArray()[i])
                    ).newInstance() as Module
                )
            }
            //combat
            for (i in RegModule.combat.split(",".toRegex()).dropLastWhile { it.isEmpty() }.toTypedArray().indices) {
                moduleManager.registerModule(
                    Class.forName(
                        "net.ccbluex.liquidbounce.features.module.modules.combat." + (RegModule.combat.split(
                            ",".toRegex()
                        ).dropLastWhile { it.isEmpty() }.toTypedArray()[i])
                    ).newInstance() as Module
                )
            }
            //movement
            for (i in RegModule.movement.split(",".toRegex()).dropLastWhile { it.isEmpty() }.toTypedArray().indices) {
                moduleManager.registerModule(
                    Class.forName(
                        "net.ccbluex.liquidbounce.features.module.modules.movement." + (RegModule.movement.split(
                            ",".toRegex()
                        ).dropLastWhile { it.isEmpty() }.toTypedArray()[i])
                    ).newInstance() as Module
                )
            }
            //world
            for (i in RegModule.world.split(",".toRegex()).dropLastWhile { it.isEmpty() }.toTypedArray().indices) {
                moduleManager.registerModule(
                    Class.forName(
                        "net.ccbluex.liquidbounce.features.module.modules.world." + (RegModule.world.split(
                            ",".toRegex()
                        ).dropLastWhile { it.isEmpty() }.toTypedArray()[i])
                    ).newInstance() as Module
                )
            }



            //hyt
            for (i in RegModule.hyt.split(",".toRegex()).dropLastWhile { it.isEmpty() }.toTypedArray().indices) {
                moduleManager.registerModule(
                    Class.forName(
                        "net.ccbluex.liquidbounce.features.module.modules.hyt." + (RegModule.hyt.split(
                            ",".toRegex()
                        ).dropLastWhile { it.isEmpty() }.toTypedArray()[i])
                    ).newInstance() as Module
                )
            }
            //exploit
            for (i in RegModule.exploit.split(",".toRegex()).dropLastWhile { it.isEmpty() }.toTypedArray().indices) {
                moduleManager.registerModule(
                    Class.forName(
                        "net.ccbluex.liquidbounce.features.module.modules.exploit." + (RegModule.exploit.split(
                            ",".toRegex()
                        ).dropLastWhile { it.isEmpty() }.toTypedArray()[i])
                    ).newInstance() as Module
                )
            }
            //misc
            for (i in RegModule.misc.split(",".toRegex()).dropLastWhile { it.isEmpty() }.toTypedArray().indices) {
                moduleManager.registerModule(
                    Class.forName(
                        "net.ccbluex.liquidbounce.features.module.modules.misc." + (RegModule.misc.split(
                            ",".toRegex()
                        ).dropLastWhile { it.isEmpty() }.toTypedArray()[i])
                    ).newInstance() as Module
                )
            }


            //render
            for (i in RegModule.render.split(",".toRegex()).dropLastWhile { it.isEmpty() }.toTypedArray().indices) {
                moduleManager.registerModule(
                    Class.forName(
                        "net.ccbluex.liquidbounce.features.module.modules.render." + (RegModule.render.split(
                            ",".toRegex()
                        ).dropLastWhile { it.isEmpty() }.toTypedArray()[i])
                    ).newInstance() as Module
                )
            }
            //cn
            for (i in RegModule.cn.split(",".toRegex()).dropLastWhile { it.isEmpty() }.toTypedArray().indices) {
                moduleManager.registerModule(
                    Class.forName(
                        "cn.client.modules." + (RegModule.cn.split(",".toRegex()).dropLastWhile { it.isEmpty() }
                            .toTypedArray()[i])
                    ).newInstance() as Module
                )
            }
            //cn
            for (i in RegModule.cn2.split(",".toRegex()).dropLastWhile { it.isEmpty() }.toTypedArray().indices) {
                moduleManager.registerModule(
                    Class.forName(
                        RegModule.cn2.split(",".toRegex()).dropLastWhile { it.isEmpty() }.toTypedArray()[i]
                    ).newInstance() as Module
                )
            }

            moduleManager.registerModule(Rotations)
            moduleManager.registerModule(NoScoreboard)
            moduleManager.registerModule(Fucker)
            moduleManager.registerModule(ChestAura)
            moduleManager.registerModule(net.ccbluex.liquidbounce.features.module.modules.render.HUD)
            moduleManager.registerModule(UIEffects)

            ClientUtils.getLogger().info("[ModuleManager] Loaded ${moduleManager.modules.size} modules.")
            Client.close()

        }
    }

    /**
     * Execute if client will be stopped
     */
    fun initClient() {
        // Save all available configs
        GuiCapeManager.save()
        fileManager.saveAllConfigs()
        MySQLDemo.Update8()
        MySQLDemo.Update3()
        val sdf=   SimpleDateFormat(" yyyy-MM-dd HH:mm:ss");
        val time2  = (sdf.format(System.currentTimeMillis()));
        MySQLDemo.Update6(time2)
        MySQLDemo.dereg()
        val file = File(fileManager.dir, "friends.json")
        file.writeText("")
        file.writeText("[]")
        try {
            if (ClientIRC.socket != null) {
                ClientIRC.socket.close()
            }
        } catch (e: IOException) {
            throw RuntimeException(e)
        }
    }
}
enum class Rank{
    Dev,User,Tester
}