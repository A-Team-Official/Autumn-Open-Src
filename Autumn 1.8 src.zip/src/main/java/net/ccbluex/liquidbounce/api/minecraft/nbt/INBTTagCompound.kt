
package net.ccbluex.liquidbounce.api.minecraft.nbt

import net.minecraft.nbt.NBTTagCompound

interface INBTTagCompound : INBTBase {
    fun hasKey(name: String): Boolean
    fun hasKey(name: String , int: Int): Boolean
    fun getShort(name: String): Short
    fun setString(key: String, value: String)
    fun setTag(key: String, tag: INBTBase)
    fun setInteger(key: String, value: Int)
    fun getCompoundTag(string: String): NBTTagCompound
}