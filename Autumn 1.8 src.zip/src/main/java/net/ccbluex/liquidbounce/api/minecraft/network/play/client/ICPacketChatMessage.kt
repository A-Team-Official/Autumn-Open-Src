
package net.ccbluex.liquidbounce.api.minecraft.network.play.client

interface ICPacketChatMessage {
    var message: String
}