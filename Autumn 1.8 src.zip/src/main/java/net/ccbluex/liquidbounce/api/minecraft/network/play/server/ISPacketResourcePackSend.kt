
package net.ccbluex.liquidbounce.api.minecraft.network.play.server

interface ISPacketResourcePackSend {
    val url: String
    val hash: String
}