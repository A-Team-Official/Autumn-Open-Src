
package net.ccbluex.liquidbounce.api.minecraft.util

interface IChatComponentText : IIChatComponent