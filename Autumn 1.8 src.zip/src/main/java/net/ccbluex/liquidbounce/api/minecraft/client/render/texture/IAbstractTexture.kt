
package net.ccbluex.liquidbounce.api.minecraft.client.render.texture

interface IAbstractTexture