
package net.ccbluex.liquidbounce.api.enums

enum class StatType {
    JUMP_STAT
}