
package net.ccbluex.liquidbounce.api.enums

enum class EnumFacingType {
    DOWN,
    UP,
    NORTH,
    SOUTH,
    WEST,
    EAST
}