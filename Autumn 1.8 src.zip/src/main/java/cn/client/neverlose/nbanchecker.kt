package cn.client.neverlose

import cn.client.oth.tenacity.blur.Bloom
import cn.client.oth.tenacity.blur.BlurBuffer
import cn.client.utils.Color.modules.CustomUI
import net.ccbluex.liquidbounce.Client
import net.ccbluex.liquidbounce.ui.client.hud.element.Border
import net.ccbluex.liquidbounce.ui.client.hud.element.Element
import net.ccbluex.liquidbounce.ui.client.hud.element.ElementInfo
import cn.client.novoline.ui.InfosUtils.Recorder
import net.ccbluex.liquidbounce.ui.cnfont.FontLoaders
import net.ccbluex.liquidbounce.ui.font.Fonts
import net.ccbluex.liquidbounce.utils.render.RoundedUtil
import org.lwjgl.opengl.GL11
import java.awt.Color

@cn.obf.Native
@ElementInfo(name = "N-BanChcker")
class NBanChecker() : Element() {


    override fun drawElement(): Border {
        var width = 90f
        var height = 64f
        if (CustomUI.Blur.get()){
            val floatX = renderX.toFloat()
            val floatY = renderY.toFloat()
            GL11.glTranslated(-renderX, -renderY, 0.0)
            GL11.glPushMatrix()
            BlurBuffer.CustomBlurRoundArea(floatX, floatY,width, height, CustomUI.radius.get())
            GL11.glPopMatrix()
            GL11.glTranslated(renderX, renderY, 0.0)
        }
        if (CustomUI.Shadow.get()){
            var floatX = renderX.toFloat()
            var floatY = renderY.toFloat()
            GL11.glTranslated(-renderX, -renderY, 0.0)
            GL11.glPushMatrix()
            Bloom.shadow {
                RoundedUtil.drawRound(floatX, floatY, width, height, CustomUI.radius.get(), Color(29,40,53))
            }
            GL11.glPopMatrix()
            GL11.glTranslated(renderX, renderY, 0.0)
        }
        RoundedUtil.drawRound(
                0f,
                0f,
                width,
                height,
                CustomUI.radius.get(),
                Color(29,40,53,CustomUI.a.get())
        )

            Fonts.icon40.drawString("o",4f,7f,Color(14,102,155).rgb)
            Fonts.mousesans35.drawString("Ban Checker",Fonts.icon40.getStringWidth("o")+7, 8, Color.WHITE.rgb)
            Fonts.mousesans35.drawString("Baned: ${Recorder.ban}",6, 5 + FontLoaders.F18.FONT_HEIGHT, Color.WHITE.rgb)
            Fonts.mousesans35.drawString("Wins: ${Recorder.win}",6, 2 + FontLoaders.F18.FONT_HEIGHT * 2, Color.WHITE.rgb)
            Fonts.mousesans35.drawString("Kills: ${Client.combatManager.kills}",6,  FontLoaders.F18.FONT_HEIGHT *3, Color.WHITE.rgb)
        return Border(0f, 0f, width, height, CustomUI.radius.get())
    }
}