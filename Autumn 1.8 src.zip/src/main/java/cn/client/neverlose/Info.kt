package cn.client.neverlose

import cn.client.utils.Color.modules.CustomUI
import net.ccbluex.liquidbounce.Client
import net.ccbluex.liquidbounce.ui.client.hud.element.Border
import net.ccbluex.liquidbounce.ui.client.hud.element.Element
import net.ccbluex.liquidbounce.ui.client.hud.element.ElementInfo
import net.ccbluex.liquidbounce.ui.font.Fonts
import net.ccbluex.liquidbounce.utils.render.RoundedUtil
import java.awt.Color

@ElementInfo(name = "About")
class Info(x: Double = 700.0, y: Double = 220.0, scale: Float = 1F) : Element(x, y, scale) {
    val width = 165f
    val height = 170F
    override fun drawElement(): Border {
        if (mc2.currentScreen is cn.client.neverlose.yuanshen.OP) {
            RoundedUtil.drawRound(0f, 0f, width, height, CustomUI.radius.get(),Color(14,18,20, 190))
            Fonts.icon40.drawString(
                "i",
                3f,
                3F,
                Color(0, 64, 105).rgb
            )
            Fonts.mousesans35.drawString(
                "About Autumn",
                Fonts.icon40.getStringWidth("i") + 4,
                4,
                Color(145, 148, 145).rgb
            )
            Fonts.never900_100.drawCenteredString("Autumn.Cn", width / 2f, 30f, Color.WHITE.rgb)
            Fonts.mousesans40.drawString("Version: ", 7f, 70f, Color.WHITE.rgb)
            Fonts.mousesans40.drawString(
                Client.CLIENT_VERSION,
                Fonts.mousesans40.getStringWidth("Version: ") + 7f,
                70f,
                Color(0, 100, 200).rgb
            )
            Fonts.mousesans40.drawString("Your Group: ", 7f, 70f + Fonts.mousesans40.fontHeight + 4f, Color.WHITE.rgb)
            Fonts.mousesans40.drawString(
                Client.group,
                Fonts.mousesans40.getStringWidth("Your Group: ") + 7f,
                70f + Fonts.mousesans40.fontHeight + 4f,
                Color(0, 100, 200).rgb
            )
            Fonts.mousesans40.drawString("UserName: ", 7f, 70 + Fonts.mousesans40.fontHeight * 2 + 8f, Color.WHITE.rgb)
            Fonts.mousesans40.drawString(
                Client.username1,
                Fonts.mousesans40.getStringWidth("UserName: ") + 7f,
                70 + Fonts.mousesans40.fontHeight * 2 + 8f,
                Color(0, 100, 200).rgb
            )
            Fonts.mousesans40.drawString(
                "Build Dev: ",
                7f,
                70 + Fonts.mousesans40.fontHeight * 3 + 12f,
                Color.WHITE.rgb
            )
            Fonts.mousesans40.drawString(
                "@A-Team",
                Fonts.mousesans40.getStringWidth("Build Dev: ") + 7f,
                70 + Fonts.mousesans40.fontHeight * 3 + 12f,
                Color(0, 100, 200).rgb
            )
            Fonts.mousesans35.drawCenteredString(
                "Autumn.Dev.Build @ 2023",
                (width / 2f) + 1f,
                70 + Fonts.mousesans40.fontHeight * 4 + 30f,
                Color(145, 148, 145).rgb
            )
            Fonts.never900_45.drawCenteredString(
                "A-Team Love You",
                width / 2f,
                140 + Fonts.mousesans40.fontHeight + 8f,
                Color(0, 64, 105).rgb
            )
        }
        return Border(0f,0f,width,height,CustomUI.radius.get())
    }
}