//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package cn.client.neverlose.yuanshen.settings;

import cn.client.neverlose.yuanshen.Downward;
import cn.client.neverlose.yuanshen.ModuleRender;
import cn.client.neverlose.yuanshen.OP;
import net.ccbluex.liquidbounce.ui.cnfont.FontLoaders;
import net.ccbluex.liquidbounce.utils.render.RenderUtils;
import net.ccbluex.liquidbounce.value.BoolValue;

import java.awt.*;




public class OptionSetting extends Downward<BoolValue> {
    public int mainx;
    public int mainy;
    public int y;

    public OptionSetting(BoolValue s, float x, float y, int width, int height, ModuleRender moduleRender) {
        super(s, x, y, width, height, moduleRender);
    }

    public void draw(int mouseX, int mouseY) {
        this.mainx = OP.mainx;
        this.mainy = OP.mainy;
        this.y = (int)(this.pos.y + (float)this.getScrollY());
        FontLoaders.msr18.drawString(this.setting.getName(), (float)(this.mainx + 17) + this.pos.x, (float)(this.mainy + 38 + this.y), new Color(130,140,150).getRGB());

        if(this.setting.get()) {
            RenderUtils.drawRoundedRect((float)(this.mainx + 138) + this.pos.x - 3f, (float)(this.mainy + 38 + this.y), (float)(this.mainx + 143) + this.pos.x+8.0F,(float)(this.mainy + 38 + this.y)+ 8.0F, 3f,new Color(4,22,45).getRGB());
            RenderUtils.drawGoodCircle((double)((float)this.mainx + 150.5F + this.pos.x), (double)((float)this.mainy + 41.5F + (float)this.y), 6, (new Color(32,138,209)).getRGB());
        }
        else {
            RenderUtils.drawRoundedRect((float)(this.mainx + 138) + this.pos.x - 3f, (float)(this.mainy + 38 + this.y), (float)(this.mainx + 143) + this.pos.x+10f,(float)(this.mainy + 38 + this.y)+ 8.0F, 3f,new Color(5,23,37).getRGB());
            RenderUtils.drawGoodCircle((double)((float)this.mainx + 138f + this.pos.x), (double)((float)this.mainy + 41.5F + (float)this.y), 6, (new Color(124,139,149).getRGB()));
        }

    }

    public void mouseClicked(int mouseX, int mouseY, int mouseButton) {
        if (RenderUtils.isHovering((float)(this.mainx + 138) + this.pos.x -3f, (float)(this.mainy + 38 + this.y),this.mainx+ 16F, 8.0F, mouseX, mouseY) && mouseButton == 0) {
            ((BoolValue)this.setting).set(!(boolean)setting.get());;
        }

    }

    public void mouseReleased(int mouseX, int mouseY, int state) {
    }
}
