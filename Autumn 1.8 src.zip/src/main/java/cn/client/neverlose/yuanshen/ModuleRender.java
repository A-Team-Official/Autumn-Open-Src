//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package cn.client.neverlose.yuanshen;


import cn.client.neverlose.yuanshen.settings.*;
import net.ccbluex.liquidbounce.features.module.Module;
import net.ccbluex.liquidbounce.ui.font.Fonts;
import net.ccbluex.liquidbounce.utils.render.RenderUtils;
import net.ccbluex.liquidbounce.value.*;

import java.awt.*;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;




public class ModuleRender {
    public Module module;
    public int height = 0;
    public float y;
    public float x;
    public int mainx;
    public int mainy;
    public int scrollY = 0;
    public List<Downward> downwards;
    private Position pos;
    private final float modX;
    private final float modY;
    private final float w;

    public ModuleRender(Module module, float modX, float modY, float w, float h) {
        this.module = module;
        this.downwards = new ArrayList();
        this.modX=modX;
        this.modY=modY;
        this.w=w;
        int cHeight = 28;
        Iterator var7 = module.getValues().iterator();


        while(var7.hasNext()) {
            Value setting = (Value)var7.next();
            if (setting instanceof BoolValue) {
                this.downwards.add(new OptionSetting((BoolValue)setting, modX, modY + (float)cHeight, 0, 0, this));
                cHeight += 20;
            }

            if (setting instanceof IntegerValue) {
                this.downwards.add(new NumberSetting((IntegerValue)setting, modX, modY + (float)cHeight, 0, 0, this));
                cHeight += 20;
            }

            if (setting instanceof FloatValue) {
                this.downwards.add(new FloatSetting((FloatValue) setting, modX, modY + (float)cHeight, 0, 0, this));
                cHeight += 20;
            }

            if (setting instanceof ListValue) {
                this.downwards.add(new StringsSetting((ListValue)setting, modX, modY + (float)cHeight, 0, 0, this));
                cHeight += 20;
            }

            if (setting instanceof TextValue) {
                this.downwards.add(new TextSetting((TextValue) setting, modX, modY+cHeight, 0, 0,this));
                cHeight += 20;
            }

            if (setting instanceof ColorValue) {
                this.downwards.add(new colorSetting((ColorValue) setting, modX, modY+cHeight, 0, 0,this));
                cHeight += 20;
            }

        }
        this.height = cHeight;

        this.pos = new Position(modX, modY, w, (float)cHeight);

    }

    public void draw(int mx, int my) {


    	 this.mainx = OP.mainx;
         this.mainy = OP.mainy;
        this.x = this.pos.x;
        this.y = this.pos.y + (float)this.scrollY;

        RenderUtils.drawRoundedRect((float)(this.mainx + 10) + this.x, (float)(this.mainy + 35) + this.y,(float)(this.mainx + 10) + this.x+ 160.0F,(float)(this.mainy + 35) + this.y+ this.pos.height, 2, new Color(14,18,20, 255).getRGB());
//        RenderUtils.drawRect((float)(this.mainx + 12) + this.x, (float)(this.mainy + 35) + this.y+20,(float)(this.mainx + 10) + this.x+ 158.0F,(float)(this.mainy + 35) + this.y+ 21,  new Color(6,18,31, 255).getRGB());
        Fonts.mousesans40.drawString(this.module.getName(), (float)(this.mainx + 17) + this.x, (float)(this.mainy +42) + this.y, Color.WHITE.getRGB());
     //   FontLoaders.msr18.drawString("Enable", var10002, var10003, new Color(130,140,150).getRGB());

        if (this.module.getState()) {
            RenderUtils.drawRoundedRect((float)(this.mainx + 138) + this.pos.x - 3f, (float)(this.mainy + 40) + this.y, (float)(this.mainx + 143) + this.pos.x+8.0F,(float)(this.mainy + 40) + this.y+8.0F, 3f,new Color(4,22,45).getRGB());
            RenderUtils.drawGoodCircle((double)((float)this.mainx + 150.5F + this.pos.x), (double)((float)this.mainy + 43f + (float)this.y), 6, (new Color(32,138,209)).getRGB());
        }
        else {
            RenderUtils.drawRoundedRect((float)(this.mainx + 138) + this.pos.x - 3f,(float)(this.mainy + 40) + this.y, (float)(this.mainx + 143) + this.pos.x+10f,(float)(this.mainy + 40) + this.y+8.0F, 3f,new Color(5,23,37).getRGB());
            RenderUtils.drawGoodCircle((double)((float)this.mainx + 138f + this.pos.x), (double)((float)this.mainy + 43f + (float)this.y), 6, (new Color(124,139,149).getRGB()));
        }
        
        this.downwards.forEach((e) -> {
            e.draw(mx, my);
        });
    }

    public void mouseClicked(int mouseX, int mouseY, int mouseButton) {
        if (mouseButton == 0 && RenderUtils.isHovering((float)(this.mainx + 138) + this.x, (float)(this.mainy + 40) + this.y, 18F, 8.0F, mouseX, mouseY)) {
            this.module.setState(!this.module.getState());
        }

        Iterator var4 = this.downwards.iterator();

        while(var4.hasNext()) {
            Downward downward = (Downward)var4.next();
            downward.mouseClicked(mouseX, mouseY, mouseButton);
        }

    }

    public void mouseReleased(int mouseX, int mouseY, int state) {
        this.downwards.forEach((e) -> {
            e.mouseReleased(mouseX, mouseY, state);
        });
    }

    public void keyTyped(char typedChar, int keyCode) {
        this.downwards.forEach((e) -> {
            e.keyTyped(typedChar, keyCode);
        });
    }

    public int getMaxScrollY() {
        return (int)((float)((int)this.pos.y) + this.pos.height);
    }

    public int getPosY() {
        return (int)this.pos.y;
    }

    public int getScrollY() {
        return this.scrollY;
    }
}
