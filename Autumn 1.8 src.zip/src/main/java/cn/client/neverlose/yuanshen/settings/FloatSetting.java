//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package cn.client.neverlose.yuanshen.settings;

import cn.client.neverlose.yuanshen.Downward;
import cn.client.neverlose.yuanshen.ModuleRender;
import cn.client.neverlose.yuanshen.OP;
import cn.client.utils.Color.MathUtils;
import net.ccbluex.liquidbounce.ui.cnfont.FontLoaders;
import net.ccbluex.liquidbounce.ui.font.Fonts;
import net.ccbluex.liquidbounce.utils.render.RenderUtils;
import net.ccbluex.liquidbounce.value.FloatValue;
import net.minecraft.util.math.MathHelper;

import java.awt.*;


public class FloatSetting extends Downward<FloatValue> {
    public int mainx;
    public int mainy;
    public int y;
    public float percent = 0.0F;
    private boolean iloveyou;

    public FloatSetting(FloatValue s, float x, float y, int width, int height, ModuleRender moduleRender) {
        super(s, x, y, width, height, moduleRender);
    }

    public void draw(int mouseX, int mouseY) {
        this.mainx = OP.mainx;
        this.mainy = OP.mainy;
        this.y = (int)(this.pos.y + (float)this.getScrollY());
        FontLoaders.msr18.drawString(((FloatValue)this.setting).getName(), (float)(this.mainx + 17) + this.pos.x, (float)(this.mainy + 38 + this.y), new Color(130, 140, 150).getRGB());

        RenderUtils.drawRect((float)(this.mainx + 91) + this.pos.x, (float)(this.mainy + 42 + this.y), (float)(this.mainx + 161) + this.pos.x, (float)(this.mainy + 44 + this.y), new Color(5, 23, 37).getRGB());

        double clamp = (double)MathHelper.clamp(300f, 1.0F, 9999.0F);
        double minValue = ((FloatValue)this.setting).getMinimum();
        double maxValue = ((FloatValue)this.setting).getMaximum();
        double range = maxValue - minValue;
        double value = ((FloatValue)this.setting).get().doubleValue();
        double percentBar = (value - minValue) / range;
        this.percent = (float) MathUtils.clamp((float) (this.percent + (MathUtils.clamp((float) percentBar, 0.0f, 1.0f) - this.percent) * (30 / clamp)), 0.0f, 1.0f);

        float startX = (float)(this.mainx + 91) + this.pos.x;
        float endX = (float)(this.mainx + 161) + this.pos.x;
        float barWidth = endX - startX;
        float barFillWidth = barWidth * this.percent;
        float barHeight = 5.0F;

        RenderUtils.drawRect(startX, (float)(this.mainy + 42 + this.y), startX + barFillWidth, (float)(this.mainy + 44 + this.y), new Color(12,102,146).getRGB());
        RenderUtils.drawGoodCircle(startX + barFillWidth, (float)(this.mainy + 42 + this.y),4f,new Color(54,134,242).getRGB());
        if (this.iloveyou) {
            float percentt = MathUtils.clamp((float)(mouseX - (startX + 1.0F)) / (barWidth - 1.0F), 0.0F, 1.0F);
            double newValue = (double)percentt * range + minValue;
            double set = MathUtils.roundToDecimalPlace(newValue, 1);
            ((FloatValue)this.setting).set(set);
        }

        String valueString = String.valueOf(((FloatValue)this.setting).get());
        String displayName = ((FloatValue)this.setting).getDisplayName();
        float textWidth = FontLoaders.msr18.getStringWidth(valueString + displayName);

        Fonts.mousesans35.drawString(valueString + displayName, startX + barFillWidth - textWidth, (float)this.mainy + 31.0F + (float)this.y, new Color(130, 140, 150).getRGB());
    }


    public void mouseClicked(int mouseX, int mouseY, int mouseButton) {
        if (RenderUtils.isHovering((float)(this.mainx + 91) + this.pos.x, (float)(this.mainy + 40 + this.y), 70.0F, 5.0F, mouseX, mouseY) && mouseButton == 0) {
            this.iloveyou = true;
        }

    }

    public void mouseReleased(int mouseX, int mouseY, int state) {
        if (state == 0) {
            this.iloveyou = false;
        }

    }
}
