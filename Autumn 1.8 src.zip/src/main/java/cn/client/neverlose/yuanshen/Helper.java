package cn.client.neverlose.yuanshen;

import net.ccbluex.liquidbounce.features.module.ModuleCategory;
import net.ccbluex.liquidbounce.utils.render.RenderUtils;

public class Helper {
    static ModuleCategory category;
    public static void helper(){

        if (category == ModuleCategory.COMBAT){
            OP.cnm =1;
        }
        if (category == ModuleCategory.PLAYER){
            OP.cnm =2;
        }
        if (category == ModuleCategory.MOVEMENT){
            OP.cnm =3;
        }
        if (category == ModuleCategory.RENDER){
            OP.cnm =4;
        }
        if (category == ModuleCategory.WORLD){
            OP.cnm =5;
        }
        if (category == ModuleCategory.MISC){
            OP.cnm =6;
        }
        if (category == ModuleCategory.EXPLOIT){
            OP.cnm =7;
        }
        if (category == ModuleCategory.COLOR){
            OP.cnm =8;
        }
        if (category == ModuleCategory.HYT){
            OP.cnm =9;
        }
        if (category == ModuleCategory.GUI) {
            OP.cnm = 10;
        }

        for (; OP.y4 <OP.cnm ; OP.y4++){
            OP.y22 = 28f * OP.y4;
        }
        for (; OP.y4 >OP.cnm ; OP.y4--){
            OP.y22 = 28f * OP.y4;
        }
        OP.y3 = (float) RenderUtils.getAnimationState2(OP.y3 ,OP.y22 , 200);
    }

}
