//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package cn.client.neverlose.yuanshen;

import net.ccbluex.liquidbounce.Client;
import net.ccbluex.liquidbounce.features.module.ModuleCategory;
import net.ccbluex.liquidbounce.features.module.modules.render.HUD;
import net.ccbluex.liquidbounce.ui.client.hud.designer.GuiHudDesigner;
import net.ccbluex.liquidbounce.ui.font.Fonts;
import net.ccbluex.liquidbounce.utils.MinecraftInstance;
import net.ccbluex.liquidbounce.utils.render.RenderUtils;
import net.ccbluex.liquidbounce.utils.render.tenacity.ColorUtil;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;

import java.awt.*;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import static net.ccbluex.liquidbounce.utils.MinecraftInstance.classProvider;


public class OP extends GuiScreen {
    public static int mainx = 300;
    public static int mainy = 110;
    private int x2;
    private int y2;
    public static OP getInstance() {
        return instance == null ? instance = new OP() : instance;
    }
    private boolean dragging;
    private final List<TypeScreen> types = new ArrayList();
    private final ResourceLocation hudIcon = new ResourceLocation(Client.CLIENT_NAME.toLowerCase() + "/custom_hud_icon.png");
    public static OP instance;
    public static float y22;
    public  static float y3;
    public static float y4;
    public static float cnm;


    @Override
    public void initGui() {
        super.initGui();

    }
    public OP() {
        int x = 0;
        ModuleCategory[] var2 = ModuleCategory.values();
        int var3 = var2.length;


        for(int var4 = 0; var4 < var3; var4++) {
            ModuleCategory category = var2[var4];
            this.types.add(new TypeScreen(category, x));
            x +=  28;

        }

    }



    public String newcatename(ModuleCategory moduleCategory) {
        return moduleCategory.getDisplayName();
    }
    @Override

    public void drawScreen(int mouseX, int mouseY, float partialTicks) {

        if (Mouse.isButtonDown(0) && mouseX >= 5 && mouseX <= 50 && mouseY <= height - 5 && mouseY >= height - 50)
            MinecraftInstance.mc.displayGuiScreen(classProvider.wrapGuiScreen(new GuiHudDesigner()));

        if (this.getSelectedTab() == null && !this.types.isEmpty()) {
            ((TypeScreen)this.types.get(0)).setSelected(true);
        }

        RenderUtils.drawImage(hudIcon, 9, height - 41, 32, 32);
        if (this.dragging) {
            mainx = this.x2 + mouseX;
            mainy = this.y2 + mouseY;
        }
        int a = 1;
        Color baseColor = new Color(14,18,20, 190);
        Color colorr = ColorUtil.interpolateColorC(baseColor, new Color(ColorUtil.applyOpacity(baseColor.getRGB(), .3f)), 0.5F);
        RenderUtils.drawRect((float)mainx,(float)(mainy + 325 - Fonts.mousesans35.getFontHeight()),(float) (mainx+ 100),(mainy + 325 - Fonts.mousesans35.getFontHeight() - 2),new Color(20,25,25).getRGB());
        RenderUtils.drawRoundedRect((float)mainx-105, (float)mainy, (float) (mainx+ 100),mainy+ 350.0F,5f,colorr.getRGB());
        //    RenderUtils.drawRoundedRect((float)mainx-80, (float)mainy, mainx, mainy+350.0F,  new Color(28, 28, 28, 180).getRGB());
        RenderUtils.drawRoundedRect((float)mainx, (float)mainy, mainx+350.0F, mainy+350.0F,5f,  new Color(9,8,14).getRGB());
        RenderUtils.drawRoundedRect((float)mainx, (float)mainy, mainx+250.0F, mainy+350.0F,0f,  new Color(9,8,14).getRGB());
        RenderUtils.drawRoundedRect((float)mainx+2, (float)mainy+30, mainx+348.0F, mainy+31.0F,0f,  new Color(40,40,40).getRGB());
        //RenderUtils.drawRoundedRect((float)(mainx + 348), (float)(mainy + 130), mainx+ 2.0F,mainy+ 20.0F,  new Color(28, 28, 28, 220).getRGB());
        //  RenderUtils.drawRect((float)mainx, (float)(mainy + 300), mainx+350.0F,mainy+ 20.0F,new Color(28, 28, 28, 220).getRGB());
        Fonts.mousesansbold65.drawCenteredString(HUD.clientname.get().toUpperCase(), (float)(mainx -51.5 ), (float)(mainy + 17),  (new Color(0,64,105)).getRGB());
        Fonts.mousesansbold65.drawCenteredString(HUD.clientname.get().toUpperCase(), (float)(mainx -50.5 ), (float)(mainy + 17),  (new Color(255, 255, 255)).getRGB());
        Date date = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");

        Fonts.mousesans30.drawString(Client.INSTANCE.getUSERNAME(), (float)(mainx -77 - a), (float)(mainy + 331), (new Color(107,111,114)).getRGB());
        Fonts.mousesans30.drawString("QQ: ", (float)(mainx -77 - a), (float)(mainy + 341),  (new Color(189,192,195)).getRGB());
        Fonts.mousesans30.drawString(Client.INSTANCE.getQQ(), (float)(mainx -75 - a + Fonts.mousesans30.getStringWidth("QQ: ")), (float)(mainy + 341),  (new Color(29,100,147)).getRGB());
        RenderUtils.drawRect((float)mainx-105,(float)(mainy + 326),(float) (mainx),(float)(mainy + 345),new Color(40,40,40).getRGB());

        RenderUtils.drawRect((float)mainx-105,(float)(mainy + 323),(float) (mainx),(float)(mainy + 324),new Color(40,40,40).getRGB());
        RenderUtils.drawCircleWithTexture((float)(mainx -90  - a),  (float)(mainy + 336), 0, 360, 10.0F, RenderUtils.getResourceLocation(Client.INSTANCE.getQQ()), Colors.WHITE.c);


        this.types.forEach((e) -> {
            e.draw(mouseX, mouseY);
        });

        Fonts.mousesans32.drawString("Main", (float)(mainx -90  - a), (float)(mainy + 42 + a),  (new Color(130,140,150)).getRGB());

        Fonts.mousesans32.drawString("Other", (float)(mainx -90  - a), (float)(mainy + 182 + a),  (new Color(130,140,150)).getRGB());

        Fonts.mousesans35.drawString("Combat", (float)(mainx -70  - a), (float)(mainy + 55 + a),  (new Color(255, 255, 255)).getRGB());

        Fonts.icon40.drawString("a", (float)(mainx -90 - a ), (float)(mainy + 55 + a),  (new Color(29,100,147)).getRGB());

        Fonts.mousesans35.drawString("Player ", (float)(mainx -70  - a), (float)(mainy + 83 + a),  (new Color(255, 255, 255)).getRGB());

        Fonts.icon40.drawString("d", (float)(mainx -90 - a ), (float)(mainy + 82 + a),  (new Color(29,100,147)).getRGB());

        Fonts.mousesans35.drawString("Movement", (float)(mainx -70 - a ), (float)(mainy + 111 + a),  (new Color(255, 255, 255)).getRGB());

        Fonts.icon40.drawString("f", (float)(mainx -90  - a), (float)(mainy + 111 + a),  (new Color(29,100,147)).getRGB());

        Fonts.mousesans35.drawString("Render", (float)(mainx -70  - a), (float)(mainy + 139 + a),  (new Color(255, 255, 255)).getRGB());

        Fonts.icon40.drawString("h", (float)(mainx -90 - a ), (float)(mainy + 139 + a),  (new Color(29,100,147)).getRGB());

        Fonts.mousesans35.drawString("World", (float)(mainx -70 - a ), (float)(mainy + 167 + a),  (new Color(255, 255, 255)).getRGB());

        Fonts.icon40.drawString("b", (float)(mainx -90  - a), (float)(mainy + 167 + a),  (new Color(29,100,147)).getRGB());

        Fonts.mousesans35.drawString("Misc", (float)(mainx -70  - a), (float)(mainy + 195 + a),  (new Color(255, 255, 255)).getRGB());

        Fonts.icon40.drawString("w", (float)(mainx -90  - a), (float)(mainy + 195 + a),  (new Color(29,100,147)).getRGB());

        Fonts.mousesans35.drawString("Exploit", (float)(mainx -70  - a), (float)(mainy + 223 + a),  (new Color(255, 255, 255)).getRGB());

        Fonts.icon40.drawString("g", (float)(mainx -90 - a), (float)(mainy + 223 + a),  (new Color(29,100,147)).getRGB());

        Fonts.mousesans35.drawString("Color", (float)(mainx -70  - a), (float)(mainy + 251 + a),  (new Color(255, 255, 255)).getRGB());
        Fonts.icon40.drawString("e", (float)(mainx -90 - a), (float)(mainy + 251 + a),  (new Color(29,100,147)).getRGB());
        Fonts.mousesans35.drawString("HYT", (float)(mainx -70  - a), (float)(mainy + 279 + a),  (new Color(255, 255, 255)).getRGB());
        Fonts.icon40.drawString("p", (float)(mainx -90 - a), (float)(mainy + 279 + a),  (new Color(29,100,147)).getRGB());
        Fonts.mousesans35.drawString("GUI", (float)(mainx -70  - a), (float)(mainy + 307 + a),  (new Color(255, 255, 255)).getRGB());

        Fonts.icon40.drawString("q", (float)(mainx -90 - a ), (float)(mainy + 307 + a),  (new Color(29,100,147)).getRGB());


        super.drawScreen(mouseX, mouseY, partialTicks);
    }
    @Override
    public void mouseClicked(int mouseX, int mouseY, int mouseButton) throws IOException {
        if (mouseButton == 0) {
            Iterator var4 = this.types.iterator();

            label35:
            while(true) {
                TypeScreen typeScreen;
                do {
                    if (!var4.hasNext()) {
                        break label35;
                    }

                    typeScreen = (TypeScreen)var4.next();
                } while(!typeScreen.isHovered(mouseX, mouseY));

                Iterator var6 = this.types.iterator();

                while(var6.hasNext()) {
                    TypeScreen other = (TypeScreen)var6.next();
                    other.setSelected(false);
                }

                typeScreen.setSelected(true);
            }
        }

        TypeScreen selectedTab = this.getSelectedTab();
        if (selectedTab != null) {
            selectedTab.mouseClicked(mouseX, mouseY, mouseButton);
        }

        if (RenderUtils.isHovering((float)mainx, (float)mainy, 500.0F, 35.0F, mouseX, mouseY)) {
            this.x2 = mainx - mouseX;
            this.y2 = mainy - mouseY;
            this.dragging = true;
        }

    }
    @Override
    public void onGuiClosed() {
        Keyboard.enableRepeatEvents(false);
    }


    @Override
    protected void mouseReleased(int mouseX, int mouseY, int state) {
        this.types.forEach((e) -> {
            e.mouseReleased(mouseX, mouseY, state);
        });
        if (state == 0) {
            this.dragging = false;
        }

        super.mouseReleased(mouseX, mouseY, state);
    }
    @Override
    protected void keyTyped(char typedChar, int keyCode) throws IOException {
        this.types.forEach((e) -> {
            e.keyTyped(typedChar, keyCode);
        });
        super.keyTyped(typedChar, keyCode);
    }
    public TypeScreen getSelectedTab() {
        return (TypeScreen)this.types.stream().filter(TypeScreen::isSelected).findAny().orElse(null);
    }


}
