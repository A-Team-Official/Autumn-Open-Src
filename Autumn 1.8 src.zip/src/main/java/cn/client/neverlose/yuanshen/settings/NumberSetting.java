//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package cn.client.neverlose.yuanshen.settings;

import cn.client.Client;
import cn.client.neverlose.yuanshen.Downward;
import cn.client.neverlose.yuanshen.ModuleRender;
import cn.client.utils.Color.MathUtils;
import net.ccbluex.liquidbounce.ui.cnfont.FontLoaders;
import net.ccbluex.liquidbounce.ui.font.Fonts;
import net.ccbluex.liquidbounce.utils.render.RenderUtils;
import net.ccbluex.liquidbounce.value.IntegerValue;
import net.minecraft.util.math.MathHelper;

import java.awt.*;


public class NumberSetting extends Downward<IntegerValue> {
    public int mainx;
    public int mainy;
    public int y;
    public float percent = 0.0F;
    private boolean iloveyou;

    public NumberSetting(IntegerValue s, float x, float y, int width, int height, ModuleRender moduleRender) {
        super(s, x, y, width, height, moduleRender);
    }

    public void draw(int mouseX, int mouseY) {
        this.mainx = Client.instance.skeet.mainx;
        this.mainy = Client.instance.skeet.mainy;
        this.y = (int)(this.pos.y + (float)this.getScrollY());
        FontLoaders.msr18.drawString((this.setting).getName(), (float)(this.mainx + 17) + this.pos.x, (float)(this.mainy + 38 + this.y), new Color(130, 140, 150).getRGB());

        RenderUtils.drawRect((float)(this.mainx + 91) + this.pos.x, (float)(this.mainy + 42 + this.y), (float)(this.mainx + 161) + this.pos.x, (float)(this.mainy + 44 + this.y), new Color(5, 23, 37).getRGB());

        double clamp = (double)MathHelper.clamp(300f, 1.0F, 9999.0F);
        double minValue = (this.setting).getMinimum();
        double maxValue = (this.setting).getMaximum();
        double range = maxValue - minValue;
        double value = (this.setting).get().doubleValue();
        double percentBar = (value - minValue) / range;
        this.percent = (float) MathUtils.clamp((float) (this.percent + (MathUtils.clamp((float) percentBar, 0.0f, 1.0f) - this.percent) * (50 / clamp)), 0.0f, 1.0f);

        float startX = (float)(this.mainx + 91) + this.pos.x;
        float endX = (float)(this.mainx + 161) + this.pos.x;
        float barWidth = endX - startX;
        float barFillWidth = barWidth * this.percent;
        float barHeight = 5.0F;

        RenderUtils.drawRect(startX, (float)(this.mainy + 42 + this.y), startX + barFillWidth, (float)(this.mainy + 44 + this.y), new Color(12,102,146).getRGB());
        RenderUtils.drawGoodCircle(startX + barFillWidth, (float)(this.mainy + 42 + this.y),4f,new Color(54,134,242).getRGB());
        if (this.iloveyou) {
            float percentt = MathHelper.clamp((float)(mouseX - (startX + 1.0F)) / (barWidth - 1.0F), 0.0F, 1.0F);
            double newValue = (double)percentt * range + minValue;
            double set = MathHelper.clamp(newValue, minValue, maxValue);
            (this.setting).set((int)set);
        }


        String valueString = String.valueOf((this.setting).get());
        String displayName = (this.setting).getDisplayName();
        float textWidth = FontLoaders.msr18.getStringWidth(valueString + displayName);

        Fonts.mousesans35.drawString(valueString + displayName, startX + barFillWidth - textWidth, (float)this.mainy + 31.0F + (float)this.y, new Color(130, 140, 150).getRGB());
    }

    public void mouseClicked(int mouseX, int mouseY, int mouseButton) {
        if (RenderUtils.isHovering((float)(this.mainx + 91) + this.pos.x, (float)(this.mainy + 40 + this.y), 70.0F, 5.0F, mouseX, mouseY) && mouseButton == 0) {
            this.iloveyou = true;
        }

    }

    public void mouseReleased(int mouseX, int mouseY, int state) {
        if (state == 0) {
            this.iloveyou = false;
        }

    }
}
