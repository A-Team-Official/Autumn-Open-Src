//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package cn.client.neverlose.yuanshen;

import net.ccbluex.liquidbounce.Client;
import net.ccbluex.liquidbounce.features.module.Module;
import net.ccbluex.liquidbounce.features.module.ModuleCategory;
import net.ccbluex.liquidbounce.ui.cnfont.FontLoaders;
import net.ccbluex.liquidbounce.utils.render.RenderUtils;
import net.ccbluex.liquidbounce.utils.render.tenacity.ColorUtil;
import net.ccbluex.liquidbounce.utils.render.tenacity.MathUtils;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.GL11;

import java.awt.*;
import java.util.ArrayList;
import java.util.Iterator;


public class TypeScreen {
    private final Position pos;
    private final ModuleCategory type;
    private final float minScroll = 0.0F;
    public int x;
    public int y;
    public int mainx;
    public int anmitY;
    public int leftAdd;
    public int rightAdd;
    public ArrayList<ModuleRender> moduleRect;
    private boolean selected;
    private float maxScroll = Float.MAX_VALUE;
    private float rawScroll;
    private float scroll;
    private final float y1 = 28f;


    private Animation scrollAnimation;

    public TypeScreen(ModuleCategory category, int x) {
        Helper.helper();
        this.scrollAnimation = new SmoothStepAnimation(0, 0.0, Direction.BACKWARDS);
        this.x = x;
        this.type = category;
        this.pos = new Position(0.0F, 0.0F, 0.0F, 0.0F);
        int count = 0;
        this.moduleRect = new ArrayList();
        Iterator var4 = Client.moduleManager.getModules().iterator();

        while(var4.hasNext()) {
            Module holder = (Module)var4.next();
            if (holder.getCategory().equals(category)) {
                float posWidth = 0.0F;
                float posX = this.pos.x + (float)(count % 2 == 0 ? 0 : 170);
                float posY = this.pos.y + (float)(count % 2 == 0 ? this.leftAdd : this.rightAdd);
                Position pos = new Position(posX, posY, posWidth, 20.0F);
                ModuleRender otlM = new ModuleRender(holder, pos.x, pos.y, pos.width, 0.0F);
                pos.height = (float)otlM.height;
                if (count % 2 == 0) {
                    this.leftAdd = (int)((float)this.leftAdd + pos.height + 10.0F);
                } else {
                    this.rightAdd = (int)((float)this.rightAdd + pos.height + 10.0F);
                }

                this.moduleRect.add(otlM);
                ++count;
            }
        }

    }

    
    public void draw(int mx, int my) {

    	   this.mainx = OP.mainx;
            this.anmitY = OP.mainy;
            OP.y4 =0f;

   		Color baseColor = new Color(3,11,23, 110);
   		Color colorr = ColorUtil.interpolateColorC(baseColor, new Color(ColorUtil.applyOpacity(baseColor.getRGB(), .3f)), 0.5F);
       if (this.selected) {

           if (type == ModuleCategory.COMBAT){
               OP.cnm =1;
           }
           if (type == ModuleCategory.PLAYER){
               OP.cnm =2;
           }
           if (type == ModuleCategory.MOVEMENT){
               OP.cnm =3;
           }
           if (type == ModuleCategory.RENDER){
               OP.cnm =4;
           }
           if (type == ModuleCategory.WORLD){
               OP.cnm =5;
           }
           if (type == ModuleCategory.MISC){
               OP.cnm =6;
           }
           if (type == ModuleCategory.EXPLOIT){
               OP.cnm =7;
           }
           if (type == ModuleCategory.COLOR){
               OP.cnm =8;
           }
           if (type == ModuleCategory.HYT){
               OP.cnm =9;
           }
           if (type == ModuleCategory.GUI) {
               OP.cnm = 10;
           }

           for (; OP.y4 <OP.cnm ; OP.y4++){
               OP.y22 = 28f * OP.y4;
           }
           for (; OP.y4 >OP.cnm ; OP.y4--){
               OP.y22 = 28f * OP.y4;
           }
           OP.y3 = (float) RenderUtils.getAnimationState2(OP.y3 ,OP.y22 , 800);
           RenderUtils.drawRoundedRect((float)(this.mainx -97 ), (float)this.anmitY+50+ OP.y3,(float)(this.mainx -65) + 60,this.anmitY+ 68F+ OP.y3,2, (new Color(7,48,70)).getRGB());
       }
     //  RenderUtils.drawImage(new ResourceLocation("Boker/clickgui/RENDER.png"), (int)mainx + 5, (int)mainx + 60, 0, 0);

  //      FontLoaders.NL24.drawString(this.newcatename(this.type), (float)(this.mainx -70 ), (float)(this.mainy + 55)+ this.x,  (new Color(255, 255, 255)).getRGB());
       
    
      //  Client.INSTANCE.getFontManager().check18.drawString(l2, var10002, (float)(this.mainy + 16), this.selected ? Hud.colorValue.getValue() : (new Color(133, 135, 139)).getRGB());
    
        if (this.selected) {
            GL11.glPushMatrix();
            RenderUtils.doGlScissor((double)this.mainx, (double)(this.anmitY + 35), 500.0, 305.0);
            GL11.glEnable(3089);
            this.moduleRect.forEach((e) -> {
                e.draw(mx, my);
            });
            GL11.glDisable(3089);
            GL11.glPopMatrix();
            double scrolll = (double)this.getScroll();

            ModuleRender module;
            for(Iterator var7 = this.moduleRect.iterator(); var7.hasNext(); module.scrollY = (int) MathUtils.roundToHalf(scrolll)) {
                module = (ModuleRender)var7.next();
            }

            this.onScroll(30, mx, my);
            this.maxScroll = (float)Math.max(0, this.moduleRect.size() == 0 ? 0 : ((ModuleRender)this.moduleRect.get(this.moduleRect.size() - 1)).getMaxScrollY());
        }

    }

    public String newcatename(ModuleCategory moduleCategory) {
        return moduleCategory.getDisplayName();
    }

    public boolean isSelected() {
        return this.selected;
    }

    public void setSelected(boolean s) {
        this.selected = s;
    }

    public void onScroll(int ms, int mx, int my) {
        this.scroll = (float)((double)this.rawScroll - this.scrollAnimation.getOutput());
        if (RenderUtils.isHovering((float)this.mainx, (float)(this.anmitY + 35), 350.0F, 265.0F, mx, my)) {
            this.rawScroll += (float)Mouse.getDWheel() / 4.0F;
        }

        this.rawScroll = Math.max(Math.min(0.0F, this.rawScroll), -this.maxScroll);
        this.scrollAnimation = new SmoothStepAnimation(ms, (double)(this.rawScroll - this.scroll), Direction.BACKWARDS);
    }

    public float getScroll() {
        this.scroll = (float)((double)this.rawScroll - this.scrollAnimation.getOutput());
        return this.scroll;
    }

    protected void mouseClicked(int mouseX, int mouseY, int mouseButton) {
        this.moduleRect.forEach((s) -> {
            s.mouseClicked(mouseX, mouseY, mouseButton);
        });
    }

    public void mouseReleased(int mouseX, int mouseY, int state) {
        this.moduleRect.forEach((e) -> {
            e.mouseReleased(mouseX, mouseY, state);
        });
    }

    public void keyTyped(char typedChar, int keyCode) {
        this.moduleRect.forEach((e) -> {
            e.keyTyped(typedChar, keyCode);
        });
    }

    public boolean isHovered(int mouseX, int mouseY) {
        return RenderUtils.isHovering((float)(this.mainx -70 ), (float)(this.anmitY + 54)+ this.x, (float) FontLoaders.msr18.getStringWidth(this.newcatename(this.type))+10, (float)(FontLoaders.msr18.getHeight() + 42)+ this.x, mouseX, mouseY);
    }
}
