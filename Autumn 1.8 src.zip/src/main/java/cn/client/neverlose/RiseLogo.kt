package cn.client.neverlose

import cn.client.oth.tenacity.blur.Bloom
import net.ccbluex.liquidbounce.features.module.modules.render.HUD.clientColors
import net.ccbluex.liquidbounce.features.module.modules.render.HUD.clientname
import net.ccbluex.liquidbounce.ui.client.hud.element.Border
import net.ccbluex.liquidbounce.ui.client.hud.element.Element
import net.ccbluex.liquidbounce.ui.client.hud.element.ElementInfo
import net.ccbluex.liquidbounce.ui.font.Fonts
import net.ccbluex.liquidbounce.utils.render.tenacity.GradientUtil
import org.lwjgl.opengl.GL11

@ElementInfo("Logo")
class RiseLogo : Element(){
    override fun drawElement(): Border {

        GradientUtil.applyGradientHorizontal(
            0f,
            0f,
            Fonts.productSansLogo.getStringWidth(clientname.get()).toFloat(),
            Fonts.productSansLogo.fontHeight.toFloat(),
            1f,
            clientColors[0],
            clientColors[1]
        ) {
            Fonts.productSansLogo.drawString(clientname.get(), 0f, 0f, -1)
        }

        var floatX = renderX.toFloat()
        var floatY = renderY.toFloat()
        GL11.glTranslated(-renderX, -renderY, 0.0)
        GL11.glPushMatrix()
        Bloom.shadow {
            GradientUtil.applyGradientHorizontal(
                floatX,
                floatY,
                Fonts.productSansLogo.getStringWidth(clientname.get()).toFloat(),
                Fonts.productSansLogo.fontHeight.toFloat(),
                1f,
                clientColors[0],
                clientColors[1]
            ) {
                Fonts.productSansLogo.drawString(clientname.get(), floatX, floatY, -1)
            }
        }
        GL11.glPopMatrix()
        GL11.glTranslated(renderX, renderY, 0.0)


        return Border(0f,0f,Fonts.productSansLogo.getStringWidth(clientname.get()).toFloat(),Fonts.productSansLogo.fontHeight.toFloat(),0f)
    }
}