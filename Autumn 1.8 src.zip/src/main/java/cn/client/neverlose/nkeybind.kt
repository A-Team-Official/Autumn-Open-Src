package cn.client.neverlose

import cn.client.oth.tenacity.blur.Bloom
import cn.client.oth.tenacity.blur.BlurBuffer
import cn.client.utils.Color.modules.CustomUI
import net.ccbluex.liquidbounce.Client
import net.ccbluex.liquidbounce.ui.client.hud.element.Border
import net.ccbluex.liquidbounce.ui.client.hud.element.Element
import net.ccbluex.liquidbounce.ui.client.hud.element.ElementInfo
import net.ccbluex.liquidbounce.utils.render.RenderUtils
import net.ccbluex.liquidbounce.utils.render.RoundedUtil
import net.ccbluex.liquidbounce.value.BoolValue
import org.lwjgl.opengl.GL11
import java.awt.Color

@cn.obf.Native
@ElementInfo(name = "N-KeyBinds")
class NKeyBinds : Element() {
    val onlyState = BoolValue("OnlyModuleState", true)
    private var anmitY = 0F
    override fun drawElement(): Border {
        var y2 = 0
        anmitY = RenderUtils.getAnimationState2(anmitY.toDouble(),(getmoduley()).toFloat().toDouble(), 200.0).toFloat()

        //draw Background
        if (CustomUI.Blur.get()){
            val floatX = renderX.toFloat()
            val floatY = renderY.toFloat()
            GL11.glTranslated(-renderX, -renderY, 0.0)
            GL11.glPushMatrix()
            BlurBuffer.CustomBlurRoundArea(floatX, floatY,100f, 15 + anmitY, CustomUI.radius.get())
            GL11.glPopMatrix()
            GL11.glTranslated(renderX, renderY, 0.0)
        }
        if (CustomUI.Shadow.get()){
            var floatX = renderX.toFloat()
            var floatY = renderY.toFloat()
            GL11.glTranslated(-renderX, -renderY, 0.0)
            GL11.glPushMatrix()
            Bloom.shadow {
                RoundedUtil.drawRound(floatX, floatY, 100f, 15 + anmitY, CustomUI.radius.get(), Color(29,40,53))
            }
            GL11.glPopMatrix()
            GL11.glTranslated(renderX, renderY, 0.0)
        }
        RoundedUtil.drawRound(0f, 0f, 100f, 15 + anmitY, CustomUI.radius.get(), Color(29,40,53,CustomUI.a.get()))

        //draw Title
        net.ccbluex.liquidbounce.ui.font.Fonts.icon40.drawString("n", 3f, 6f, Color(14,102,155).rgb, false)
        net.ccbluex.liquidbounce.ui.font.Fonts.mousesans35.drawString("Binds",  net.ccbluex.liquidbounce.ui.font.Fonts.icon40.getStringWidth("n") + 6f, 6.5f, Color.WHITE.rgb, false)

        //draw Module Bind
        for (module in Client.moduleManager.modules) {
            if (module.keyBind == 0) continue
            if (onlyState.get()) {
                if (!module.state) continue
            }
            net.ccbluex.liquidbounce.ui.font.Fonts.mousesans30.drawString(module.name, 3f, y2 + 21f, -1, false)
            net.ccbluex.liquidbounce.ui.font.Fonts.mousesans30.drawString(
                "[Toggle]",
                (95 - net.ccbluex.liquidbounce.ui.font.Fonts.mousesans30.getStringWidth("[Toggle]")).toFloat(),
                y2 + 21f,
                Color(255, 255, 255).rgb,
                false
            )
            y2 += 12
        }
        return Border(0f, 0f, 100f, 15 + anmitY, 0f)
    }

    fun getmoduley(): Int {
        var y = 0
        for (module in Client.moduleManager.modules) {
            if (module.keyBind == 0) continue
            if (onlyState.get()) {
                if (!module.state) continue
            }
            y += 12
        }
        return y
    }
}