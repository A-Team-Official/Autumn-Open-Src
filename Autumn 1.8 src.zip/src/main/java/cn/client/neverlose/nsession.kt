package cn.client.neverlose

import cn.client.oth.tenacity.blur.Bloom
import cn.client.oth.tenacity.blur.BlurBuffer
import cn.client.utils.Color.modules.CustomUI
import net.ccbluex.liquidbounce.ui.client.hud.element.Border
import net.ccbluex.liquidbounce.ui.client.hud.element.Element
import net.ccbluex.liquidbounce.ui.client.hud.element.ElementInfo
import net.ccbluex.liquidbounce.ui.font.Fonts
import net.ccbluex.liquidbounce.utils.render.RenderUtils
import net.ccbluex.liquidbounce.utils.render.RoundedUtil
import net.minecraft.client.Minecraft
import org.lwjgl.opengl.GL11
import java.awt.Color
import java.text.SimpleDateFormat
import java.util.*

@cn.obf.Native
@ElementInfo(name = "N-SessionInfo")
class NSession(x: Double = 10.0, y: Double = 30.0, scale: Float = 1F) : Element(x, y, scale) {
    private fun BPS(): Double {
        val bps = Math.hypot(
            mc.thePlayer!!.posX - mc.thePlayer!!.prevPosX,
            mc.thePlayer!!.posZ - mc.thePlayer!!.prevPosZ
        ) * mc.timer.timerSpeed * 20
        return Math.round(bps * 100.0) / 100.0
    }

    override fun drawElement(): Border {
        val fontRenderer = Fonts.mousesans35
        val y2 = fontRenderer.fontHeight * 5 + 11.0.toInt()
        val a = 2
            val DATE_FORMAT = SimpleDateFormat("HH:mm:ss")
        if (CustomUI.Blur.get()){
            var floatX = renderX.toFloat()
            var floatY = renderY.toFloat()
            GL11.glTranslated(-renderX, -renderY, 0.0)
            GL11.glPushMatrix()
            BlurBuffer.CustomBlurRoundArea(floatX-2f, floatY-2f, 150f, y2.toFloat() + 6f,CustomUI.radius.get())
            GL11.glPopMatrix()
            GL11.glTranslated(renderX, renderY, 0.0)
        }
        if (CustomUI.Shadow.get()){
            var floatX = renderX.toFloat()
            var floatY = renderY.toFloat()
            GL11.glTranslated(-renderX, -renderY, 0.0)
            GL11.glPushMatrix()
            Bloom.shadow {
                RoundedUtil.drawRound(floatX-2f, floatY-2f, 150f, y2.toFloat() + 6f, CustomUI.radius.get(), Color(29,40,53))
            }
            GL11.glPopMatrix()
            GL11.glTranslated(renderX, renderY, 0.0)
        }
            RoundedUtil.drawRound(-2f, -2f, 150f, y2.toFloat() + 6f, CustomUI.radius.get(), Color(29,40,53,CustomUI.a.get()))
            RenderUtils.drawRect(2f, 11f,145f,11.8f,Color(72,85,100,210))
            Fonts.icon40.drawString("p",
                3.0f, 3f,Color(14,102,155).rgb)
            fontRenderer.drawString("Session Info", 15f, 2f + a, Color.WHITE.rgb, false)
            val Date = Date()

            fontRenderer.drawString("FPS: " + Minecraft.getDebugFPS().toString(), 2,
                (fontRenderer.fontHeight + 6f + a).toInt(), Color.WHITE.rgb)
            fontRenderer.drawString("Speed: " + BPS().toString() + " b/s", 2,
                (fontRenderer.fontHeight * 2 + 8f + a).toInt(), Color.WHITE.rgb)
            fontRenderer.drawString("Time: " + DATE_FORMAT.format(Date), 2,
                (fontRenderer.fontHeight * 3 + 10f + a).toInt(), Color.WHITE.rgb)
            fontRenderer.drawString("Health " + Math.round(mc.thePlayer!!.health)+ ".0 / " + Math.round(mc.thePlayer!!.maxHealth) + ".0", 2,
                (fontRenderer.fontHeight * 4 + 12f + a).toInt(), Color.WHITE.rgb)


        return Border(-2f, -2f, 150f, y2.toFloat() + 6f,2f)
    }
}
