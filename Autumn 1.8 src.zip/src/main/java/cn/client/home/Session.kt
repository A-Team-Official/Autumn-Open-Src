package cn.client.home

import cn.client.oth.tenacity.blur.BlurBuffer
import cn.client.utils.Color.modules.CustomUI
import net.ccbluex.liquidbounce.ui.client.hud.element.Border
import net.ccbluex.liquidbounce.ui.client.hud.element.Element
import net.ccbluex.liquidbounce.ui.client.hud.element.ElementInfo
import cn.client.novoline.ui.InfosUtils.Recorder
import net.ccbluex.liquidbounce.ui.font.Fonts
import net.ccbluex.liquidbounce.utils.render.RenderUtils
import net.ccbluex.liquidbounce.utils.render.RoundedUtil
import net.minecraft.util.ResourceLocation
import org.lwjgl.opengl.GL11
import java.awt.Color

@ElementInfo(name = "H-Session")
class Session : Element() {
    var DATE_FORMAT = ""

    override fun drawElement(): Border {
        val durationInMillis: Long = System.currentTimeMillis() - Recorder.startTime
        val second = durationInMillis / 1000 % 60
        val minute = durationInMillis / (1000 * 60) % 60
        val hour = durationInMillis / (1000 * 60 * 60) % 24
        DATE_FORMAT = String.format("%01dh:%02dmin", hour, minute, second)
        if (CustomUI.Blur.get()){
            val floatX = renderX.toFloat()
            val floatY = renderY.toFloat()
            GL11.glTranslated(-renderX, -renderY, 0.0)
            GL11.glPushMatrix()
            BlurBuffer.CustomBlurRoundArea(floatX, floatY,130f +  Fonts.mousesans35.getStringWidth(if (!mc2.isSingleplayer)mc.currentServerData!!.serverIP else "Singleplayer") / 3F, 95f, CustomUI.radius.get())
            GL11.glPopMatrix()
            GL11.glTranslated(renderX, renderY, 0.0)
        }
        val fontRenderer = Fonts.mousesans35
        RoundedUtil.drawRound(0F,0F,130f + Fonts.mousesans35.getStringWidth(if (!mc2.isSingleplayer)mc.currentServerData!!.serverIP else "Singleplayer") / 3F,95f,CustomUI.radius.get(), Color(0,0,0,100))
        Fonts.mousesans40.drawString("SessionInfo",5,7,Color.WHITE.rgb)
        RenderUtils.drawImage(ResourceLocation("autumn/home/play.png"),12,20,12,12)
        Fonts.mousesans35.drawString(mc.thePlayer!!.name.toString(),25,22,Color.WHITE.rgb)
        RenderUtils.drawImage(ResourceLocation("autumn/home/sever.png"),10,30 + Fonts.mousesans35.fontHeight   ,12,12)
        Fonts.mousesans35.drawString(if (!mc2.isSingleplayer)mc.currentServerData!!.serverIP else "Singleplayer",25,32+ Fonts.mousesans35.fontHeight,Color.WHITE.rgb)
        RenderUtils.drawImage(ResourceLocation("autumn/home/kill.png"),10,40 + Fonts.mousesans35.fontHeight *2  ,12,12)
        Fonts.mousesans35.drawString(Recorder.killCounts.toString()+" kills",25,42+ Fonts.mousesans35.fontHeight*2,Color.WHITE.rgb)
        RenderUtils.drawImage(ResourceLocation("autumn/home/death.png"),10,50 + Fonts.mousesans35.fontHeight *3  ,12,12)
        Fonts.mousesans35.drawString(Recorder.ban.toString()+" ban",25,52+ Fonts.mousesans35.fontHeight*3,Color.WHITE.rgb)
        return Border(0F,0F,150f,75f,CustomUI.radius.get())
    }


}