package cn.client.home;

import cn.client.oth.tenacity.blur.BlurBuffer;
import cn.client.utils.Color.modules.CustomUI;
import net.ccbluex.liquidbounce.api.minecraft.potion.IPotion;
import net.ccbluex.liquidbounce.api.minecraft.potion.IPotionEffect;
import net.ccbluex.liquidbounce.api.minecraft.util.IResourceLocation;
import net.ccbluex.liquidbounce.features.module.modules.render.HUD;
import net.ccbluex.liquidbounce.ui.client.hud.element.Border;
import net.ccbluex.liquidbounce.ui.client.hud.element.Element;
import net.ccbluex.liquidbounce.ui.client.hud.element.ElementInfo;
import net.ccbluex.liquidbounce.ui.font.Fonts;
import net.ccbluex.liquidbounce.utils.render.Colors;
import net.ccbluex.liquidbounce.utils.render.RenderUtils;
import net.ccbluex.liquidbounce.utils.render.RoundedUtil;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.OpenGlHelper;
import org.lwjgl.opengl.GL11;
import top.fl0wowp4rty.phantomshield.annotations.Native;

import java.awt.Color;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
@Native
@ElementInfo(name = "H-Effect")
public class HEffects extends Element {
    private final Map<Integer, Integer> potionMaxDurations = new HashMap<>();
    Map<IPotion, Double> timerMap = new HashMap<>();
    private int x;
    private int length;
    private int length2;


    @Override
    public Border drawElement() {
        this.x = 0;
        final int tempY = (length = HUD.mc.getThePlayer().getActivePotionEffects().size()) * -30;
        length2 = (int) RenderUtils.getAnimationState2(length2,-50 + tempY,1500f);

        if (CustomUI.Blur.get()){
            float floatX = (float) getRenderX();
            float floatY = (float) getRenderY();
            GL11.glTranslated(-getRenderX(), -getRenderY(), 0.0);
            GL11.glPushMatrix();
            BlurBuffer.CustomBlurRoundArea2(floatX-120f, floatY +length2, floatX + 10f,floatY -25,CustomUI.radius.get());
            GL11.glPopMatrix();
            GL11.glTranslated(getRenderX(), getRenderY(), 0.0);
        }

        RoundedUtil.drawRound2(-120F,length2,10f,-25,2f,new Color(0,0,0,100));
        Fonts.font35.drawString("Effects",-115f,-50 + tempY + 5f,Color.WHITE.getRGB());


        for (final IPotionEffect effect : HUD.mc.getThePlayer().getActivePotionEffects()) {
            if (!this.potionMaxDurations.containsKey(effect.getPotionID()) || this.potionMaxDurations.get(effect.getPotionID()) < effect.getDuration()) {
                this.potionMaxDurations.put(effect.getPotionID(), effect.getDuration());
            }
            final IPotion potion = functions.getPotionById(effect.getPotionID());
            final String PType = functions.formatI18n(potion.getName(), Arrays.toString(new Object[0]));
            int minutes;
            int seconds;
            try {
                minutes = Integer.parseInt(effect.getDurationString().split(":")[0]);
                seconds = Integer.parseInt(effect.getDurationString().split(":")[1]);
            }
            catch (Exception ex) {
                minutes = 0;
                seconds = 0;
            }
            final double total = minutes * 60 + seconds;
            if (!this.timerMap.containsKey(potion)) {
                this.timerMap.put(potion, total);
            }
            if (this.timerMap.get(potion) == 0.0 || total > this.timerMap.get(potion)) {
                this.timerMap.replace(potion, total);
            }

            final int y2 =  - HUD.mc.getFontRendererObj().getFontHeight() + this.x - 38;
            RoundedUtil.drawRound2( - 115f,y2 - 10 ,5,y2 + 15f,3f,new Color(0,0,0,120));

            final int color = Colors.blendColors(new float[] { 0.0f, 0.5f, 1.0f }, new Color[] { new Color(250, 50, 56), new Color(236, 129, 44), new Color(5, 134, 105) }, effect.getDuration() / (1.0f * this.potionMaxDurations.get(effect.getPotionID()))).getRGB();
            final int x1 = (int)(( - 6) * 1.33f);
            final int y1 = (int)(( - 52 - HUD.mc.getFontRendererObj().getFontHeight() + this.x + 5) * 1.33f);
            final float rectX =  - 120 + 110.0f * (effect.getDuration() / (1.0f * this.potionMaxDurations.get(effect.getPotionID())));
            if (potion.getHasStatusIcon()) {
                classProvider.getGlStateManager().pushMatrix();
                GL11.glDisable(2929);
                GL11.glEnable(3042);
                GL11.glDepthMask(false);
                OpenGlHelper.glBlendFunc(770, 771, 1, 0);
                GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
                final int index = potion.getStatusIconIndex();
                final IResourceLocation location = classProvider.createResourceLocation("textures/gui/container/inventory.png");
                HUD.mc.getTextureManager().bindTexture(location);
                GlStateManager.scale(0.75, 0.75, 0.75);
                mc2.ingameGUI.drawTexturedModalRect(x1 - 141, y1 + 7, index % 8 * 18, 198 + index / 8 * 18, 18, 18);
                GL11.glDepthMask(true);
                GL11.glDisable(3042);
                GL11.glEnable(2929);
                GlStateManager.popMatrix();
            }
            RenderUtils.drawArc( - 104.75f, y2 + 2.5f, 10.0, new Color(22, 28, 15).getRGB(), 0, 360.0, 3);
            RenderUtils.drawArc( - 104.75f, y2 + 2.5f, 10.0, color, 0, 360.0f * (effect.getDuration() / (1.0f * this.potionMaxDurations.get(effect.getPotionID()))), 3);
            Fonts.font30.drawString(PType.replaceAll("§.", "") + " " + intToRomanByGreedy(effect.getAmplifier() + 1),  - 85.0f, y2 - HUD.mc.getFontRendererObj().getFontHeight() + 5, -1);
            Fonts.font30.drawString(effect.getDurationString().replaceAll("§.", ""),  - 85.0f, y2 + 3.5f,  new Color(255, 255, 255, 100).getRGB());

            this.x -= 30;

        }
        return new Border(-120F,-50 + tempY,10f,-25f, CustomUI.radius.get());
    }
    private String intToRomanByGreedy(int num) {
        final int[] values = {1000, 900, 500, 400, 100, 90, 50, 40, 10, 9, 5, 4, 1};
        final String[] symbols = {"M", "CM", "D", "CD", "C", "XC", "L", "XL", "X", "IX", "V", "IV", "I"};
        final StringBuilder stringBuilder = new StringBuilder();
        for(int i = 0; i < values.length && num >= 0; i++)
            while (values[i] <= num){
                num -= values[i];
                stringBuilder.append(symbols[i]);
            }

        return stringBuilder.toString();
    }
}