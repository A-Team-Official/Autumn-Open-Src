package cn.client.home

import cn.client.oth.tenacity.blur.BlurBuffer
import cn.client.utils.Color.modules.CustomUI
import net.ccbluex.liquidbounce.Client
import net.ccbluex.liquidbounce.features.module.modules.render.HUD
import net.ccbluex.liquidbounce.ui.client.hud.element.Border
import net.ccbluex.liquidbounce.ui.client.hud.element.Element
import net.ccbluex.liquidbounce.ui.client.hud.element.ElementInfo
import net.ccbluex.liquidbounce.ui.font.Fonts
import net.ccbluex.liquidbounce.utils.render.RenderUtils
import net.ccbluex.liquidbounce.utils.render.RoundedUtil
import net.ccbluex.liquidbounce.value.BoolValue
import net.minecraft.client.Minecraft
import org.lwjgl.opengl.GL11
import java.awt.Color

@ElementInfo(name = "H-Logo")

class NLogo : Element(x = 23.0, y = 15.0){
    private val user = BoolValue("User",true)
    private val fps = BoolValue("Fps",true)
    private val group = BoolValue("Group",true)

    private val separate = BoolValue("Logo-Separate",true)
    private var anmitX = 0F
    private var anmitX2 = 0f
    private var anmitX3 = 0f
    override fun drawElement(): Border {

        val a = Client.USERNAME
        val b = Minecraft.getDebugFPS().toString() + "fps"
        val c = Client.group
        var logo = HUD.clientname.get().toUpperCase()
        var text = ""
        if (!separate.get()) {
            if (user.get()) {
                text = "| $a"
            }
            if (fps.get()) {
                text = "| $b"
            }
            if (group.get()) {
                text = "| $c"
            }
            if (user.get() && fps.get()) {
                text = "| $a | $b"
            }
            if (user.get() && group.get()) {
                text = "| $a | $c"
            }
            if (fps.get() && group.get()) {
                text = "| $b | $c"
            }
            if (user.get() && fps.get() && group.get()) {
                text = "| $a | $b | $c"
            }
        }
        else{
            if (user.get()) {
                text = "$a"
            }
            if (fps.get()) {
                text = "$b"
            }
            if (group.get()) {
                text = "$c"
            }
            if (user.get() && fps.get()) {
                text = "$a | $b"
            }
            if (user.get() && group.get()) {
                text = "$a | $c"
            }
            if (fps.get() && group.get()) {
                text = "$b | $c"
            }
            if (user.get() && fps.get() && group.get()) {
                text = "$a | $b | $c"
            }
        }

        var fontRenderer = Fonts.mousesans35
        var width = Fonts.mousesansbold40.getStringWidth("$logo | ") + fontRenderer.getStringWidth(text).toFloat() + 8f
        var width2 = Fonts.mousesansbold40.getStringWidth(logo) + 11f
        var width3 = fontRenderer.getStringWidth(text).toFloat() + 10f
        var height = fontRenderer.fontHeight + 8f
        var radius = CustomUI.radius.get()
        if (!separate.get()) {
            anmitX = RenderUtils.getAnimationState2(anmitX.toDouble(),(width).toDouble(), CustomUI.aspeed.get().toDouble()).toFloat()
            if (CustomUI.Blur.get()){
                val floatX = renderX.toFloat()
                val floatY = renderY.toFloat()
                GL11.glTranslated(-renderX, -renderY, 0.0)
                GL11.glPushMatrix()
                BlurBuffer.CustomBlurRoundArea(floatX, floatY, anmitX, height,CustomUI.radius.get())
                GL11.glPopMatrix()
                GL11.glTranslated(renderX, renderY, 0.0)
            }

            RoundedUtil.drawRound(0f, 0f, anmitX, height, radius, Color(0,0,0,100))
            Fonts.mousesansbold40.drawString(logo,4f,7f,Color(255,255,255).rgb)
            Fonts.mousesansbold40.drawString(logo,5f,7f,Color.WHITE.rgb)
            fontRenderer.drawString(text,Fonts.mousesansbold40.getStringWidth("$logo | ").toFloat() + 2f,7f,Color.WHITE.rgb)
        }
        else{

            anmitX2 = RenderUtils.getAnimationState2(anmitX2.toDouble(),(width2).toDouble(), CustomUI.aspeed.get().toDouble()).toFloat()
            anmitX3 = RenderUtils.getAnimationState2(anmitX3.toDouble(),(width3).toDouble(), CustomUI.aspeed.get().toDouble()).toFloat()
            if (CustomUI.Blur.get()){
                var floatX = renderX.toFloat()
                var floatY = renderY.toFloat()
                GL11.glTranslated(-renderX, -renderY, 0.0)
                GL11.glPushMatrix()
                BlurBuffer.CustomBlurRoundArea(floatX, floatY, anmitX2, height,CustomUI.radius.get())
                GL11.glPopMatrix()
                GL11.glTranslated(renderX, renderY, 0.0)
            }

            RoundedUtil.drawRound(0f, 0f, anmitX2, height, radius, Color(29,40,53,CustomUI.a.get()))
            Fonts.mousesansbold40.drawString(logo,4.4f,7f,Color(255,255,255).rgb)
            Fonts.mousesansbold40.drawString(logo,5f,7f,Color.WHITE.rgb)
            if (user.get() || fps.get() || group.get()) {
                if (CustomUI.Blur.get()){
                    val floatX = renderX.toFloat()
                    val floatY = renderY.toFloat()
                    GL11.glTranslated(-renderX, -renderY, 0.0)
                    GL11.glPushMatrix()
                    BlurBuffer.CustomBlurRoundArea(floatX+width2 + 4f, floatY, anmitX3, height,CustomUI.radius.get())
                    GL11.glPopMatrix()
                    GL11.glTranslated(renderX, renderY, 0.0)
                }

                RoundedUtil.drawRound(width2 + 4f, 0f, anmitX3, height, radius, Color(0, 0, 0,100))
                fontRenderer.drawString(text, width2 + 9f, 7f, Color.WHITE.rgb)
            }
        }
        return Border(0f,0f,anmitX,height,radius)
    }
}