package cn.client.rave

import cn.client.utils.Color.modules.CustomUI
import net.ccbluex.liquidbounce.ui.client.hud.element.Border
import net.ccbluex.liquidbounce.ui.client.hud.element.Element
import net.ccbluex.liquidbounce.ui.client.hud.element.ElementInfo
import net.ccbluex.liquidbounce.ui.font.Fonts
import net.ccbluex.liquidbounce.utils.render.RoundedUtil
import java.awt.Color

@ElementInfo(name = "Rave-Logo")
class LOgo:Element() {

    override fun drawElement(): Border {
        val width = Fonts.sfbold35.getStringWidth(mc.thePlayer!!.name.toString()) + Fonts.iconmoon.getStringWidth("D")+24f
        RoundedUtil.drawRound(0F,0F,width,Fonts.iconmoon.fontHeight+10F,CustomUI.radius.get(),Color.BLACK)
        Fonts.iconmoon.drawString("D",10,6,Color.WHITE.rgb)
        Fonts.sfbold35.drawString(mc.thePlayer!!.name.toString(),Fonts.iconmoon.getStringWidth("D")+12f,6F,Color.WHITE.rgb)
        return Border(0F,0F,width,Fonts.iconmoon.fontHeight+10F,CustomUI.radius.get())

    }
}