package cn.client.rave

import cn.client.utils.Color.modules.CustomUI
import net.ccbluex.liquidbounce.Client
import net.ccbluex.liquidbounce.ui.client.hud.element.Border
import net.ccbluex.liquidbounce.ui.client.hud.element.Element
import net.ccbluex.liquidbounce.ui.client.hud.element.ElementInfo
import net.ccbluex.liquidbounce.ui.font.Fonts
import net.ccbluex.liquidbounce.utils.render.RenderUtils
import net.ccbluex.liquidbounce.utils.render.RoundedUtil
import net.ccbluex.liquidbounce.value.BoolValue
import net.minecraft.util.ResourceLocation
import org.lwjgl.input.Keyboard
import java.awt.Color

@ElementInfo(name = "Rave-KeyBinds")
class Keybinds: Element() {
    val onlyState = BoolValue("OnlyModuleState", true)
    private var anmitY = 0F

    override fun drawElement(): Border {
        var y2 = 0
        anmitY = RenderUtils.getAnimationState2(anmitY.toDouble(),(getmoduley()).toFloat().toDouble(), 200.0).toFloat()
        RoundedUtil.drawRound(0F,0f,100f,anmitY,CustomUI.radius.get(), Color(0,0,0,255))
        RenderUtils.drawImage(ResourceLocation("autumn/rave/keybinds.png"),8,5,6,6)
        Fonts.pop35.drawString("KeyBinds",21,4,Color.WHITE.rgb)

        //draw Module Bind
        for (module in Client.moduleManager.modules) {
            if (Keyboard.getKeyName(module.keyBind).length < 2) {
                if (module.keyBind == 0) continue
                if (onlyState.get()) {
                    if (!module.state) continue
                }
                RoundedUtil.drawRound(
                    10F,
                    y2 + 20f,
                    10f,
                    10f,
                    2f,
                    if (module.state) Color(0, 102, 255) else Color(255, 255, 255, 200)
                )
                Fonts.mousesans30.drawString(Keyboard.getKeyName(module.keyBind), 12, y2 + 24,if (module.state) Color(255,255,255).rgb else Color(123, 123, 123).rgb)
                Fonts.mousesans35.drawString(
                    module.name,
                    20 + Fonts.mousesans30.getStringWidth(Keyboard.getKeyName(module.keyBind)),
                    y2 + 24,
                    if (module.state) Color(255,255,255).rgb  else Color(65, 65, 65).rgb
                )

                // Fonts.mousesans35.drawString(module.name, 3f, y2 + 21f, -1, false)

                y2 += 16
            }
        }

        return Border(0f, 0f, 100f, 15 + anmitY, 0f)
    }
    fun getmoduley(): Int {
        var y = 15
        for (module in Client.moduleManager.modules) {
            if (Keyboard.getKeyName(module.keyBind).length < 2) {
                if (module.keyBind == 0) continue
                if (onlyState.get()) {
                    if (!module.state) continue
                }
                y += 18
            }
        }
        return y
    }



    }





