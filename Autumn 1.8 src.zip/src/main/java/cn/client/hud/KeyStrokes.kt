/*
 * FDPClient Hacked Client
 * A free open source mixin-based injection hacked client for Minecraft using Minecraft Forge by LiquidBounce.
 * https://github.com/SkidderMC/FDPClient/
 */
package cn.client.hud

import net.ccbluex.liquidbounce.api.minecraft.client.gui.IFontRenderer
import net.ccbluex.liquidbounce.api.minecraft.client.settings.IKeyBinding
import net.ccbluex.liquidbounce.ui.client.hud.element.Border
import net.ccbluex.liquidbounce.ui.client.hud.element.Element
import net.ccbluex.liquidbounce.ui.client.hud.element.ElementInfo
import net.ccbluex.liquidbounce.ui.client.hud.element.Side
import net.ccbluex.liquidbounce.ui.font.Fonts
import net.ccbluex.liquidbounce.utils.render.ColorUtils
import net.ccbluex.liquidbounce.utils.render.RenderUtils
import net.ccbluex.liquidbounce.utils.render.RoundedUtil
import net.ccbluex.liquidbounce.value.FloatValue
import net.ccbluex.liquidbounce.value.IntegerValue
import net.ccbluex.liquidbounce.value.ListValue
import org.lwjgl.input.Keyboard
import org.lwjgl.opengl.GL11
import java.awt.Color

@ElementInfo(name = "Keystrokes")
class Keystrokes : Element(5.0, 25.0, 1.5F, Side.default()) {
    private val keys = ArrayList<KeyStroke>()
    private val tenacitykey = ArrayList<KeyStroke>()

    private val backGroundRedValue = IntegerValue("BackGroundRed", 0, 0, 255)
    private val backGroundGreenValue = IntegerValue("BackGroundGreen", 0, 0, 255)
    private val backGroundBlueValue = IntegerValue("BackGroundBlue", 0, 0, 255)
    private val backGroundAlphaValue = IntegerValue("BackGroundAlpha", 170, 0, 255)
    private val highLightPercent = FloatValue("HighLightPercent", 0.5F, 0F, 1F)
    private val animSpeedValue = IntegerValue("AnimationSpeed", 300, 0, 700)
    val keyStyleValue = ListValue("Mode", arrayOf("Tenacity"), "Tenacity")
    private val radius = FloatValue("T-Radius", 3F, 0F, 10F)

    var floatX: Float? = null
    var floatY: Float? = null
    init {
        keys.add(KeyStroke(mc.gameSettings.keyBindForward, 16, 0, 15, 15).initKeyName())
        keys.add(KeyStroke(mc.gameSettings.keyBindLeft, 0, 16, 15, 15).initKeyName())
        keys.add(KeyStroke(mc.gameSettings.keyBindBack, 16, 16, 15, 15).initKeyName())
        keys.add(KeyStroke(mc.gameSettings.keyBindRight, 32, 16, 15, 15).initKeyName())
        keys.add(KeyStroke(mc.gameSettings.keyBindAttack, 0, 32, 23, 15).initKeyName("L"))
        keys.add(KeyStroke(mc.gameSettings.keyBindUseItem, 24, 32, 23, 15).initKeyName("R"))
        tenacitykey.add(KeyStroke(mc.gameSettings.keyBindForward, 17, 0, 15, 15).initKeyName())
        tenacitykey.add(KeyStroke(mc.gameSettings.keyBindLeft, 0, 17, 15, 15).initKeyName())
        tenacitykey.add(KeyStroke(mc.gameSettings.keyBindBack, 17, 17, 15, 15).initKeyName())
        tenacitykey.add(KeyStroke(mc.gameSettings.keyBindRight, 34, 17, 15, 15).initKeyName())
        tenacitykey.add(KeyStroke(mc.gameSettings.keyBindJump,0,34,49,15).initKeyName("SPACE"))
    }


    override fun drawElement(): Border {
        floatX = renderX.toFloat()
        floatY = renderY.toFloat()
        val backGroundColor = Color(backGroundRedValue.get(), backGroundGreenValue.get(), backGroundBlueValue.get(), backGroundAlphaValue.get())

        if(keyStyleValue.get().equals("Tenacity")) {
            for (keyStroke in tenacitykey) {
                keyStroke.Tenacity(animSpeedValue.get(), backGroundColor, highLightPercent.get(), Fonts.tenacitybold28,radius.get())
            }
        }
        return Border(0F, 0F, 47F, 47F,0f)
    }
}

class KeyStroke(val key: IKeyBinding, val posX: Int, val posY: Int, val width: Int, val height: Int) {
    var keyName = "KEY"

    private var lastClick = false
    private val animations = ArrayList<Long>()

    fun Tenacity(speed: Int, bgColor: Color, highLightPct: Float, font: IFontRenderer, radius:Float) {
        GL11.glPushMatrix()
        GL11.glTranslatef(posX.toFloat(), posY.toFloat(), 0F)

        val highLightColor = Color(255 - ((255 - bgColor.red) * highLightPct).toInt(), 255 - ((255 - bgColor.blue) * highLightPct).toInt(), 255 - ((255 - bgColor.green) * highLightPct).toInt())
        val clickAlpha = 255 - (255 - bgColor.alpha) * highLightPct
        val centerX = width / 2
        val centerY = height / 2
        val nowTime = System.currentTimeMillis()

        val rectColor = if (lastClick && animations.isEmpty()) { ColorUtils.reAlpha(highLightColor, clickAlpha.toInt()) } else { bgColor }
        RoundedUtil.drawRound(0F, 0F, width.toFloat(), height.toFloat(), radius,rectColor)

        val removeAble = ArrayList<Long>()
        for (time in animations) {
            val pct = (nowTime - time) / (speed.toFloat())
            if (pct> 1) {
                removeAble.add(time)
                continue
            }
           RenderUtils.drawLimitedCircle(0F, 0F, width.toFloat(), height.toFloat(), centerX, centerY, (width * 0.7F) * pct, Color(255 - ((255 - highLightColor.red) * pct).toInt(), 255 - ((255 - highLightColor.green) * pct).toInt(), 255 - ((255 - highLightColor.blue) * pct).toInt(), 255 - ((255 - clickAlpha) * pct).toInt()))
        }
        for (time in removeAble) {
            animations.remove(time)
        }
        if (!lastClick && key.isKeyDown) {
            animations.add(nowTime)
        }
        lastClick = key.isKeyDown

        font.drawString(keyName, centerX - (font.getStringWidth(keyName) / 2), centerY - (font.fontHeight/2), Color(255,255,255).rgb)

        GL11.glPopMatrix()
    }
    fun initKeyName(): KeyStroke {
        keyName = Keyboard.getKeyName(key.keyCode)
        return this
    }

    fun initKeyName(name: String): KeyStroke {
        keyName = name
        return this
    }
}
