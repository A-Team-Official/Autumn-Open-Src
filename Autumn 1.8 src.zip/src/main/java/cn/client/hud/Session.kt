package cn.client.hud

import cn.client.utils.Color.modules.CustomUI
import net.ccbluex.liquidbounce.ui.client.hud.element.Border
import net.ccbluex.liquidbounce.ui.client.hud.element.Element
import net.ccbluex.liquidbounce.ui.client.hud.element.ElementInfo
import cn.client.novoline.ui.InfosUtils.Recorder
import net.ccbluex.liquidbounce.ui.font.Fonts
import net.ccbluex.liquidbounce.utils.render.RenderUtils
import net.ccbluex.liquidbounce.utils.render.RoundedUtil
import net.minecraft.util.ResourceLocation
import java.awt.Color

@ElementInfo(name = "H-Session")
class Session : Element() {
    var DATE_FORMAT = ""

    override fun drawElement(): Border {
        val durationInMillis: Long = System.currentTimeMillis() - Recorder.startTime
        val second = durationInMillis / 1000 % 60
        val minute = durationInMillis / (1000 * 60) % 60
        val hour = durationInMillis / (1000 * 60 * 60) % 24
        DATE_FORMAT = String.format("%01dh:%02dmin", hour, minute, second)
        val fontRenderer = Fonts.mousesans35
        RoundedUtil.drawRound(0F,0F,170F,75f,CustomUI.radius.get(), Color.BLACK)
        RenderUtils.drawImage(ResourceLocation("autumn/rave/info.png"),5,5,10,10)
        Fonts.mousesans40.drawString("SessionInfo",18,7,Color.WHITE.rgb)
        RenderUtils.drawImage(ResourceLocation("autumn/rave/time.png"),5,27,8,8)
        Fonts.mousesans35.drawString("Last time: $DATE_FORMAT",15,29,Color.WHITE.rgb)
        RenderUtils.drawImage(ResourceLocation("autumn/rave/ban.png"),5,32 + Fonts.mousesans35.fontHeight   ,8,8)
        Fonts.mousesans35.drawString("Bans in 10min: ${Recorder.ban}",15,34+ Fonts.mousesans35.fontHeight,Color.WHITE.rgb)
        RenderUtils.drawImage(ResourceLocation("autumn/rave/win.png"),5,37 + Fonts.mousesans35.fontHeight *2  ,8,8)
        Fonts.mousesans35.drawString("Win: ${Recorder.win}",15,39+ Fonts.mousesans35.fontHeight*2,Color.WHITE.rgb)
        return Border(0F,0F,150F,65F,CustomUI.radius.get())
    }


}