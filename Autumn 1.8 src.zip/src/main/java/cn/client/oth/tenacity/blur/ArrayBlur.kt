package cn.client.oth.tenacity.blur

import cn.client.oth.tenacity.blur.BlurBuffer.stencilFramebuffer
import cn.client.utils.Color.modules.CustomUI
import net.ccbluex.liquidbounce.utils.MinecraftInstance

object ArrayBlur : MinecraftInstance(){

    fun blur(drawMod: (() -> Unit)) {
        stencilFramebuffer = RenderUtil.createFrameBuffer(stencilFramebuffer)
        stencilFramebuffer.framebufferClear()
        stencilFramebuffer.bindFramebuffer(false)
        drawMod()
        stencilFramebuffer.unbindFramebuffer()
        KawaseBlur.renderBlur(
            stencilFramebuffer.framebufferTexture,
            CustomUI.blurValue.get(),
            CustomUI.blurOffset.get()
        )
    }

}