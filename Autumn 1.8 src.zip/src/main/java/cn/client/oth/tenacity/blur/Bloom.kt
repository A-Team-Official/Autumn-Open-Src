package cn.client.oth.tenacity.blur

import cn.client.oth.tenacity.blur.BlurBuffer.stencilFramebuffer
import cn.client.utils.Color.modules.CustomUI
import net.ccbluex.liquidbounce.utils.MinecraftInstance


object Bloom : MinecraftInstance(){

    fun shadow(drawMod: (() -> Unit)) {
        stencilFramebuffer = RenderUtil.createFrameBuffer(stencilFramebuffer)
        stencilFramebuffer.framebufferClear()
        stencilFramebuffer.bindFramebuffer(false)
        drawMod()
        stencilFramebuffer.unbindFramebuffer()
        KawaseBloom.renderBlur(
            stencilFramebuffer.framebufferTexture,
            CustomUI.shadowValue.get(),
            CustomUI.shadowOffset.get()
        )
    }
    fun Cshadow(s:Int,o:Int,drawMod: (() -> Unit)) {
        stencilFramebuffer = RenderUtil.createFrameBuffer(stencilFramebuffer)
        stencilFramebuffer.framebufferClear()
        stencilFramebuffer.bindFramebuffer(false)
        drawMod()
        stencilFramebuffer.unbindFramebuffer()
        KawaseBloom.renderBlur(
            stencilFramebuffer.framebufferTexture,
            s,
            o
        )
    }
}