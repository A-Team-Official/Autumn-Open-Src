package cn.client.oth.tenacity.blur;


import cn.client.utils.Color.modules.CustomUI;
import net.ccbluex.liquidbounce.utils.render.RenderUtils;
import net.ccbluex.liquidbounce.utils.render.RoundedUtil;
import net.minecraft.client.shader.Framebuffer;

import java.awt.*;

public class BlurBuffer {
    public static Framebuffer stencilFramebuffer = new Framebuffer(1, 1, false);

    public static void blurArea(float x, float y, float width, float height) {
        stencilFramebuffer = RenderUtil.createFrameBuffer(stencilFramebuffer);
        stencilFramebuffer.framebufferClear();
        stencilFramebuffer.bindFramebuffer(false);
        RenderUtils.drawRect(x, y, x + width, y + height, new Color(-2).getRGB());
        stencilFramebuffer.unbindFramebuffer();
        KawaseBlur.renderBlur(stencilFramebuffer.framebufferTexture, CustomUI.blurValue.get(), CustomUI.blurOffset.get());

    }
    public static void CustomBlurRoundArea2(float x, float y, float width, float height, int radius,int blurOffset) {
        stencilFramebuffer = RenderUtil.createFrameBuffer(stencilFramebuffer);
        stencilFramebuffer.framebufferClear();
        stencilFramebuffer.bindFramebuffer(false);
        RoundedUtil.drawRound(x, y, width, height, 0F, new Color(-2));
        stencilFramebuffer.unbindFramebuffer();
        KawaseBlur.renderBlur(stencilFramebuffer.framebufferTexture, radius, blurOffset);

    }
    public static void CustomBlurRoundArea3(float x, float y, float width, float height,int radius, int radius2,int blurOffset) {
        stencilFramebuffer = RenderUtil.createFrameBuffer(stencilFramebuffer);
        stencilFramebuffer.framebufferClear();
        stencilFramebuffer.bindFramebuffer(false);
        RoundedUtil.drawRound(x, y, width, height, radius, new Color(-2));
        stencilFramebuffer.unbindFramebuffer();
        KawaseBlur.renderBlur(stencilFramebuffer.framebufferTexture, radius2, blurOffset);

    }
    public static void CustomBlurRoundArea2(float x, float y, float width, float height, float radius) {
        stencilFramebuffer = RenderUtil.createFrameBuffer(stencilFramebuffer);
        stencilFramebuffer.framebufferClear();
        stencilFramebuffer.bindFramebuffer(false);
        RoundedUtil.drawRound2(x, y, width, height, radius, new Color(-2));
        stencilFramebuffer.unbindFramebuffer();
        KawaseBlur.renderBlur(stencilFramebuffer.framebufferTexture, CustomUI.blurValue.get(), CustomUI.blurOffset.get());

    }
    public static void CustomBlurRoundArea(float x, float y, float width, float height, float radius) {
        stencilFramebuffer = RenderUtil.createFrameBuffer(stencilFramebuffer);
        stencilFramebuffer.framebufferClear();
        stencilFramebuffer.bindFramebuffer(false);
        RoundedUtil.drawRound(x, y, width, height, radius, new Color(-2));
        stencilFramebuffer.unbindFramebuffer();
        KawaseBlur.renderBlur(stencilFramebuffer.framebufferTexture, CustomUI.blurValue.get(), CustomUI.blurOffset.get());

    }
    public static void nrb(float x, float y, float width, float height, float radius,int s,int o) {
        stencilFramebuffer = RenderUtil.createFrameBuffer(stencilFramebuffer);
        stencilFramebuffer.framebufferClear();
        stencilFramebuffer.bindFramebuffer(false);
        RoundedUtil.drawRound(x, y, width, height, radius, new Color(-2));
        stencilFramebuffer.unbindFramebuffer();
        KawaseBlur.renderBlur(stencilFramebuffer.framebufferTexture, s, o);
    }
    public static void GuiBlur(float x, float y, float width, float height, float radius) {
        stencilFramebuffer = RenderUtil.createFrameBuffer(stencilFramebuffer);
        stencilFramebuffer.framebufferClear();
        stencilFramebuffer.bindFramebuffer(false);
        RenderUtils.drawRoundedRect2(x, y, x + width, y + height, radius, 6, new Color(-2).getRGB());
        stencilFramebuffer.unbindFramebuffer();
        KawaseBlur.renderBlur(stencilFramebuffer.framebufferTexture, 5, 1);

    }
    public static void blurAreacustomradius(float x, float y, float width, float height) {
        stencilFramebuffer = RenderUtil.createFrameBuffer(stencilFramebuffer);
        stencilFramebuffer.framebufferClear();
        stencilFramebuffer.bindFramebuffer(false);
        RenderUtils.drawRect(x, y, x + width, y + height, new Color(-2).getRGB());
        stencilFramebuffer.unbindFramebuffer();
        KawaseBlur.renderBlur(stencilFramebuffer.framebufferTexture,CustomUI.blurValue.get(), CustomUI.blurOffset.get());
    }
    public static void blurRoundArea(float x, float y, float width, float height, int radius) {
        stencilFramebuffer = RenderUtil.createFrameBuffer(stencilFramebuffer);
        stencilFramebuffer.framebufferClear();
        stencilFramebuffer.bindFramebuffer(false);
        RenderUtils.drawRoundedRect2(x, y, x + width, y + height, radius, 6, new Color(-2).getRGB());
        stencilFramebuffer.unbindFramebuffer();
        KawaseBlur.renderBlur(stencilFramebuffer.framebufferTexture, CustomUI.blurValue.get(), CustomUI.blurOffset.get());

    }
}
