package cn.client.novoline.ui

import cn.client.oth.tenacity.blur.BlurBuffer
import cn.client.oth.tenacity.blur.GLUtil
import net.ccbluex.liquidbounce.Client
import net.ccbluex.liquidbounce.ui.client.GuiBackground
import net.ccbluex.liquidbounce.ui.client.altmanager.GuiAltManager
import net.ccbluex.liquidbounce.ui.font.Fonts
import net.ccbluex.liquidbounce.utils.Bloom
import net.ccbluex.liquidbounce.utils.MinecraftInstance
import net.ccbluex.liquidbounce.utils.render.RenderUtils
import net.ccbluex.liquidbounce.utils.render.RoundedUtil
import net.minecraft.client.Minecraft
import net.minecraft.client.gui.GuiLanguage
import net.minecraft.client.gui.GuiMultiplayer
import net.minecraft.client.gui.GuiOptions
import net.minecraft.client.gui.GuiScreen
import net.minecraft.client.gui.GuiWorldSelection
import net.minecraft.client.gui.ScaledResolution
import net.minecraft.util.ResourceLocation
import java.awt.Color
import java.io.IOException
import java.text.SimpleDateFormat

class GuiMainMenu : GuiScreen() {
    private var sr: ScaledResolution? = null
    var color1 = Color(30,30,30,255)
    var color2 = Color(30,30,30,255)
    var color3 = Color(30,30,30,255)


    override fun drawScreen(mouseX: Int, mouseY: Int, p: Float) {
        val sr = ScaledResolution(mc)
        RenderUtils.drawImage(ResourceLocation("autumn/blackboard.png"),0,0,sr.scaledWidth,sr.scaledHeight)
        width = sr.scaledWidth
        height = sr.scaledHeight
        RenderUtils.drawRect(0F,0F,width.toFloat(),40f,Color(30,30,30))
        Fonts.tenacityboldLogo.drawString(Client.CLIENT_NAME,25f,5f,Color.WHITE.rgb)
        val sdf=   SimpleDateFormat("HH:mm");
        val time2  = (sdf.format(System.currentTimeMillis()));
        Fonts.tenacitybold100.drawCenteredString(time2,width/2F,height/2f-30f,Color.WHITE.rgb)


        isHoveredText("Single Players", 20F,height - 110f,mouseX,mouseY)
        isHoveredText("Multi Players", 180f,height - 110f,mouseX,mouseY)
        isHoveredText("Settings", 340F,height - 110f,mouseX,mouseY)
        isHoveredText("Language",width -100f,10f,mouseX,mouseY)
        isHoveredText("BackGround",width -130f - Fonts.tenacitybold40.getStringWidth("Language"),10f,mouseX,mouseY)
        isHoveredText("AltManager",width -190f - Fonts.tenacitybold40.getStringWidth("BackGround"),10f,mouseX,mouseY)

    }
    fun renderPlayer2D(x: Float, y: Float, width: Float, height: Float, player: ResourceLocation) {
        GLUtil.startBlend()
        mc.textureManager.bindTexture(player)
        RenderUtils.drawScaledCustomSizeModalRect(
            x.toInt(),
            y.toInt(),
            8.0.toFloat(),
            8.0.toFloat(),
            8,
            8,
            width.toInt(),
            height.toInt(),
            64.0f,
            64.0f
        )
        GLUtil.endBlend()
    }

    fun drawNEWRound(x:Float,y: Float,width:Float,height:Float,radius:Float){
        BlurBuffer.nrb(x,y,width,height,radius,3,3)
        Bloom.Cshadow(1,1) {
            RoundedUtil.drawRound(
                x,y,width,height,radius, Color(0,0,0,200)
            )
        }
    }
    fun isHoveredText(text:String,x:Float,y:Float,mouseX: Int, mouseY: Int) {
        if (text == "AltManager") {
            if (RenderUtils.isHovered(
                    x, y, Fonts.tenacitybold40.getStringWidth("Language").toFloat(),
                    Fonts.tenacitybold40.fontHeight.toFloat(), mouseX, mouseY
                )
            ) {
                Fonts.tenacitybold40.drawString("AltManager", x, y, Color(255, 255, 255, 255).rgb)
            } else {
                Fonts.tenacitybold40.drawString("AltManager", x, y, Color(146, 146, 146, 255).rgb)
            }
        }
        if (text == "Language") {
            if (RenderUtils.isHovered(
                    x, y, Fonts.tenacitybold40.getStringWidth("Language").toFloat(),
                    Fonts.tenacitybold40.fontHeight.toFloat(), mouseX, mouseY
                )
            ) {
                Fonts.tenacitybold40.drawString("Language", x, y, Color(255, 255, 255, 255).rgb)
            } else {
                Fonts.tenacitybold40.drawString("Language", x, y, Color(146, 146, 146, 255).rgb)
            }
        }
        if (text == "BackGround") {
            if (RenderUtils.isHovered(
                    x, y, Fonts.tenacitybold40.getStringWidth("BackGround").toFloat(),
                    Fonts.tenacitybold40.fontHeight.toFloat(), mouseX, mouseY
                )
            ) {
                Fonts.tenacitybold40.drawString("BackGround", x, y, Color(255, 255, 255, 255).rgb)
            } else {
                Fonts.tenacitybold40.drawString("BackGround", x, y, Color(146, 146, 146, 255).rgb)
            }
        }

        if (text == "Single Players") {
            if (RenderUtils.isHovered(x, y, 150f, 80F, mouseX, mouseY)) {
                RoundedUtil.drawRound(
                    x - 2, y - 2, 154f, 84F, 0f, Color(255, 255, 255, 255)
                )

                RoundedUtil.drawRound(
                    x, y, 150f, 80F, 0f, color1
                )
                Fonts.hicon45.drawString("F", (x + 10f), y + 5f, Color(255, 255, 255, 200).rgb)
                Fonts.tenacitybold40.drawString(
                    text, (x + 10f) + Fonts.hicon45.getStringWidth("F"),
                    y + 10f, Color(255, 255, 255, 200).rgb
                )
                Fonts.tenacitybold30.drawString(
                    "The world of one.",
                    (x + 10f) + Fonts.hicon45.getStringWidth("F"),
                    y + 30f,
                    Color(60, 60, 60).rgb
                )
                Fonts.tenacitybold30.drawString(
                    "You can do anything",
                    (x + 10f) + Fonts.hicon45.getStringWidth("F"),
                    y + 30f + Fonts.tenacitybold30.fontHeight,
                    Color(60, 60, 60).rgb
                )
                Fonts.tenacitybold30.drawString(
                    "want in this world.",
                    (x + 10f) + Fonts.hicon45.getStringWidth("F"),
                    y + 30f + Fonts.tenacitybold30.fontHeight * 2,
                    Color(60, 60, 60).rgb
                )
            } else {
                if (RenderUtils.isHovered(x, y, 150f, 80F, mouseX, mouseY)) {
                    RoundedUtil.drawRound(
                        x - 2, y - 2, 154f, 84F, 0f, Color(255, 255, 255, 255)
                    )
                }

                Bloom.Cshadow(4, 0) {
                    RoundedUtil.drawRound(
                        x, y, 150f, 80F, 0f, color1
                    )
                }
                RoundedUtil.drawRound(
                    x, y, 150f, 80F, 0f, color1
                )
                Fonts.hicon45.drawString("F", (x + 10f), y + 5f, Color(255, 255, 255, 200).rgb)
                Fonts.tenacitybold40.drawString(
                    text, (x + 10f) + Fonts.hicon45.getStringWidth("F"),
                    y + 10f, Color(255, 255, 255, 200).rgb
                )
                Fonts.tenacitybold30.drawString(
                    "The world of one.",
                    (x + 10f) + Fonts.hicon45.getStringWidth("F"),
                    y + 30f,
                    Color(60, 60, 60).rgb
                )
                Fonts.tenacitybold30.drawString(
                    "You can do anything",
                    (x + 10f) + Fonts.hicon45.getStringWidth("F"),
                    y + 30f + Fonts.tenacitybold30.fontHeight,
                    Color(60, 60, 60).rgb
                )
                Fonts.tenacitybold30.drawString(
                    "want in this world.",
                    (x + 10f) + Fonts.hicon45.getStringWidth("F"),
                    y + 30f + Fonts.tenacitybold30.fontHeight * 2,
                    Color(60, 60, 60).rgb
                )

            }
        }

        if (text == "Multi Players") {

            if (RenderUtils.isHovered(x, y, 150f, 80F, mouseX, mouseY)) {
                RoundedUtil.drawRound(
                    x - 2, y - 2, 154f, 84F, 0f, Color(255, 255, 255, 255)
                )
                RoundedUtil.drawRound(
                    x, y, 150f, 80F, 0f, color2
                )
                Fonts.hicon45.drawString("H", (x + 10f), y + 5f, Color(255, 255, 255, 200).rgb)
                Fonts.tenacitybold40.drawString(
                    text, (x + 10f) + Fonts.hicon45.getStringWidth("H"),
                    y + 10f, Color(255, 255, 255, 200).rgb
                )
                Fonts.tenacitybold30.drawString(
                    "You have access to other",
                    (x + 10f) + Fonts.hicon45.getStringWidth("H"),
                    y + 30f,
                    Color(60, 60, 60).rgb
                )
                Fonts.tenacitybold30.drawString(
                    "people's servers.",
                    (x + 10f) + Fonts.hicon45.getStringWidth("H"),
                    y + 30f + Fonts.tenacitybold30.fontHeight,
                    Color(60, 60, 60).rgb
                )
                Fonts.tenacitybold30.drawString(
                    "And defeated them using Client.",
                    (x + 10f) + Fonts.hicon45.getStringWidth("H"),
                    y + 30f + Fonts.tenacitybold30.fontHeight * 2,
                    Color(60, 60, 60).rgb
                )

            } else {


                Bloom.Cshadow(4, 0) {
                    RoundedUtil.drawRound(
                        x, y, 150f, 80F, 0f, color2
                    )
                }
                RoundedUtil.drawRound(
                    x, y, 150f, 80F, 0f, color2
                )
                Fonts.hicon45.drawString("H", (x + 10f), y + 5f, Color(255, 255, 255, 200).rgb)
                Fonts.tenacitybold40.drawString(
                    text, (x + 10f) + Fonts.hicon45.getStringWidth("H"),
                    y + 10f, Color(255, 255, 255, 200).rgb
                )
                Fonts.tenacitybold30.drawString(
                    "You have access to other",
                    (x + 10f) + Fonts.hicon45.getStringWidth("H"),
                    y + 30f,
                    Color(60, 60, 60).rgb
                )
                Fonts.tenacitybold30.drawString(
                    "people's servers.",
                    (x + 10f) + Fonts.hicon45.getStringWidth("H"),
                    y + 30f + Fonts.tenacitybold30.fontHeight,
                    Color(60, 60, 60).rgb
                )
                Fonts.tenacitybold30.drawString(
                    "And defeated them using Client.",
                    (x + 10f) + Fonts.hicon45.getStringWidth("H"),
                    y + 30f + Fonts.tenacitybold30.fontHeight * 2,
                    Color(60, 60, 60).rgb
                )

            }
        }

        if (text == "Settings") {
            if (RenderUtils.isHovered(x, y, 150f, 80F, mouseX, mouseY)) {
                RoundedUtil.drawRound(
                    x - 2, y - 2, 154f, 84F, 0f, Color(255, 255, 255, 255)
                )
                RoundedUtil.drawRound(
                    x, y, 150f, 80F, 0f, color3
                )
                Fonts.hicon45.drawString("K", (x + 10f), y + 5f, Color(255, 255, 255, 200).rgb)
                Fonts.tenacitybold40.drawString(
                    text, (x + 10f) + Fonts.hicon45.getStringWidth("K"),
                    y + 10f, Color(255, 255, 255, 200).rgb
                )
                Fonts.tenacitybold30.drawString(
                    "About the client Settings",
                    (x + 10f) + Fonts.hicon45.getStringWidth("K"),
                    y + 30f,
                    Color(60, 60, 60).rgb
                )
                Fonts.tenacitybold30.drawString(
                    "You can change a lot of things",
                    (x + 10f) + Fonts.hicon45.getStringWidth("K"),
                    y + 30f + Fonts.tenacitybold30.fontHeight,
                    Color(60, 60, 60).rgb
                )
                Fonts.tenacitybold30.drawString(
                    "on the client here.",
                    (x + 10f) + Fonts.hicon45.getStringWidth("K"),
                    y + 30f + Fonts.tenacitybold30.fontHeight * 2,
                    Color(60, 60, 60).rgb
                )
            } else{


                Bloom.Cshadow(4, 0) {
                    RoundedUtil.drawRound(
                        x, y, 150f, 80F, 0f, color3
                    )
                }
            RoundedUtil.drawRound(
                x, y, 150f, 80F, 0f, color3
            )
            Fonts.hicon45.drawString("K", (x + 10f), y + 5f, Color(255, 255, 255, 200).rgb)
            Fonts.tenacitybold40.drawString(
                text, (x + 10f) + Fonts.hicon45.getStringWidth("K"),
                y + 10f, Color(255, 255, 255, 200).rgb
            )
            Fonts.tenacitybold30.drawString(
                "About the client Settings",
                (x + 10f) + Fonts.hicon45.getStringWidth("K"),
                y + 30f,
                Color(60, 60, 60).rgb
            )
            Fonts.tenacitybold30.drawString(
                "You can change a lot of things",
                (x + 10f) + Fonts.hicon45.getStringWidth("K"),
                y + 30f + Fonts.tenacitybold30.fontHeight,
                Color(60, 60, 60).rgb
            )
            Fonts.tenacitybold30.drawString(
                "on the client here.",
                (x + 10f) + Fonts.hicon45.getStringWidth("K"),
                y + 30f + Fonts.tenacitybold30.fontHeight * 2,
                Color(60, 60, 60).rgb
            )


        }
    }

    }
    override fun initGui() {
        sr = ScaledResolution(mc)
        super.initGui()
    }


    @Throws(IOException::class)
    override fun mouseClicked(mouseX: Int, mouseY: Int, p: Int) {
        if (RenderUtils.isHovered(width -130f - Fonts.tenacitybold40.getStringWidth("Language"),10f, Fonts.tenacitybold40.getStringWidth("Language").toFloat(),
                Fonts.tenacitybold40.fontHeight.toFloat(),mouseX,mouseY)){
            MinecraftInstance.mc.displayGuiScreen(MinecraftInstance.classProvider.wrapGuiScreen(GuiBackground(
                MinecraftInstance.mc.currentScreen!!
            )))

        }
        if (RenderUtils.isHovered(width -190f - Fonts.tenacitybold40.getStringWidth("AltManager"),10f, Fonts.tenacitybold40.getStringWidth("AltManager").toFloat(),
                Fonts.tenacitybold40.fontHeight.toFloat(),mouseX,mouseY)){
            MinecraftInstance.mc.displayGuiScreen(MinecraftInstance.classProvider.wrapGuiScreen(GuiAltManager()))

        }

        if (RenderUtils.isHovered(width -100f,10f, Fonts.tenacitybold40.getStringWidth("Language").toFloat(),
                Fonts.tenacitybold40.fontHeight.toFloat(),mouseX,mouseY)){
            mc.displayGuiScreen(GuiLanguage(this,Minecraft.getMinecraft().gameSettings,Minecraft.getMinecraft().languageManager))

        }
        if (RenderUtils.isHovered(20f,height - 110f,150f,80f, mouseX, mouseY)) {
            mc.displayGuiScreen(GuiWorldSelection(this))
        }
        if (RenderUtils.isHovered(180f,height - 110f,150f,80f, mouseX, mouseY)) {

            mc.displayGuiScreen(GuiMultiplayer(this))
        }
        if (RenderUtils.isHovered(340f,height - 110f,150f,80f, mouseX, mouseY)) {

            mc.displayGuiScreen(GuiOptions(this, Minecraft.getMinecraft().gameSettings))

        }

        super.mouseClicked(mouseX, mouseY, p)
    }
}