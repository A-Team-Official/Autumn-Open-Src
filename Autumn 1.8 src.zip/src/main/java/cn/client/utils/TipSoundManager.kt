
package cn.client.utils

import net.ccbluex.liquidbounce.Client
import net.ccbluex.liquidbounce.utils.render.tenacity.FileUtils
import java.io.File

class TipSoundManager {
    var enableSound : TipSoundPlayer
    var disableSound : TipSoundPlayer

    init {
        val enableSoundFile=File(Client.fileManager.soundsDir,"enable.wav")
        val disableSoundFile=File(Client.fileManager.soundsDir,"disable.wav")

        if(!enableSoundFile.exists())
            FileUtils.unpackFile(enableSoundFile,"assets/minecraft/autumn/sounds/enable.wav")
        if(!disableSoundFile.exists())
            FileUtils.unpackFile(disableSoundFile,"assets/minecraft/autumn/sounds/disable.wav")

        enableSound=TipSoundPlayer(enableSoundFile)
        disableSound=TipSoundPlayer(disableSoundFile)
    }
}