package cn.client.utils;

import net.ccbluex.liquidbounce.ui.client.newdropdown.SideGui.SideGui;
import net.ccbluex.liquidbounce.utils.ClientUtils;

public class ClientMain {

    private static ClientMain INSTANCE;

    public static ClientMain getInstance() {
        try {
            if (INSTANCE == null) INSTANCE = new ClientMain();
            return INSTANCE;
        } catch (Throwable t) {
            ClientUtils.getLogger().warn(t);
            throw t;
        }
    }


    private final SideGui sideGui = new SideGui();

    public SideGui getSideGui() {
        return sideGui;
    }

}
