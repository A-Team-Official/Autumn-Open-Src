package cn.client.utils.Color.modules

import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.value.BoolValue
import net.ccbluex.liquidbounce.value.FloatValue
import net.ccbluex.liquidbounce.value.IntegerValue


@ModuleInfo(name = "UISettings", description = "Custom", category = ModuleCategory.GUI, Chinese = "自定义界面")
class CustomUI : Module() {


    companion object {
        @JvmField
        val r = IntegerValue("Red", 29, 0, 255)
        @JvmField
        val g = IntegerValue("Green", 40, 0, 255)
        @JvmField
        val b = IntegerValue("Blue", 53, 0, 255)
        @JvmField
        val r2= IntegerValue("Red2", 20, 0, 255)
        @JvmField
        val g2= IntegerValue("Green2", 50, 0, 255)
        @JvmField
        val b2 = IntegerValue("Blue2", 80, 0, 255)
        @JvmField
        val a = IntegerValue("Alpha", 255, 0, 255)
        @JvmField
        val radius = FloatValue("Radius", 3f, 0f, 10f)
        @JvmField
        var Chinese = BoolValue("Chinese",true)
        @JvmField
        val aspeed = FloatValue("AnimationSpeed",200f,1f,1500f)
        //Blur
        @JvmField
        var Blur = BoolValue("Blur",false)
        @JvmField
        var blurValue = IntegerValue("BlurStrength", 5,1,8)
        @JvmField
        var blurOffset = IntegerValue("BlurOffset", 2,0,10)
        @JvmField
        var Shadow = BoolValue("Shadow",true)
        @JvmField
        var shadowValue = IntegerValue("ShadowStrength", 5,1,8)
        @JvmField
        var shadowOffset = IntegerValue("ShadowOffset", 2,0,10)
    }




}
