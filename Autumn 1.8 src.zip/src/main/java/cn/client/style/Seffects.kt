package cn.client.style

import cn.client.oth.tenacity.blur.Bloom
import cn.client.oth.tenacity.blur.BlurBuffer
import cn.client.utils.Color.modules.CustomUI
import net.ccbluex.liquidbounce.api.minecraft.potion.IPotion
import net.ccbluex.liquidbounce.ui.client.hud.element.Border
import net.ccbluex.liquidbounce.ui.client.hud.element.Element
import net.ccbluex.liquidbounce.ui.client.hud.element.ElementInfo
import net.ccbluex.liquidbounce.ui.font.Fonts
import net.ccbluex.liquidbounce.utils.PotionData
import net.ccbluex.liquidbounce.utils.Translate
import net.ccbluex.liquidbounce.utils.render.RenderUtils
import net.ccbluex.liquidbounce.utils.render.RoundedUtil
import net.ccbluex.liquidbounce.utils.timer.MSTimer
import net.ccbluex.liquidbounce.value.BoolValue
import net.minecraft.client.renderer.GlStateManager
import org.lwjgl.opengl.GL11
import java.awt.Color
import java.util.*
import kotlin.math.pow

@cn.obf.Native
@ElementInfo(name = "S-Effects")
class Seffects(x: Double =97.0, y: Double = 141.0, scale: Float = 1F) : Element() {

    private val potionMap: MutableMap<IPotion, PotionData?> = HashMap()

    var timer = MSTimer()
    var backamin = 0f
    var healthamin = 0f
    var pcololr = Color(255,255,255)
    /**
     * Draw the entity.
     */
    override fun drawElement(): Border {

        RoundedUtil.drawRound(
            12.20f,
            -7.32f,
            100f,
            20f,
            CustomUI.radius.get(),
            Color(24,40,52)
        )
        GlStateManager.pushMatrix()
        var namewith3 = 0f
        var namehight = 0f
        var y = 0
        for (potionEffect in Objects.requireNonNull(mc.thePlayer)!!.activePotionEffects) {
            val potion = functions.getPotionById(potionEffect.potionID)
            val name = functions.formatI18n(potion.name)
            val potionData: PotionData?
            if (potionMap.containsKey(potion) && potionMap[potion]!!.level == potionEffect.amplifier) potionData =
                potionMap[potion] else potionMap[potion] =
                PotionData(potion, Translate(0f, -40f + y), potionEffect.amplifier).also {
                    potionData = it
                }
            var flag = true
            for (checkEffect in mc.thePlayer!!.activePotionEffects) if (checkEffect.amplifier == potionData!!.level) {
                flag = false
                break
            }
            if (flag) potionMap.remove(potion)
            var potionTime: Int
            var potionMaxTime: Int
            try {
                potionTime = potionEffect.getDurationString().split(":".toRegex()).dropLastWhile { it.isEmpty() }
                    .toTypedArray()[0].toInt()
                potionMaxTime = potionEffect.getDurationString().split(":".toRegex()).dropLastWhile { it.isEmpty() }
                    .toTypedArray()[1].toInt()
            } catch (ignored: Exception) {
                potionTime = 100
                potionMaxTime = 1000
            }
            val lifeTime = potionTime * 60 + potionMaxTime
            if (potionData!!.getMaxTimer() == 0 || lifeTime > potionData.getMaxTimer().toDouble()) potionData.maxTimer =
                lifeTime
            var state = 0.0f
            if (lifeTime >= 0.0) state = (lifeTime / potionData.getMaxTimer().toFloat().toDouble() * 100.0).toFloat()
            state = Math.max(state, 2.0f)
            potionData.translate.interpolate(0f, y.toFloat(), 0.1)
            potionData.animationX = RenderUtils.getAnimationState2(
                potionData.getAnimationX().toDouble(), (1.2f * state).toDouble(),CustomUI.aspeed.get().toDouble()
            ).toFloat()

            val namewith2 =
                Fonts.mousesans30.getStringWidth(name+" "+ intToRomanByGreedy(potionEffect.amplifier + 1))
            if (namewith2 > namewith3) {
                namewith3 = namewith2.toFloat()
            }
            val posY = potionData.translate.y / 2.5f - 3f
            namehight = potionData.translate.y/ 2.5f-8f
            Fonts.mousesans30.drawString(
                name+" "+intToRomanByGreedy(potionEffect.amplifier + 1),
                15f,
                -(posY - Fonts.mousesans30.fontHeight),
                -1
            )

            Fonts.mousesans30.drawString(potionEffect.getDurationString(), 93f, -(posY - 9.76f), -1)
            y -= 35
        }



        GlStateManager.popMatrix()
        Fonts.icon40.drawString("q",16,-2,Color.WHITE.rgb)
        Fonts.mousesans35.drawString("Potions",27,-1,Color.WHITE.rgb)

        return Border(12.20f,
            -7.32f,
            100f,
            20f + 2f,2f)
    }


    private fun intToRomanByGreedy(num: Int): String {
        var num = num
        val values = intArrayOf(1000, 900, 500, 400, 100, 90, 50, 40, 10, 9, 5, 4, 1)
        val symbols = arrayOf("M", "CM", "D", "CD", "C", "XC", "L", "XL", "X", "IX", "V", "IV", "I")
        val stringBuilder = StringBuilder()
        var i = 0
        while (i < values.size && num >= 0) {
            while (values[i] <= num) {
                num -= values[i]
                stringBuilder.append(symbols[i])
            }
            i++
        }
        return stringBuilder.toString()
    }

    companion object {
        private val blur = BoolValue("Blur", true)
    }
}