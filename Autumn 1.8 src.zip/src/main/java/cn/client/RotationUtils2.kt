package cn.client

import net.ccbluex.liquidbounce.event.Listenable
import net.ccbluex.liquidbounce.utils.MinecraftInstance
import net.ccbluex.liquidbounce.utils.Rotation


object RotationUtils2 : MinecraftInstance(), Listenable {
    var targetRotation: Rotation? = null
    override fun handleEvents() = true
}