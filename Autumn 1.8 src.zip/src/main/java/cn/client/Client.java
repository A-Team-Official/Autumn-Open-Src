package cn.client;

import cn.client.neverlose.yuanshen.OP;
import net.minecraft.client.Minecraft;

public class Client {
    public OP skeet;

    public static Client instance = new Client();

    public static double deltaTime() {
        return Minecraft.getDebugFPS() > 0 ? (1.0000 / Minecraft.getDebugFPS()) : 1;
    }

}
