package net.ccbluex.liquidbounce.features.module.modules.hyt

import net.ccbluex.liquidbounce.event.EventTarget
import net.ccbluex.liquidbounce.event.MotionEvent
import net.ccbluex.liquidbounce.event.PacketEvent
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.injection.backend.unwrap
import net.ccbluex.liquidbounce.utils.PacketUtils
import net.ccbluex.liquidbounce.value.FloatValue
import net.minecraft.init.Blocks
import net.minecraft.network.play.client.CPacketPlayerDigging
import net.minecraft.util.EnumFacing
import net.minecraft.util.math.BlockPos
import top.fl0wowp4rty.phantomshield.annotations.Native

@Native
@ModuleInfo(name = "HYTSpeedMine", description = "SpeedMine", category = ModuleCategory.HYT, Chinese = "更快的挖掘")
class BWSpeedMine : Module() {

    private val speedValue = FloatValue("Speed", 1.5f, 1f, 3f)
    private var facing: EnumFacing? = null
    private var pos: BlockPos? = null
    private var boost = false
    private var damage = 0f
    @EventTarget
    fun onMotion(e: MotionEvent) {
        if (e.isPre()) {
            mc.playerController.blockHitDelay = 0
            if (pos != null && boost) {
                val blockState = mc2.world!!.getBlockState(pos!!) ?: return
                damage += try {
                    blockState.block.getPlayerRelativeBlockHardness(mc2.world.getBlockState(pos!!),mc2.player, mc2.world, pos!!) * speedValue.get()
                } catch (ex: Exception) {
                    ex.printStackTrace()
                    return
                }
                if (damage >= 1) {
                    try {
                        mc2.world!!.setBlockState(pos!!, Blocks.AIR.defaultState, 11)
                    } catch (ex: Exception) {
                        ex.printStackTrace()
                        return
                    }
                    PacketUtils.sendPacketNoEvent(
                        CPacketPlayerDigging(
                            CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK,
                            pos!!,
                            facing!!
                        )
                    )
                    damage = 0f
                    boost = false
                }
            }
        }
    }

    @EventTarget
    fun onPacket(e: PacketEvent) {
        val packet = e.packet.unwrap()

        if (packet is CPacketPlayerDigging) {
            if (packet.action == CPacketPlayerDigging.Action.START_DESTROY_BLOCK) {
                boost = true
                pos = packet.position
                facing = packet.facing
                damage = 0f
            } else if ((packet.action == CPacketPlayerDigging.Action.ABORT_DESTROY_BLOCK) or (packet.action == CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK)) {
                boost = false
                pos = null
                facing = null
            }
        }
    }


}