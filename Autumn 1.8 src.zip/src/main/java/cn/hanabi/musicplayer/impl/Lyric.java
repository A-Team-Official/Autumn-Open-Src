package cn.hanabi.musicplayer.impl;


public class Lyric {
	public long time;
	public String text;
	
	public Lyric(String text, long time) {
		this.text = text;
		this.time = time;
	}
}
